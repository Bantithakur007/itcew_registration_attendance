/*! For license information please see main.242c745f.js.LICENSE.txt */
(() => {
    "use strict";
    var e = {
            730: (e, t, n) => {
                var r = n(43),
                    a = n(853);

                function o(e) {
                    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
                    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
                }
                var l = new Set,
                    i = {};

                function s(e, t) {
                    u(e, t), u(e + "Capture", t)
                }

                function u(e, t) {
                    for (i[e] = t, e = 0; e < t.length; e++) l.add(t[e])
                }
                var c = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement),
                    d = Object.prototype.hasOwnProperty,
                    f = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
                    p = {},
                    h = {};

                function m(e, t, n, r, a, o, l) {
                    this.acceptsBooleans = 2 === t || 3 === t || 4 === t, this.attributeName = r, this.attributeNamespace = a, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = l
                }
                var g = {};
                "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach((function(e) {
                    g[e] = new m(e, 0, !1, e, null, !1, !1)
                })), [
                    ["acceptCharset", "accept-charset"],
                    ["className", "class"],
                    ["htmlFor", "for"],
                    ["httpEquiv", "http-equiv"]
                ].forEach((function(e) {
                    var t = e[0];
                    g[t] = new m(t, 1, !1, e[1], null, !1, !1)
                })), ["contentEditable", "draggable", "spellCheck", "value"].forEach((function(e) {
                    g[e] = new m(e, 2, !1, e.toLowerCase(), null, !1, !1)
                })), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach((function(e) {
                    g[e] = new m(e, 2, !1, e, null, !1, !1)
                })), "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach((function(e) {
                    g[e] = new m(e, 3, !1, e.toLowerCase(), null, !1, !1)
                })), ["checked", "multiple", "muted", "selected"].forEach((function(e) {
                    g[e] = new m(e, 3, !0, e, null, !1, !1)
                })), ["capture", "download"].forEach((function(e) {
                    g[e] = new m(e, 4, !1, e, null, !1, !1)
                })), ["cols", "rows", "size", "span"].forEach((function(e) {
                    g[e] = new m(e, 6, !1, e, null, !1, !1)
                })), ["rowSpan", "start"].forEach((function(e) {
                    g[e] = new m(e, 5, !1, e.toLowerCase(), null, !1, !1)
                }));
                var y = /[\-:]([a-z])/g;

                function v(e) {
                    return e[1].toUpperCase()
                }

                function b(e, t, n, r) {
                    var a = g.hasOwnProperty(t) ? g[t] : null;
                    (null !== a ? 0 !== a.type : r || !(2 < t.length) || "o" !== t[0] && "O" !== t[0] || "n" !== t[1] && "N" !== t[1]) && (function(e, t, n, r) {
                        if (null === t || "undefined" === typeof t || function(e, t, n, r) {
                                if (null !== n && 0 === n.type) return !1;
                                switch (typeof t) {
                                    case "function":
                                    case "symbol":
                                        return !0;
                                    case "boolean":
                                        return !r && (null !== n ? !n.acceptsBooleans : "data-" !== (e = e.toLowerCase().slice(0, 5)) && "aria-" !== e);
                                    default:
                                        return !1
                                }
                            }(e, t, n, r)) return !0;
                        if (r) return !1;
                        if (null !== n) switch (n.type) {
                            case 3:
                                return !t;
                            case 4:
                                return !1 === t;
                            case 5:
                                return isNaN(t);
                            case 6:
                                return isNaN(t) || 1 > t
                        }
                        return !1
                    }(t, n, a, r) && (n = null), r || null === a ? function(e) {
                        return !!d.call(h, e) || !d.call(p, e) && (f.test(e) ? h[e] = !0 : (p[e] = !0, !1))
                    }(t) && (null === n ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : a.mustUseProperty ? e[a.propertyName] = null === n ? 3 !== a.type && "" : n : (t = a.attributeName, r = a.attributeNamespace, null === n ? e.removeAttribute(t) : (n = 3 === (a = a.type) || 4 === a && !0 === n ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
                }
                "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach((function(e) {
                    var t = e.replace(y, v);
                    g[t] = new m(t, 1, !1, e, null, !1, !1)
                })), "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach((function(e) {
                    var t = e.replace(y, v);
                    g[t] = new m(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
                })), ["xml:base", "xml:lang", "xml:space"].forEach((function(e) {
                    var t = e.replace(y, v);
                    g[t] = new m(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
                })), ["tabIndex", "crossOrigin"].forEach((function(e) {
                    g[e] = new m(e, 1, !1, e.toLowerCase(), null, !1, !1)
                })), g.xlinkHref = new m("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1), ["src", "href", "action", "formAction"].forEach((function(e) {
                    g[e] = new m(e, 1, !1, e.toLowerCase(), null, !0, !0)
                }));
                var w = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
                    x = Symbol.for("react.element"),
                    S = Symbol.for("react.portal"),
                    k = Symbol.for("react.fragment"),
                    E = Symbol.for("react.strict_mode"),
                    C = Symbol.for("react.profiler"),
                    N = Symbol.for("react.provider"),
                    j = Symbol.for("react.context"),
                    _ = Symbol.for("react.forward_ref"),
                    T = Symbol.for("react.suspense"),
                    P = Symbol.for("react.suspense_list"),
                    O = Symbol.for("react.memo"),
                    R = Symbol.for("react.lazy");
                Symbol.for("react.scope"), Symbol.for("react.debug_trace_mode");
                var L = Symbol.for("react.offscreen");
                Symbol.for("react.legacy_hidden"), Symbol.for("react.cache"), Symbol.for("react.tracing_marker");
                var z = Symbol.iterator;

                function D(e) {
                    return null === e || "object" !== typeof e ? null : "function" === typeof(e = z && e[z] || e["@@iterator"]) ? e : null
                }
                var A, I = Object.assign;

                function F(e) {
                    if (void 0 === A) try {
                        throw Error()
                    } catch (n) {
                        var t = n.stack.trim().match(/\n( *(at )?)/);
                        A = t && t[1] || ""
                    }
                    return "\n" + A + e
                }
                var U = !1;

                function M(e, t) {
                    if (!e || U) return "";
                    U = !0;
                    var n = Error.prepareStackTrace;
                    Error.prepareStackTrace = void 0;
                    try {
                        if (t)
                            if (t = function() {
                                    throw Error()
                                }, Object.defineProperty(t.prototype, "props", {
                                    set: function() {
                                        throw Error()
                                    }
                                }), "object" === typeof Reflect && Reflect.construct) {
                                try {
                                    Reflect.construct(t, [])
                                } catch (u) {
                                    var r = u
                                }
                                Reflect.construct(e, [], t)
                            } else {
                                try {
                                    t.call()
                                } catch (u) {
                                    r = u
                                }
                                e.call(t.prototype)
                            }
                        else {
                            try {
                                throw Error()
                            } catch (u) {
                                r = u
                            }
                            e()
                        }
                    } catch (u) {
                        if (u && r && "string" === typeof u.stack) {
                            for (var a = u.stack.split("\n"), o = r.stack.split("\n"), l = a.length - 1, i = o.length - 1; 1 <= l && 0 <= i && a[l] !== o[i];) i--;
                            for (; 1 <= l && 0 <= i; l--, i--)
                                if (a[l] !== o[i]) {
                                    if (1 !== l || 1 !== i)
                                        do {
                                            if (l--, 0 > --i || a[l] !== o[i]) {
                                                var s = "\n" + a[l].replace(" at new ", " at ");
                                                return e.displayName && s.includes("<anonymous>") && (s = s.replace("<anonymous>", e.displayName)), s
                                            }
                                        } while (1 <= l && 0 <= i);
                                    break
                                }
                        }
                    } finally {
                        U = !1, Error.prepareStackTrace = n
                    }
                    return (e = e ? e.displayName || e.name : "") ? F(e) : ""
                }

                function B(e) {
                    switch (e.tag) {
                        case 5:
                            return F(e.type);
                        case 16:
                            return F("Lazy");
                        case 13:
                            return F("Suspense");
                        case 19:
                            return F("SuspenseList");
                        case 0:
                        case 2:
                        case 15:
                            return e = M(e.type, !1);
                        case 11:
                            return e = M(e.type.render, !1);
                        case 1:
                            return e = M(e.type, !0);
                        default:
                            return ""
                    }
                }

                function H(e) {
                    if (null == e) return null;
                    if ("function" === typeof e) return e.displayName || e.name || null;
                    if ("string" === typeof e) return e;
                    switch (e) {
                        case k:
                            return "Fragment";
                        case S:
                            return "Portal";
                        case C:
                            return "Profiler";
                        case E:
                            return "StrictMode";
                        case T:
                            return "Suspense";
                        case P:
                            return "SuspenseList"
                    }
                    if ("object" === typeof e) switch (e.$$typeof) {
                        case j:
                            return (e.displayName || "Context") + ".Consumer";
                        case N:
                            return (e._context.displayName || "Context") + ".Provider";
                        case _:
                            var t = e.render;
                            return (e = e.displayName) || (e = "" !== (e = t.displayName || t.name || "") ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
                        case O:
                            return null !== (t = e.displayName || null) ? t : H(e.type) || "Memo";
                        case R:
                            t = e._payload, e = e._init;
                            try {
                                return H(e(t))
                            } catch (n) {}
                    }
                    return null
                }

                function W(e) {
                    var t = e.type;
                    switch (e.tag) {
                        case 24:
                            return "Cache";
                        case 9:
                            return (t.displayName || "Context") + ".Consumer";
                        case 10:
                            return (t._context.displayName || "Context") + ".Provider";
                        case 18:
                            return "DehydratedFragment";
                        case 11:
                            return e = (e = t.render).displayName || e.name || "", t.displayName || ("" !== e ? "ForwardRef(" + e + ")" : "ForwardRef");
                        case 7:
                            return "Fragment";
                        case 5:
                            return t;
                        case 4:
                            return "Portal";
                        case 3:
                            return "Root";
                        case 6:
                            return "Text";
                        case 16:
                            return H(t);
                        case 8:
                            return t === E ? "StrictMode" : "Mode";
                        case 22:
                            return "Offscreen";
                        case 12:
                            return "Profiler";
                        case 21:
                            return "Scope";
                        case 13:
                            return "Suspense";
                        case 19:
                            return "SuspenseList";
                        case 25:
                            return "TracingMarker";
                        case 1:
                        case 0:
                        case 17:
                        case 2:
                        case 14:
                        case 15:
                            if ("function" === typeof t) return t.displayName || t.name || null;
                            if ("string" === typeof t) return t
                    }
                    return null
                }

                function V(e) {
                    switch (typeof e) {
                        case "boolean":
                        case "number":
                        case "string":
                        case "undefined":
                        case "object":
                            return e;
                        default:
                            return ""
                    }
                }

                function $(e) {
                    var t = e.type;
                    return (e = e.nodeName) && "input" === e.toLowerCase() && ("checkbox" === t || "radio" === t)
                }

                function q(e) {
                    e._valueTracker || (e._valueTracker = function(e) {
                        var t = $(e) ? "checked" : "value",
                            n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
                            r = "" + e[t];
                        if (!e.hasOwnProperty(t) && "undefined" !== typeof n && "function" === typeof n.get && "function" === typeof n.set) {
                            var a = n.get,
                                o = n.set;
                            return Object.defineProperty(e, t, {
                                configurable: !0,
                                get: function() {
                                    return a.call(this)
                                },
                                set: function(e) {
                                    r = "" + e, o.call(this, e)
                                }
                            }), Object.defineProperty(e, t, {
                                enumerable: n.enumerable
                            }), {
                                getValue: function() {
                                    return r
                                },
                                setValue: function(e) {
                                    r = "" + e
                                },
                                stopTracking: function() {
                                    e._valueTracker = null, delete e[t]
                                }
                            }
                        }
                    }(e))
                }

                function Q(e) {
                    if (!e) return !1;
                    var t = e._valueTracker;
                    if (!t) return !0;
                    var n = t.getValue(),
                        r = "";
                    return e && (r = $(e) ? e.checked ? "true" : "false" : e.value), (e = r) !== n && (t.setValue(e), !0)
                }

                function K(e) {
                    if ("undefined" === typeof(e = e || ("undefined" !== typeof document ? document : void 0))) return null;
                    try {
                        return e.activeElement || e.body
                    } catch (t) {
                        return e.body
                    }
                }

                function G(e, t) {
                    var n = t.checked;
                    return I({}, t, {
                        defaultChecked: void 0,
                        defaultValue: void 0,
                        value: void 0,
                        checked: null != n ? n : e._wrapperState.initialChecked
                    })
                }

                function J(e, t) {
                    var n = null == t.defaultValue ? "" : t.defaultValue,
                        r = null != t.checked ? t.checked : t.defaultChecked;
                    n = V(null != t.value ? t.value : n), e._wrapperState = {
                        initialChecked: r,
                        initialValue: n,
                        controlled: "checkbox" === t.type || "radio" === t.type ? null != t.checked : null != t.value
                    }
                }

                function X(e, t) {
                    null != (t = t.checked) && b(e, "checked", t, !1)
                }

                function Y(e, t) {
                    X(e, t);
                    var n = V(t.value),
                        r = t.type;
                    if (null != n) "number" === r ? (0 === n && "" === e.value || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
                    else if ("submit" === r || "reset" === r) return void e.removeAttribute("value");
                    t.hasOwnProperty("value") ? ee(e, t.type, n) : t.hasOwnProperty("defaultValue") && ee(e, t.type, V(t.defaultValue)), null == t.checked && null != t.defaultChecked && (e.defaultChecked = !!t.defaultChecked)
                }

                function Z(e, t, n) {
                    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
                        var r = t.type;
                        if (!("submit" !== r && "reset" !== r || void 0 !== t.value && null !== t.value)) return;
                        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
                    }
                    "" !== (n = e.name) && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, "" !== n && (e.name = n)
                }

                function ee(e, t, n) {
                    "number" === t && K(e.ownerDocument) === e || (null == n ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
                }
                var te = Array.isArray;

                function ne(e, t, n, r) {
                    if (e = e.options, t) {
                        t = {};
                        for (var a = 0; a < n.length; a++) t["$" + n[a]] = !0;
                        for (n = 0; n < e.length; n++) a = t.hasOwnProperty("$" + e[n].value), e[n].selected !== a && (e[n].selected = a), a && r && (e[n].defaultSelected = !0)
                    } else {
                        for (n = "" + V(n), t = null, a = 0; a < e.length; a++) {
                            if (e[a].value === n) return e[a].selected = !0, void(r && (e[a].defaultSelected = !0));
                            null !== t || e[a].disabled || (t = e[a])
                        }
                        null !== t && (t.selected = !0)
                    }
                }

                function re(e, t) {
                    if (null != t.dangerouslySetInnerHTML) throw Error(o(91));
                    return I({}, t, {
                        value: void 0,
                        defaultValue: void 0,
                        children: "" + e._wrapperState.initialValue
                    })
                }

                function ae(e, t) {
                    var n = t.value;
                    if (null == n) {
                        if (n = t.children, t = t.defaultValue, null != n) {
                            if (null != t) throw Error(o(92));
                            if (te(n)) {
                                if (1 < n.length) throw Error(o(93));
                                n = n[0]
                            }
                            t = n
                        }
                        null == t && (t = ""), n = t
                    }
                    e._wrapperState = {
                        initialValue: V(n)
                    }
                }

                function oe(e, t) {
                    var n = V(t.value),
                        r = V(t.defaultValue);
                    null != n && ((n = "" + n) !== e.value && (e.value = n), null == t.defaultValue && e.defaultValue !== n && (e.defaultValue = n)), null != r && (e.defaultValue = "" + r)
                }

                function le(e) {
                    var t = e.textContent;
                    t === e._wrapperState.initialValue && "" !== t && null !== t && (e.value = t)
                }

                function ie(e) {
                    switch (e) {
                        case "svg":
                            return "http://www.w3.org/2000/svg";
                        case "math":
                            return "http://www.w3.org/1998/Math/MathML";
                        default:
                            return "http://www.w3.org/1999/xhtml"
                    }
                }

                function se(e, t) {
                    return null == e || "http://www.w3.org/1999/xhtml" === e ? ie(t) : "http://www.w3.org/2000/svg" === e && "foreignObject" === t ? "http://www.w3.org/1999/xhtml" : e
                }
                var ue, ce, de = (ce = function(e, t) {
                    if ("http://www.w3.org/2000/svg" !== e.namespaceURI || "innerHTML" in e) e.innerHTML = t;
                    else {
                        for ((ue = ue || document.createElement("div")).innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = ue.firstChild; e.firstChild;) e.removeChild(e.firstChild);
                        for (; t.firstChild;) e.appendChild(t.firstChild)
                    }
                }, "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(e, t, n, r) {
                    MSApp.execUnsafeLocalFunction((function() {
                        return ce(e, t)
                    }))
                } : ce);

                function fe(e, t) {
                    if (t) {
                        var n = e.firstChild;
                        if (n && n === e.lastChild && 3 === n.nodeType) return void(n.nodeValue = t)
                    }
                    e.textContent = t
                }
                var pe = {
                        animationIterationCount: !0,
                        aspectRatio: !0,
                        borderImageOutset: !0,
                        borderImageSlice: !0,
                        borderImageWidth: !0,
                        boxFlex: !0,
                        boxFlexGroup: !0,
                        boxOrdinalGroup: !0,
                        columnCount: !0,
                        columns: !0,
                        flex: !0,
                        flexGrow: !0,
                        flexPositive: !0,
                        flexShrink: !0,
                        flexNegative: !0,
                        flexOrder: !0,
                        gridArea: !0,
                        gridRow: !0,
                        gridRowEnd: !0,
                        gridRowSpan: !0,
                        gridRowStart: !0,
                        gridColumn: !0,
                        gridColumnEnd: !0,
                        gridColumnSpan: !0,
                        gridColumnStart: !0,
                        fontWeight: !0,
                        lineClamp: !0,
                        lineHeight: !0,
                        opacity: !0,
                        order: !0,
                        orphans: !0,
                        tabSize: !0,
                        widows: !0,
                        zIndex: !0,
                        zoom: !0,
                        fillOpacity: !0,
                        floodOpacity: !0,
                        stopOpacity: !0,
                        strokeDasharray: !0,
                        strokeDashoffset: !0,
                        strokeMiterlimit: !0,
                        strokeOpacity: !0,
                        strokeWidth: !0
                    },
                    he = ["Webkit", "ms", "Moz", "O"];

                function me(e, t, n) {
                    return null == t || "boolean" === typeof t || "" === t ? "" : n || "number" !== typeof t || 0 === t || pe.hasOwnProperty(e) && pe[e] ? ("" + t).trim() : t + "px"
                }

                function ge(e, t) {
                    for (var n in e = e.style, t)
                        if (t.hasOwnProperty(n)) {
                            var r = 0 === n.indexOf("--"),
                                a = me(n, t[n], r);
                            "float" === n && (n = "cssFloat"), r ? e.setProperty(n, a) : e[n] = a
                        }
                }
                Object.keys(pe).forEach((function(e) {
                    he.forEach((function(t) {
                        t = t + e.charAt(0).toUpperCase() + e.substring(1), pe[t] = pe[e]
                    }))
                }));
                var ye = I({
                    menuitem: !0
                }, {
                    area: !0,
                    base: !0,
                    br: !0,
                    col: !0,
                    embed: !0,
                    hr: !0,
                    img: !0,
                    input: !0,
                    keygen: !0,
                    link: !0,
                    meta: !0,
                    param: !0,
                    source: !0,
                    track: !0,
                    wbr: !0
                });

                function ve(e, t) {
                    if (t) {
                        if (ye[e] && (null != t.children || null != t.dangerouslySetInnerHTML)) throw Error(o(137, e));
                        if (null != t.dangerouslySetInnerHTML) {
                            if (null != t.children) throw Error(o(60));
                            if ("object" !== typeof t.dangerouslySetInnerHTML || !("__html" in t.dangerouslySetInnerHTML)) throw Error(o(61))
                        }
                        if (null != t.style && "object" !== typeof t.style) throw Error(o(62))
                    }
                }

                function be(e, t) {
                    if (-1 === e.indexOf("-")) return "string" === typeof t.is;
                    switch (e) {
                        case "annotation-xml":
                        case "color-profile":
                        case "font-face":
                        case "font-face-src":
                        case "font-face-uri":
                        case "font-face-format":
                        case "font-face-name":
                        case "missing-glyph":
                            return !1;
                        default:
                            return !0
                    }
                }
                var we = null;

                function xe(e) {
                    return (e = e.target || e.srcElement || window).correspondingUseElement && (e = e.correspondingUseElement), 3 === e.nodeType ? e.parentNode : e
                }
                var Se = null,
                    ke = null,
                    Ee = null;

                function Ce(e) {
                    if (e = ba(e)) {
                        if ("function" !== typeof Se) throw Error(o(280));
                        var t = e.stateNode;
                        t && (t = xa(t), Se(e.stateNode, e.type, t))
                    }
                }

                function Ne(e) {
                    ke ? Ee ? Ee.push(e) : Ee = [e] : ke = e
                }

                function je() {
                    if (ke) {
                        var e = ke,
                            t = Ee;
                        if (Ee = ke = null, Ce(e), t)
                            for (e = 0; e < t.length; e++) Ce(t[e])
                    }
                }

                function _e(e, t) {
                    return e(t)
                }

                function Te() {}
                var Pe = !1;

                function Oe(e, t, n) {
                    if (Pe) return e(t, n);
                    Pe = !0;
                    try {
                        return _e(e, t, n)
                    } finally {
                        Pe = !1, (null !== ke || null !== Ee) && (Te(), je())
                    }
                }

                function Re(e, t) {
                    var n = e.stateNode;
                    if (null === n) return null;
                    var r = xa(n);
                    if (null === r) return null;
                    n = r[t];
                    e: switch (t) {
                        case "onClick":
                        case "onClickCapture":
                        case "onDoubleClick":
                        case "onDoubleClickCapture":
                        case "onMouseDown":
                        case "onMouseDownCapture":
                        case "onMouseMove":
                        case "onMouseMoveCapture":
                        case "onMouseUp":
                        case "onMouseUpCapture":
                        case "onMouseEnter":
                            (r = !r.disabled) || (r = !("button" === (e = e.type) || "input" === e || "select" === e || "textarea" === e)), e = !r;
                            break e;
                        default:
                            e = !1
                    }
                    if (e) return null;
                    if (n && "function" !== typeof n) throw Error(o(231, t, typeof n));
                    return n
                }
                var Le = !1;
                if (c) try {
                    var ze = {};
                    Object.defineProperty(ze, "passive", {
                        get: function() {
                            Le = !0
                        }
                    }), window.addEventListener("test", ze, ze), window.removeEventListener("test", ze, ze)
                } catch (ce) {
                    Le = !1
                }

                function De(e, t, n, r, a, o, l, i, s) {
                    var u = Array.prototype.slice.call(arguments, 3);
                    try {
                        t.apply(n, u)
                    } catch (c) {
                        this.onError(c)
                    }
                }
                var Ae = !1,
                    Ie = null,
                    Fe = !1,
                    Ue = null,
                    Me = {
                        onError: function(e) {
                            Ae = !0, Ie = e
                        }
                    };

                function Be(e, t, n, r, a, o, l, i, s) {
                    Ae = !1, Ie = null, De.apply(Me, arguments)
                }

                function He(e) {
                    var t = e,
                        n = e;
                    if (e.alternate)
                        for (; t.return;) t = t.return;
                    else {
                        e = t;
                        do {
                            0 !== (4098 & (t = e).flags) && (n = t.return), e = t.return
                        } while (e)
                    }
                    return 3 === t.tag ? n : null
                }

                function We(e) {
                    if (13 === e.tag) {
                        var t = e.memoizedState;
                        if (null === t && (null !== (e = e.alternate) && (t = e.memoizedState)), null !== t) return t.dehydrated
                    }
                    return null
                }

                function Ve(e) {
                    if (He(e) !== e) throw Error(o(188))
                }

                function $e(e) {
                    return null !== (e = function(e) {
                        var t = e.alternate;
                        if (!t) {
                            if (null === (t = He(e))) throw Error(o(188));
                            return t !== e ? null : e
                        }
                        for (var n = e, r = t;;) {
                            var a = n.return;
                            if (null === a) break;
                            var l = a.alternate;
                            if (null === l) {
                                if (null !== (r = a.return)) {
                                    n = r;
                                    continue
                                }
                                break
                            }
                            if (a.child === l.child) {
                                for (l = a.child; l;) {
                                    if (l === n) return Ve(a), e;
                                    if (l === r) return Ve(a), t;
                                    l = l.sibling
                                }
                                throw Error(o(188))
                            }
                            if (n.return !== r.return) n = a, r = l;
                            else {
                                for (var i = !1, s = a.child; s;) {
                                    if (s === n) {
                                        i = !0, n = a, r = l;
                                        break
                                    }
                                    if (s === r) {
                                        i = !0, r = a, n = l;
                                        break
                                    }
                                    s = s.sibling
                                }
                                if (!i) {
                                    for (s = l.child; s;) {
                                        if (s === n) {
                                            i = !0, n = l, r = a;
                                            break
                                        }
                                        if (s === r) {
                                            i = !0, r = l, n = a;
                                            break
                                        }
                                        s = s.sibling
                                    }
                                    if (!i) throw Error(o(189))
                                }
                            }
                            if (n.alternate !== r) throw Error(o(190))
                        }
                        if (3 !== n.tag) throw Error(o(188));
                        return n.stateNode.current === n ? e : t
                    }(e)) ? qe(e) : null
                }

                function qe(e) {
                    if (5 === e.tag || 6 === e.tag) return e;
                    for (e = e.child; null !== e;) {
                        var t = qe(e);
                        if (null !== t) return t;
                        e = e.sibling
                    }
                    return null
                }
                var Qe = a.unstable_scheduleCallback,
                    Ke = a.unstable_cancelCallback,
                    Ge = a.unstable_shouldYield,
                    Je = a.unstable_requestPaint,
                    Xe = a.unstable_now,
                    Ye = a.unstable_getCurrentPriorityLevel,
                    Ze = a.unstable_ImmediatePriority,
                    et = a.unstable_UserBlockingPriority,
                    tt = a.unstable_NormalPriority,
                    nt = a.unstable_LowPriority,
                    rt = a.unstable_IdlePriority,
                    at = null,
                    ot = null;
                var lt = Math.clz32 ? Math.clz32 : function(e) {
                        return e >>>= 0, 0 === e ? 32 : 31 - (it(e) / st | 0) | 0
                    },
                    it = Math.log,
                    st = Math.LN2;
                var ut = 64,
                    ct = 4194304;

                function dt(e) {
                    switch (e & -e) {
                        case 1:
                            return 1;
                        case 2:
                            return 2;
                        case 4:
                            return 4;
                        case 8:
                            return 8;
                        case 16:
                            return 16;
                        case 32:
                            return 32;
                        case 64:
                        case 128:
                        case 256:
                        case 512:
                        case 1024:
                        case 2048:
                        case 4096:
                        case 8192:
                        case 16384:
                        case 32768:
                        case 65536:
                        case 131072:
                        case 262144:
                        case 524288:
                        case 1048576:
                        case 2097152:
                            return 4194240 & e;
                        case 4194304:
                        case 8388608:
                        case 16777216:
                        case 33554432:
                        case 67108864:
                            return 130023424 & e;
                        case 134217728:
                            return 134217728;
                        case 268435456:
                            return 268435456;
                        case 536870912:
                            return 536870912;
                        case 1073741824:
                            return 1073741824;
                        default:
                            return e
                    }
                }

                function ft(e, t) {
                    var n = e.pendingLanes;
                    if (0 === n) return 0;
                    var r = 0,
                        a = e.suspendedLanes,
                        o = e.pingedLanes,
                        l = 268435455 & n;
                    if (0 !== l) {
                        var i = l & ~a;
                        0 !== i ? r = dt(i) : 0 !== (o &= l) && (r = dt(o))
                    } else 0 !== (l = n & ~a) ? r = dt(l) : 0 !== o && (r = dt(o));
                    if (0 === r) return 0;
                    if (0 !== t && t !== r && 0 === (t & a) && ((a = r & -r) >= (o = t & -t) || 16 === a && 0 !== (4194240 & o))) return t;
                    if (0 !== (4 & r) && (r |= 16 & n), 0 !== (t = e.entangledLanes))
                        for (e = e.entanglements, t &= r; 0 < t;) a = 1 << (n = 31 - lt(t)), r |= e[n], t &= ~a;
                    return r
                }

                function pt(e, t) {
                    switch (e) {
                        case 1:
                        case 2:
                        case 4:
                            return t + 250;
                        case 8:
                        case 16:
                        case 32:
                        case 64:
                        case 128:
                        case 256:
                        case 512:
                        case 1024:
                        case 2048:
                        case 4096:
                        case 8192:
                        case 16384:
                        case 32768:
                        case 65536:
                        case 131072:
                        case 262144:
                        case 524288:
                        case 1048576:
                        case 2097152:
                            return t + 5e3;
                        default:
                            return -1
                    }
                }

                function ht(e) {
                    return 0 !== (e = -1073741825 & e.pendingLanes) ? e : 1073741824 & e ? 1073741824 : 0
                }

                function mt() {
                    var e = ut;
                    return 0 === (4194240 & (ut <<= 1)) && (ut = 64), e
                }

                function gt(e) {
                    for (var t = [], n = 0; 31 > n; n++) t.push(e);
                    return t
                }

                function yt(e, t, n) {
                    e.pendingLanes |= t, 536870912 !== t && (e.suspendedLanes = 0, e.pingedLanes = 0), (e = e.eventTimes)[t = 31 - lt(t)] = n
                }

                function vt(e, t) {
                    var n = e.entangledLanes |= t;
                    for (e = e.entanglements; n;) {
                        var r = 31 - lt(n),
                            a = 1 << r;
                        a & t | e[r] & t && (e[r] |= t), n &= ~a
                    }
                }
                var bt = 0;

                function wt(e) {
                    return 1 < (e &= -e) ? 4 < e ? 0 !== (268435455 & e) ? 16 : 536870912 : 4 : 1
                }
                var xt, St, kt, Et, Ct, Nt = !1,
                    jt = [],
                    _t = null,
                    Tt = null,
                    Pt = null,
                    Ot = new Map,
                    Rt = new Map,
                    Lt = [],
                    zt = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

                function Dt(e, t) {
                    switch (e) {
                        case "focusin":
                        case "focusout":
                            _t = null;
                            break;
                        case "dragenter":
                        case "dragleave":
                            Tt = null;
                            break;
                        case "mouseover":
                        case "mouseout":
                            Pt = null;
                            break;
                        case "pointerover":
                        case "pointerout":
                            Ot.delete(t.pointerId);
                            break;
                        case "gotpointercapture":
                        case "lostpointercapture":
                            Rt.delete(t.pointerId)
                    }
                }

                function At(e, t, n, r, a, o) {
                    return null === e || e.nativeEvent !== o ? (e = {
                        blockedOn: t,
                        domEventName: n,
                        eventSystemFlags: r,
                        nativeEvent: o,
                        targetContainers: [a]
                    }, null !== t && (null !== (t = ba(t)) && St(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, null !== a && -1 === t.indexOf(a) && t.push(a), e)
                }

                function It(e) {
                    var t = va(e.target);
                    if (null !== t) {
                        var n = He(t);
                        if (null !== n)
                            if (13 === (t = n.tag)) {
                                if (null !== (t = We(n))) return e.blockedOn = t, void Ct(e.priority, (function() {
                                    kt(n)
                                }))
                            } else if (3 === t && n.stateNode.current.memoizedState.isDehydrated) return void(e.blockedOn = 3 === n.tag ? n.stateNode.containerInfo : null)
                    }
                    e.blockedOn = null
                }

                function Ft(e) {
                    if (null !== e.blockedOn) return !1;
                    for (var t = e.targetContainers; 0 < t.length;) {
                        var n = Gt(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
                        if (null !== n) return null !== (t = ba(n)) && St(t), e.blockedOn = n, !1;
                        var r = new(n = e.nativeEvent).constructor(n.type, n);
                        we = r, n.target.dispatchEvent(r), we = null, t.shift()
                    }
                    return !0
                }

                function Ut(e, t, n) {
                    Ft(e) && n.delete(t)
                }

                function Mt() {
                    Nt = !1, null !== _t && Ft(_t) && (_t = null), null !== Tt && Ft(Tt) && (Tt = null), null !== Pt && Ft(Pt) && (Pt = null), Ot.forEach(Ut), Rt.forEach(Ut)
                }

                function Bt(e, t) {
                    e.blockedOn === t && (e.blockedOn = null, Nt || (Nt = !0, a.unstable_scheduleCallback(a.unstable_NormalPriority, Mt)))
                }

                function Ht(e) {
                    function t(t) {
                        return Bt(t, e)
                    }
                    if (0 < jt.length) {
                        Bt(jt[0], e);
                        for (var n = 1; n < jt.length; n++) {
                            var r = jt[n];
                            r.blockedOn === e && (r.blockedOn = null)
                        }
                    }
                    for (null !== _t && Bt(_t, e), null !== Tt && Bt(Tt, e), null !== Pt && Bt(Pt, e), Ot.forEach(t), Rt.forEach(t), n = 0; n < Lt.length; n++)(r = Lt[n]).blockedOn === e && (r.blockedOn = null);
                    for (; 0 < Lt.length && null === (n = Lt[0]).blockedOn;) It(n), null === n.blockedOn && Lt.shift()
                }
                var Wt = w.ReactCurrentBatchConfig,
                    Vt = !0;

                function $t(e, t, n, r) {
                    var a = bt,
                        o = Wt.transition;
                    Wt.transition = null;
                    try {
                        bt = 1, Qt(e, t, n, r)
                    } finally {
                        bt = a, Wt.transition = o
                    }
                }

                function qt(e, t, n, r) {
                    var a = bt,
                        o = Wt.transition;
                    Wt.transition = null;
                    try {
                        bt = 4, Qt(e, t, n, r)
                    } finally {
                        bt = a, Wt.transition = o
                    }
                }

                function Qt(e, t, n, r) {
                    if (Vt) {
                        var a = Gt(e, t, n, r);
                        if (null === a) Vr(e, t, r, Kt, n), Dt(e, r);
                        else if (function(e, t, n, r, a) {
                                switch (t) {
                                    case "focusin":
                                        return _t = At(_t, e, t, n, r, a), !0;
                                    case "dragenter":
                                        return Tt = At(Tt, e, t, n, r, a), !0;
                                    case "mouseover":
                                        return Pt = At(Pt, e, t, n, r, a), !0;
                                    case "pointerover":
                                        var o = a.pointerId;
                                        return Ot.set(o, At(Ot.get(o) || null, e, t, n, r, a)), !0;
                                    case "gotpointercapture":
                                        return o = a.pointerId, Rt.set(o, At(Rt.get(o) || null, e, t, n, r, a)), !0
                                }
                                return !1
                            }(a, e, t, n, r)) r.stopPropagation();
                        else if (Dt(e, r), 4 & t && -1 < zt.indexOf(e)) {
                            for (; null !== a;) {
                                var o = ba(a);
                                if (null !== o && xt(o), null === (o = Gt(e, t, n, r)) && Vr(e, t, r, Kt, n), o === a) break;
                                a = o
                            }
                            null !== a && r.stopPropagation()
                        } else Vr(e, t, r, null, n)
                    }
                }
                var Kt = null;

                function Gt(e, t, n, r) {
                    if (Kt = null, null !== (e = va(e = xe(r))))
                        if (null === (t = He(e))) e = null;
                        else if (13 === (n = t.tag)) {
                        if (null !== (e = We(t))) return e;
                        e = null
                    } else if (3 === n) {
                        if (t.stateNode.current.memoizedState.isDehydrated) return 3 === t.tag ? t.stateNode.containerInfo : null;
                        e = null
                    } else t !== e && (e = null);
                    return Kt = e, null
                }

                function Jt(e) {
                    switch (e) {
                        case "cancel":
                        case "click":
                        case "close":
                        case "contextmenu":
                        case "copy":
                        case "cut":
                        case "auxclick":
                        case "dblclick":
                        case "dragend":
                        case "dragstart":
                        case "drop":
                        case "focusin":
                        case "focusout":
                        case "input":
                        case "invalid":
                        case "keydown":
                        case "keypress":
                        case "keyup":
                        case "mousedown":
                        case "mouseup":
                        case "paste":
                        case "pause":
                        case "play":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointerup":
                        case "ratechange":
                        case "reset":
                        case "resize":
                        case "seeked":
                        case "submit":
                        case "touchcancel":
                        case "touchend":
                        case "touchstart":
                        case "volumechange":
                        case "change":
                        case "selectionchange":
                        case "textInput":
                        case "compositionstart":
                        case "compositionend":
                        case "compositionupdate":
                        case "beforeblur":
                        case "afterblur":
                        case "beforeinput":
                        case "blur":
                        case "fullscreenchange":
                        case "focus":
                        case "hashchange":
                        case "popstate":
                        case "select":
                        case "selectstart":
                            return 1;
                        case "drag":
                        case "dragenter":
                        case "dragexit":
                        case "dragleave":
                        case "dragover":
                        case "mousemove":
                        case "mouseout":
                        case "mouseover":
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "scroll":
                        case "toggle":
                        case "touchmove":
                        case "wheel":
                        case "mouseenter":
                        case "mouseleave":
                        case "pointerenter":
                        case "pointerleave":
                            return 4;
                        case "message":
                            switch (Ye()) {
                                case Ze:
                                    return 1;
                                case et:
                                    return 4;
                                case tt:
                                case nt:
                                    return 16;
                                case rt:
                                    return 536870912;
                                default:
                                    return 16
                            }
                        default:
                            return 16
                    }
                }
                var Xt = null,
                    Yt = null,
                    Zt = null;

                function en() {
                    if (Zt) return Zt;
                    var e, t, n = Yt,
                        r = n.length,
                        a = "value" in Xt ? Xt.value : Xt.textContent,
                        o = a.length;
                    for (e = 0; e < r && n[e] === a[e]; e++);
                    var l = r - e;
                    for (t = 1; t <= l && n[r - t] === a[o - t]; t++);
                    return Zt = a.slice(e, 1 < t ? 1 - t : void 0)
                }

                function tn(e) {
                    var t = e.keyCode;
                    return "charCode" in e ? 0 === (e = e.charCode) && 13 === t && (e = 13) : e = t, 10 === e && (e = 13), 32 <= e || 13 === e ? e : 0
                }

                function nn() {
                    return !0
                }

                function rn() {
                    return !1
                }

                function an(e) {
                    function t(t, n, r, a, o) {
                        for (var l in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = a, this.target = o, this.currentTarget = null, e) e.hasOwnProperty(l) && (t = e[l], this[l] = t ? t(a) : a[l]);
                        return this.isDefaultPrevented = (null != a.defaultPrevented ? a.defaultPrevented : !1 === a.returnValue) ? nn : rn, this.isPropagationStopped = rn, this
                    }
                    return I(t.prototype, {
                        preventDefault: function() {
                            this.defaultPrevented = !0;
                            var e = this.nativeEvent;
                            e && (e.preventDefault ? e.preventDefault() : "unknown" !== typeof e.returnValue && (e.returnValue = !1), this.isDefaultPrevented = nn)
                        },
                        stopPropagation: function() {
                            var e = this.nativeEvent;
                            e && (e.stopPropagation ? e.stopPropagation() : "unknown" !== typeof e.cancelBubble && (e.cancelBubble = !0), this.isPropagationStopped = nn)
                        },
                        persist: function() {},
                        isPersistent: nn
                    }), t
                }
                var on, ln, sn, un = {
                        eventPhase: 0,
                        bubbles: 0,
                        cancelable: 0,
                        timeStamp: function(e) {
                            return e.timeStamp || Date.now()
                        },
                        defaultPrevented: 0,
                        isTrusted: 0
                    },
                    cn = an(un),
                    dn = I({}, un, {
                        view: 0,
                        detail: 0
                    }),
                    fn = an(dn),
                    pn = I({}, dn, {
                        screenX: 0,
                        screenY: 0,
                        clientX: 0,
                        clientY: 0,
                        pageX: 0,
                        pageY: 0,
                        ctrlKey: 0,
                        shiftKey: 0,
                        altKey: 0,
                        metaKey: 0,
                        getModifierState: Cn,
                        button: 0,
                        buttons: 0,
                        relatedTarget: function(e) {
                            return void 0 === e.relatedTarget ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
                        },
                        movementX: function(e) {
                            return "movementX" in e ? e.movementX : (e !== sn && (sn && "mousemove" === e.type ? (on = e.screenX - sn.screenX, ln = e.screenY - sn.screenY) : ln = on = 0, sn = e), on)
                        },
                        movementY: function(e) {
                            return "movementY" in e ? e.movementY : ln
                        }
                    }),
                    hn = an(pn),
                    mn = an(I({}, pn, {
                        dataTransfer: 0
                    })),
                    gn = an(I({}, dn, {
                        relatedTarget: 0
                    })),
                    yn = an(I({}, un, {
                        animationName: 0,
                        elapsedTime: 0,
                        pseudoElement: 0
                    })),
                    vn = I({}, un, {
                        clipboardData: function(e) {
                            return "clipboardData" in e ? e.clipboardData : window.clipboardData
                        }
                    }),
                    bn = an(vn),
                    wn = an(I({}, un, {
                        data: 0
                    })),
                    xn = {
                        Esc: "Escape",
                        Spacebar: " ",
                        Left: "ArrowLeft",
                        Up: "ArrowUp",
                        Right: "ArrowRight",
                        Down: "ArrowDown",
                        Del: "Delete",
                        Win: "OS",
                        Menu: "ContextMenu",
                        Apps: "ContextMenu",
                        Scroll: "ScrollLock",
                        MozPrintableKey: "Unidentified"
                    },
                    Sn = {
                        8: "Backspace",
                        9: "Tab",
                        12: "Clear",
                        13: "Enter",
                        16: "Shift",
                        17: "Control",
                        18: "Alt",
                        19: "Pause",
                        20: "CapsLock",
                        27: "Escape",
                        32: " ",
                        33: "PageUp",
                        34: "PageDown",
                        35: "End",
                        36: "Home",
                        37: "ArrowLeft",
                        38: "ArrowUp",
                        39: "ArrowRight",
                        40: "ArrowDown",
                        45: "Insert",
                        46: "Delete",
                        112: "F1",
                        113: "F2",
                        114: "F3",
                        115: "F4",
                        116: "F5",
                        117: "F6",
                        118: "F7",
                        119: "F8",
                        120: "F9",
                        121: "F10",
                        122: "F11",
                        123: "F12",
                        144: "NumLock",
                        145: "ScrollLock",
                        224: "Meta"
                    },
                    kn = {
                        Alt: "altKey",
                        Control: "ctrlKey",
                        Meta: "metaKey",
                        Shift: "shiftKey"
                    };

                function En(e) {
                    var t = this.nativeEvent;
                    return t.getModifierState ? t.getModifierState(e) : !!(e = kn[e]) && !!t[e]
                }

                function Cn() {
                    return En
                }
                var Nn = I({}, dn, {
                        key: function(e) {
                            if (e.key) {
                                var t = xn[e.key] || e.key;
                                if ("Unidentified" !== t) return t
                            }
                            return "keypress" === e.type ? 13 === (e = tn(e)) ? "Enter" : String.fromCharCode(e) : "keydown" === e.type || "keyup" === e.type ? Sn[e.keyCode] || "Unidentified" : ""
                        },
                        code: 0,
                        location: 0,
                        ctrlKey: 0,
                        shiftKey: 0,
                        altKey: 0,
                        metaKey: 0,
                        repeat: 0,
                        locale: 0,
                        getModifierState: Cn,
                        charCode: function(e) {
                            return "keypress" === e.type ? tn(e) : 0
                        },
                        keyCode: function(e) {
                            return "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
                        },
                        which: function(e) {
                            return "keypress" === e.type ? tn(e) : "keydown" === e.type || "keyup" === e.type ? e.keyCode : 0
                        }
                    }),
                    jn = an(Nn),
                    _n = an(I({}, pn, {
                        pointerId: 0,
                        width: 0,
                        height: 0,
                        pressure: 0,
                        tangentialPressure: 0,
                        tiltX: 0,
                        tiltY: 0,
                        twist: 0,
                        pointerType: 0,
                        isPrimary: 0
                    })),
                    Tn = an(I({}, dn, {
                        touches: 0,
                        targetTouches: 0,
                        changedTouches: 0,
                        altKey: 0,
                        metaKey: 0,
                        ctrlKey: 0,
                        shiftKey: 0,
                        getModifierState: Cn
                    })),
                    Pn = an(I({}, un, {
                        propertyName: 0,
                        elapsedTime: 0,
                        pseudoElement: 0
                    })),
                    On = I({}, pn, {
                        deltaX: function(e) {
                            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
                        },
                        deltaY: function(e) {
                            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
                        },
                        deltaZ: 0,
                        deltaMode: 0
                    }),
                    Rn = an(On),
                    Ln = [9, 13, 27, 32],
                    zn = c && "CompositionEvent" in window,
                    Dn = null;
                c && "documentMode" in document && (Dn = document.documentMode);
                var An = c && "TextEvent" in window && !Dn,
                    In = c && (!zn || Dn && 8 < Dn && 11 >= Dn),
                    Fn = String.fromCharCode(32),
                    Un = !1;

                function Mn(e, t) {
                    switch (e) {
                        case "keyup":
                            return -1 !== Ln.indexOf(t.keyCode);
                        case "keydown":
                            return 229 !== t.keyCode;
                        case "keypress":
                        case "mousedown":
                        case "focusout":
                            return !0;
                        default:
                            return !1
                    }
                }

                function Bn(e) {
                    return "object" === typeof(e = e.detail) && "data" in e ? e.data : null
                }
                var Hn = !1;
                var Wn = {
                    color: !0,
                    date: !0,
                    datetime: !0,
                    "datetime-local": !0,
                    email: !0,
                    month: !0,
                    number: !0,
                    password: !0,
                    range: !0,
                    search: !0,
                    tel: !0,
                    text: !0,
                    time: !0,
                    url: !0,
                    week: !0
                };

                function Vn(e) {
                    var t = e && e.nodeName && e.nodeName.toLowerCase();
                    return "input" === t ? !!Wn[e.type] : "textarea" === t
                }

                function $n(e, t, n, r) {
                    Ne(r), 0 < (t = qr(t, "onChange")).length && (n = new cn("onChange", "change", null, n, r), e.push({
                        event: n,
                        listeners: t
                    }))
                }
                var qn = null,
                    Qn = null;

                function Kn(e) {
                    Fr(e, 0)
                }

                function Gn(e) {
                    if (Q(wa(e))) return e
                }

                function Jn(e, t) {
                    if ("change" === e) return t
                }
                var Xn = !1;
                if (c) {
                    var Yn;
                    if (c) {
                        var Zn = "oninput" in document;
                        if (!Zn) {
                            var er = document.createElement("div");
                            er.setAttribute("oninput", "return;"), Zn = "function" === typeof er.oninput
                        }
                        Yn = Zn
                    } else Yn = !1;
                    Xn = Yn && (!document.documentMode || 9 < document.documentMode)
                }

                function tr() {
                    qn && (qn.detachEvent("onpropertychange", nr), Qn = qn = null)
                }

                function nr(e) {
                    if ("value" === e.propertyName && Gn(Qn)) {
                        var t = [];
                        $n(t, Qn, e, xe(e)), Oe(Kn, t)
                    }
                }

                function rr(e, t, n) {
                    "focusin" === e ? (tr(), Qn = n, (qn = t).attachEvent("onpropertychange", nr)) : "focusout" === e && tr()
                }

                function ar(e) {
                    if ("selectionchange" === e || "keyup" === e || "keydown" === e) return Gn(Qn)
                }

                function or(e, t) {
                    if ("click" === e) return Gn(t)
                }

                function lr(e, t) {
                    if ("input" === e || "change" === e) return Gn(t)
                }
                var ir = "function" === typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e === 1 / t) || e !== e && t !== t
                };

                function sr(e, t) {
                    if (ir(e, t)) return !0;
                    if ("object" !== typeof e || null === e || "object" !== typeof t || null === t) return !1;
                    var n = Object.keys(e),
                        r = Object.keys(t);
                    if (n.length !== r.length) return !1;
                    for (r = 0; r < n.length; r++) {
                        var a = n[r];
                        if (!d.call(t, a) || !ir(e[a], t[a])) return !1
                    }
                    return !0
                }

                function ur(e) {
                    for (; e && e.firstChild;) e = e.firstChild;
                    return e
                }

                function cr(e, t) {
                    var n, r = ur(e);
                    for (e = 0; r;) {
                        if (3 === r.nodeType) {
                            if (n = e + r.textContent.length, e <= t && n >= t) return {
                                node: r,
                                offset: t - e
                            };
                            e = n
                        }
                        e: {
                            for (; r;) {
                                if (r.nextSibling) {
                                    r = r.nextSibling;
                                    break e
                                }
                                r = r.parentNode
                            }
                            r = void 0
                        }
                        r = ur(r)
                    }
                }

                function dr(e, t) {
                    return !(!e || !t) && (e === t || (!e || 3 !== e.nodeType) && (t && 3 === t.nodeType ? dr(e, t.parentNode) : "contains" in e ? e.contains(t) : !!e.compareDocumentPosition && !!(16 & e.compareDocumentPosition(t))))
                }

                function fr() {
                    for (var e = window, t = K(); t instanceof e.HTMLIFrameElement;) {
                        try {
                            var n = "string" === typeof t.contentWindow.location.href
                        } catch (r) {
                            n = !1
                        }
                        if (!n) break;
                        t = K((e = t.contentWindow).document)
                    }
                    return t
                }

                function pr(e) {
                    var t = e && e.nodeName && e.nodeName.toLowerCase();
                    return t && ("input" === t && ("text" === e.type || "search" === e.type || "tel" === e.type || "url" === e.type || "password" === e.type) || "textarea" === t || "true" === e.contentEditable)
                }

                function hr(e) {
                    var t = fr(),
                        n = e.focusedElem,
                        r = e.selectionRange;
                    if (t !== n && n && n.ownerDocument && dr(n.ownerDocument.documentElement, n)) {
                        if (null !== r && pr(n))
                            if (t = r.start, void 0 === (e = r.end) && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
                            else if ((e = (t = n.ownerDocument || document) && t.defaultView || window).getSelection) {
                            e = e.getSelection();
                            var a = n.textContent.length,
                                o = Math.min(r.start, a);
                            r = void 0 === r.end ? o : Math.min(r.end, a), !e.extend && o > r && (a = r, r = o, o = a), a = cr(n, o);
                            var l = cr(n, r);
                            a && l && (1 !== e.rangeCount || e.anchorNode !== a.node || e.anchorOffset !== a.offset || e.focusNode !== l.node || e.focusOffset !== l.offset) && ((t = t.createRange()).setStart(a.node, a.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(l.node, l.offset)) : (t.setEnd(l.node, l.offset), e.addRange(t)))
                        }
                        for (t = [], e = n; e = e.parentNode;) 1 === e.nodeType && t.push({
                            element: e,
                            left: e.scrollLeft,
                            top: e.scrollTop
                        });
                        for ("function" === typeof n.focus && n.focus(), n = 0; n < t.length; n++)(e = t[n]).element.scrollLeft = e.left, e.element.scrollTop = e.top
                    }
                }
                var mr = c && "documentMode" in document && 11 >= document.documentMode,
                    gr = null,
                    yr = null,
                    vr = null,
                    br = !1;

                function wr(e, t, n) {
                    var r = n.window === n ? n.document : 9 === n.nodeType ? n : n.ownerDocument;
                    br || null == gr || gr !== K(r) || ("selectionStart" in (r = gr) && pr(r) ? r = {
                        start: r.selectionStart,
                        end: r.selectionEnd
                    } : r = {
                        anchorNode: (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection()).anchorNode,
                        anchorOffset: r.anchorOffset,
                        focusNode: r.focusNode,
                        focusOffset: r.focusOffset
                    }, vr && sr(vr, r) || (vr = r, 0 < (r = qr(yr, "onSelect")).length && (t = new cn("onSelect", "select", null, t, n), e.push({
                        event: t,
                        listeners: r
                    }), t.target = gr)))
                }

                function xr(e, t) {
                    var n = {};
                    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
                }
                var Sr = {
                        animationend: xr("Animation", "AnimationEnd"),
                        animationiteration: xr("Animation", "AnimationIteration"),
                        animationstart: xr("Animation", "AnimationStart"),
                        transitionend: xr("Transition", "TransitionEnd")
                    },
                    kr = {},
                    Er = {};

                function Cr(e) {
                    if (kr[e]) return kr[e];
                    if (!Sr[e]) return e;
                    var t, n = Sr[e];
                    for (t in n)
                        if (n.hasOwnProperty(t) && t in Er) return kr[e] = n[t];
                    return e
                }
                c && (Er = document.createElement("div").style, "AnimationEvent" in window || (delete Sr.animationend.animation, delete Sr.animationiteration.animation, delete Sr.animationstart.animation), "TransitionEvent" in window || delete Sr.transitionend.transition);
                var Nr = Cr("animationend"),
                    jr = Cr("animationiteration"),
                    _r = Cr("animationstart"),
                    Tr = Cr("transitionend"),
                    Pr = new Map,
                    Or = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

                function Rr(e, t) {
                    Pr.set(e, t), s(t, [e])
                }
                for (var Lr = 0; Lr < Or.length; Lr++) {
                    var zr = Or[Lr];
                    Rr(zr.toLowerCase(), "on" + (zr[0].toUpperCase() + zr.slice(1)))
                }
                Rr(Nr, "onAnimationEnd"), Rr(jr, "onAnimationIteration"), Rr(_r, "onAnimationStart"), Rr("dblclick", "onDoubleClick"), Rr("focusin", "onFocus"), Rr("focusout", "onBlur"), Rr(Tr, "onTransitionEnd"), u("onMouseEnter", ["mouseout", "mouseover"]), u("onMouseLeave", ["mouseout", "mouseover"]), u("onPointerEnter", ["pointerout", "pointerover"]), u("onPointerLeave", ["pointerout", "pointerover"]), s("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), s("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), s("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), s("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), s("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), s("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
                var Dr = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
                    Ar = new Set("cancel close invalid load scroll toggle".split(" ").concat(Dr));

                function Ir(e, t, n) {
                    var r = e.type || "unknown-event";
                    e.currentTarget = n,
                        function(e, t, n, r, a, l, i, s, u) {
                            if (Be.apply(this, arguments), Ae) {
                                if (!Ae) throw Error(o(198));
                                var c = Ie;
                                Ae = !1, Ie = null, Fe || (Fe = !0, Ue = c)
                            }
                        }(r, t, void 0, e), e.currentTarget = null
                }

                function Fr(e, t) {
                    t = 0 !== (4 & t);
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n],
                            a = r.event;
                        r = r.listeners;
                        e: {
                            var o = void 0;
                            if (t)
                                for (var l = r.length - 1; 0 <= l; l--) {
                                    var i = r[l],
                                        s = i.instance,
                                        u = i.currentTarget;
                                    if (i = i.listener, s !== o && a.isPropagationStopped()) break e;
                                    Ir(a, i, u), o = s
                                } else
                                    for (l = 0; l < r.length; l++) {
                                        if (s = (i = r[l]).instance, u = i.currentTarget, i = i.listener, s !== o && a.isPropagationStopped()) break e;
                                        Ir(a, i, u), o = s
                                    }
                        }
                    }
                    if (Fe) throw e = Ue, Fe = !1, Ue = null, e
                }

                function Ur(e, t) {
                    var n = t[ma];
                    void 0 === n && (n = t[ma] = new Set);
                    var r = e + "__bubble";
                    n.has(r) || (Wr(t, e, 2, !1), n.add(r))
                }

                function Mr(e, t, n) {
                    var r = 0;
                    t && (r |= 4), Wr(n, e, r, t)
                }
                var Br = "_reactListening" + Math.random().toString(36).slice(2);

                function Hr(e) {
                    if (!e[Br]) {
                        e[Br] = !0, l.forEach((function(t) {
                            "selectionchange" !== t && (Ar.has(t) || Mr(t, !1, e), Mr(t, !0, e))
                        }));
                        var t = 9 === e.nodeType ? e : e.ownerDocument;
                        null === t || t[Br] || (t[Br] = !0, Mr("selectionchange", !1, t))
                    }
                }

                function Wr(e, t, n, r) {
                    switch (Jt(t)) {
                        case 1:
                            var a = $t;
                            break;
                        case 4:
                            a = qt;
                            break;
                        default:
                            a = Qt
                    }
                    n = a.bind(null, t, n, e), a = void 0, !Le || "touchstart" !== t && "touchmove" !== t && "wheel" !== t || (a = !0), r ? void 0 !== a ? e.addEventListener(t, n, {
                        capture: !0,
                        passive: a
                    }) : e.addEventListener(t, n, !0) : void 0 !== a ? e.addEventListener(t, n, {
                        passive: a
                    }) : e.addEventListener(t, n, !1)
                }

                function Vr(e, t, n, r, a) {
                    var o = r;
                    if (0 === (1 & t) && 0 === (2 & t) && null !== r) e: for (;;) {
                        if (null === r) return;
                        var l = r.tag;
                        if (3 === l || 4 === l) {
                            var i = r.stateNode.containerInfo;
                            if (i === a || 8 === i.nodeType && i.parentNode === a) break;
                            if (4 === l)
                                for (l = r.return; null !== l;) {
                                    var s = l.tag;
                                    if ((3 === s || 4 === s) && ((s = l.stateNode.containerInfo) === a || 8 === s.nodeType && s.parentNode === a)) return;
                                    l = l.return
                                }
                            for (; null !== i;) {
                                if (null === (l = va(i))) return;
                                if (5 === (s = l.tag) || 6 === s) {
                                    r = o = l;
                                    continue e
                                }
                                i = i.parentNode
                            }
                        }
                        r = r.return
                    }
                    Oe((function() {
                        var r = o,
                            a = xe(n),
                            l = [];
                        e: {
                            var i = Pr.get(e);
                            if (void 0 !== i) {
                                var s = cn,
                                    u = e;
                                switch (e) {
                                    case "keypress":
                                        if (0 === tn(n)) break e;
                                    case "keydown":
                                    case "keyup":
                                        s = jn;
                                        break;
                                    case "focusin":
                                        u = "focus", s = gn;
                                        break;
                                    case "focusout":
                                        u = "blur", s = gn;
                                        break;
                                    case "beforeblur":
                                    case "afterblur":
                                        s = gn;
                                        break;
                                    case "click":
                                        if (2 === n.button) break e;
                                    case "auxclick":
                                    case "dblclick":
                                    case "mousedown":
                                    case "mousemove":
                                    case "mouseup":
                                    case "mouseout":
                                    case "mouseover":
                                    case "contextmenu":
                                        s = hn;
                                        break;
                                    case "drag":
                                    case "dragend":
                                    case "dragenter":
                                    case "dragexit":
                                    case "dragleave":
                                    case "dragover":
                                    case "dragstart":
                                    case "drop":
                                        s = mn;
                                        break;
                                    case "touchcancel":
                                    case "touchend":
                                    case "touchmove":
                                    case "touchstart":
                                        s = Tn;
                                        break;
                                    case Nr:
                                    case jr:
                                    case _r:
                                        s = yn;
                                        break;
                                    case Tr:
                                        s = Pn;
                                        break;
                                    case "scroll":
                                        s = fn;
                                        break;
                                    case "wheel":
                                        s = Rn;
                                        break;
                                    case "copy":
                                    case "cut":
                                    case "paste":
                                        s = bn;
                                        break;
                                    case "gotpointercapture":
                                    case "lostpointercapture":
                                    case "pointercancel":
                                    case "pointerdown":
                                    case "pointermove":
                                    case "pointerout":
                                    case "pointerover":
                                    case "pointerup":
                                        s = _n
                                }
                                var c = 0 !== (4 & t),
                                    d = !c && "scroll" === e,
                                    f = c ? null !== i ? i + "Capture" : null : i;
                                c = [];
                                for (var p, h = r; null !== h;) {
                                    var m = (p = h).stateNode;
                                    if (5 === p.tag && null !== m && (p = m, null !== f && (null != (m = Re(h, f)) && c.push($r(h, m, p)))), d) break;
                                    h = h.return
                                }
                                0 < c.length && (i = new s(i, u, null, n, a), l.push({
                                    event: i,
                                    listeners: c
                                }))
                            }
                        }
                        if (0 === (7 & t)) {
                            if (s = "mouseout" === e || "pointerout" === e, (!(i = "mouseover" === e || "pointerover" === e) || n === we || !(u = n.relatedTarget || n.fromElement) || !va(u) && !u[ha]) && (s || i) && (i = a.window === a ? a : (i = a.ownerDocument) ? i.defaultView || i.parentWindow : window, s ? (s = r, null !== (u = (u = n.relatedTarget || n.toElement) ? va(u) : null) && (u !== (d = He(u)) || 5 !== u.tag && 6 !== u.tag) && (u = null)) : (s = null, u = r), s !== u)) {
                                if (c = hn, m = "onMouseLeave", f = "onMouseEnter", h = "mouse", "pointerout" !== e && "pointerover" !== e || (c = _n, m = "onPointerLeave", f = "onPointerEnter", h = "pointer"), d = null == s ? i : wa(s), p = null == u ? i : wa(u), (i = new c(m, h + "leave", s, n, a)).target = d, i.relatedTarget = p, m = null, va(a) === r && ((c = new c(f, h + "enter", u, n, a)).target = p, c.relatedTarget = d, m = c), d = m, s && u) e: {
                                    for (f = u, h = 0, p = c = s; p; p = Qr(p)) h++;
                                    for (p = 0, m = f; m; m = Qr(m)) p++;
                                    for (; 0 < h - p;) c = Qr(c),
                                    h--;
                                    for (; 0 < p - h;) f = Qr(f),
                                    p--;
                                    for (; h--;) {
                                        if (c === f || null !== f && c === f.alternate) break e;
                                        c = Qr(c), f = Qr(f)
                                    }
                                    c = null
                                }
                                else c = null;
                                null !== s && Kr(l, i, s, c, !1), null !== u && null !== d && Kr(l, d, u, c, !0)
                            }
                            if ("select" === (s = (i = r ? wa(r) : window).nodeName && i.nodeName.toLowerCase()) || "input" === s && "file" === i.type) var g = Jn;
                            else if (Vn(i))
                                if (Xn) g = lr;
                                else {
                                    g = ar;
                                    var y = rr
                                }
                            else(s = i.nodeName) && "input" === s.toLowerCase() && ("checkbox" === i.type || "radio" === i.type) && (g = or);
                            switch (g && (g = g(e, r)) ? $n(l, g, n, a) : (y && y(e, i, r), "focusout" === e && (y = i._wrapperState) && y.controlled && "number" === i.type && ee(i, "number", i.value)), y = r ? wa(r) : window, e) {
                                case "focusin":
                                    (Vn(y) || "true" === y.contentEditable) && (gr = y, yr = r, vr = null);
                                    break;
                                case "focusout":
                                    vr = yr = gr = null;
                                    break;
                                case "mousedown":
                                    br = !0;
                                    break;
                                case "contextmenu":
                                case "mouseup":
                                case "dragend":
                                    br = !1, wr(l, n, a);
                                    break;
                                case "selectionchange":
                                    if (mr) break;
                                case "keydown":
                                case "keyup":
                                    wr(l, n, a)
                            }
                            var v;
                            if (zn) e: {
                                switch (e) {
                                    case "compositionstart":
                                        var b = "onCompositionStart";
                                        break e;
                                    case "compositionend":
                                        b = "onCompositionEnd";
                                        break e;
                                    case "compositionupdate":
                                        b = "onCompositionUpdate";
                                        break e
                                }
                                b = void 0
                            }
                            else Hn ? Mn(e, n) && (b = "onCompositionEnd") : "keydown" === e && 229 === n.keyCode && (b = "onCompositionStart");
                            b && (In && "ko" !== n.locale && (Hn || "onCompositionStart" !== b ? "onCompositionEnd" === b && Hn && (v = en()) : (Yt = "value" in (Xt = a) ? Xt.value : Xt.textContent, Hn = !0)), 0 < (y = qr(r, b)).length && (b = new wn(b, e, null, n, a), l.push({
                                event: b,
                                listeners: y
                            }), v ? b.data = v : null !== (v = Bn(n)) && (b.data = v))), (v = An ? function(e, t) {
                                switch (e) {
                                    case "compositionend":
                                        return Bn(t);
                                    case "keypress":
                                        return 32 !== t.which ? null : (Un = !0, Fn);
                                    case "textInput":
                                        return (e = t.data) === Fn && Un ? null : e;
                                    default:
                                        return null
                                }
                            }(e, n) : function(e, t) {
                                if (Hn) return "compositionend" === e || !zn && Mn(e, t) ? (e = en(), Zt = Yt = Xt = null, Hn = !1, e) : null;
                                switch (e) {
                                    case "paste":
                                    default:
                                        return null;
                                    case "keypress":
                                        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                                            if (t.char && 1 < t.char.length) return t.char;
                                            if (t.which) return String.fromCharCode(t.which)
                                        }
                                        return null;
                                    case "compositionend":
                                        return In && "ko" !== t.locale ? null : t.data
                                }
                            }(e, n)) && (0 < (r = qr(r, "onBeforeInput")).length && (a = new wn("onBeforeInput", "beforeinput", null, n, a), l.push({
                                event: a,
                                listeners: r
                            }), a.data = v))
                        }
                        Fr(l, t)
                    }))
                }

                function $r(e, t, n) {
                    return {
                        instance: e,
                        listener: t,
                        currentTarget: n
                    }
                }

                function qr(e, t) {
                    for (var n = t + "Capture", r = []; null !== e;) {
                        var a = e,
                            o = a.stateNode;
                        5 === a.tag && null !== o && (a = o, null != (o = Re(e, n)) && r.unshift($r(e, o, a)), null != (o = Re(e, t)) && r.push($r(e, o, a))), e = e.return
                    }
                    return r
                }

                function Qr(e) {
                    if (null === e) return null;
                    do {
                        e = e.return
                    } while (e && 5 !== e.tag);
                    return e || null
                }

                function Kr(e, t, n, r, a) {
                    for (var o = t._reactName, l = []; null !== n && n !== r;) {
                        var i = n,
                            s = i.alternate,
                            u = i.stateNode;
                        if (null !== s && s === r) break;
                        5 === i.tag && null !== u && (i = u, a ? null != (s = Re(n, o)) && l.unshift($r(n, s, i)) : a || null != (s = Re(n, o)) && l.push($r(n, s, i))), n = n.return
                    }
                    0 !== l.length && e.push({
                        event: t,
                        listeners: l
                    })
                }
                var Gr = /\r\n?/g,
                    Jr = /\u0000|\uFFFD/g;

                function Xr(e) {
                    return ("string" === typeof e ? e : "" + e).replace(Gr, "\n").replace(Jr, "")
                }

                function Yr(e, t, n) {
                    if (t = Xr(t), Xr(e) !== t && n) throw Error(o(425))
                }

                function Zr() {}
                var ea = null,
                    ta = null;

                function na(e, t) {
                    return "textarea" === e || "noscript" === e || "string" === typeof t.children || "number" === typeof t.children || "object" === typeof t.dangerouslySetInnerHTML && null !== t.dangerouslySetInnerHTML && null != t.dangerouslySetInnerHTML.__html
                }
                var ra = "function" === typeof setTimeout ? setTimeout : void 0,
                    aa = "function" === typeof clearTimeout ? clearTimeout : void 0,
                    oa = "function" === typeof Promise ? Promise : void 0,
                    la = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof oa ? function(e) {
                        return oa.resolve(null).then(e).catch(ia)
                    } : ra;

                function ia(e) {
                    setTimeout((function() {
                        throw e
                    }))
                }

                function sa(e, t) {
                    var n = t,
                        r = 0;
                    do {
                        var a = n.nextSibling;
                        if (e.removeChild(n), a && 8 === a.nodeType)
                            if ("/$" === (n = a.data)) {
                                if (0 === r) return e.removeChild(a), void Ht(t);
                                r--
                            } else "$" !== n && "$?" !== n && "$!" !== n || r++;
                        n = a
                    } while (n);
                    Ht(t)
                }

                function ua(e) {
                    for (; null != e; e = e.nextSibling) {
                        var t = e.nodeType;
                        if (1 === t || 3 === t) break;
                        if (8 === t) {
                            if ("$" === (t = e.data) || "$!" === t || "$?" === t) break;
                            if ("/$" === t) return null
                        }
                    }
                    return e
                }

                function ca(e) {
                    e = e.previousSibling;
                    for (var t = 0; e;) {
                        if (8 === e.nodeType) {
                            var n = e.data;
                            if ("$" === n || "$!" === n || "$?" === n) {
                                if (0 === t) return e;
                                t--
                            } else "/$" === n && t++
                        }
                        e = e.previousSibling
                    }
                    return null
                }
                var da = Math.random().toString(36).slice(2),
                    fa = "__reactFiber$" + da,
                    pa = "__reactProps$" + da,
                    ha = "__reactContainer$" + da,
                    ma = "__reactEvents$" + da,
                    ga = "__reactListeners$" + da,
                    ya = "__reactHandles$" + da;

                function va(e) {
                    var t = e[fa];
                    if (t) return t;
                    for (var n = e.parentNode; n;) {
                        if (t = n[ha] || n[fa]) {
                            if (n = t.alternate, null !== t.child || null !== n && null !== n.child)
                                for (e = ca(e); null !== e;) {
                                    if (n = e[fa]) return n;
                                    e = ca(e)
                                }
                            return t
                        }
                        n = (e = n).parentNode
                    }
                    return null
                }

                function ba(e) {
                    return !(e = e[fa] || e[ha]) || 5 !== e.tag && 6 !== e.tag && 13 !== e.tag && 3 !== e.tag ? null : e
                }

                function wa(e) {
                    if (5 === e.tag || 6 === e.tag) return e.stateNode;
                    throw Error(o(33))
                }

                function xa(e) {
                    return e[pa] || null
                }
                var Sa = [],
                    ka = -1;

                function Ea(e) {
                    return {
                        current: e
                    }
                }

                function Ca(e) {
                    0 > ka || (e.current = Sa[ka], Sa[ka] = null, ka--)
                }

                function Na(e, t) {
                    ka++, Sa[ka] = e.current, e.current = t
                }
                var ja = {},
                    _a = Ea(ja),
                    Ta = Ea(!1),
                    Pa = ja;

                function Oa(e, t) {
                    var n = e.type.contextTypes;
                    if (!n) return ja;
                    var r = e.stateNode;
                    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
                    var a, o = {};
                    for (a in n) o[a] = t[a];
                    return r && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = o), o
                }

                function Ra(e) {
                    return null !== (e = e.childContextTypes) && void 0 !== e
                }

                function La() {
                    Ca(Ta), Ca(_a)
                }

                function za(e, t, n) {
                    if (_a.current !== ja) throw Error(o(168));
                    Na(_a, t), Na(Ta, n)
                }

                function Da(e, t, n) {
                    var r = e.stateNode;
                    if (t = t.childContextTypes, "function" !== typeof r.getChildContext) return n;
                    for (var a in r = r.getChildContext())
                        if (!(a in t)) throw Error(o(108, W(e) || "Unknown", a));
                    return I({}, n, r)
                }

                function Aa(e) {
                    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || ja, Pa = _a.current, Na(_a, e), Na(Ta, Ta.current), !0
                }

                function Ia(e, t, n) {
                    var r = e.stateNode;
                    if (!r) throw Error(o(169));
                    n ? (e = Da(e, t, Pa), r.__reactInternalMemoizedMergedChildContext = e, Ca(Ta), Ca(_a), Na(_a, e)) : Ca(Ta), Na(Ta, n)
                }
                var Fa = null,
                    Ua = !1,
                    Ma = !1;

                function Ba(e) {
                    null === Fa ? Fa = [e] : Fa.push(e)
                }

                function Ha() {
                    if (!Ma && null !== Fa) {
                        Ma = !0;
                        var e = 0,
                            t = bt;
                        try {
                            var n = Fa;
                            for (bt = 1; e < n.length; e++) {
                                var r = n[e];
                                do {
                                    r = r(!0)
                                } while (null !== r)
                            }
                            Fa = null, Ua = !1
                        } catch (a) {
                            throw null !== Fa && (Fa = Fa.slice(e + 1)), Qe(Ze, Ha), a
                        } finally {
                            bt = t, Ma = !1
                        }
                    }
                    return null
                }
                var Wa = [],
                    Va = 0,
                    $a = null,
                    qa = 0,
                    Qa = [],
                    Ka = 0,
                    Ga = null,
                    Ja = 1,
                    Xa = "";

                function Ya(e, t) {
                    Wa[Va++] = qa, Wa[Va++] = $a, $a = e, qa = t
                }

                function Za(e, t, n) {
                    Qa[Ka++] = Ja, Qa[Ka++] = Xa, Qa[Ka++] = Ga, Ga = e;
                    var r = Ja;
                    e = Xa;
                    var a = 32 - lt(r) - 1;
                    r &= ~(1 << a), n += 1;
                    var o = 32 - lt(t) + a;
                    if (30 < o) {
                        var l = a - a % 5;
                        o = (r & (1 << l) - 1).toString(32), r >>= l, a -= l, Ja = 1 << 32 - lt(t) + a | n << a | r, Xa = o + e
                    } else Ja = 1 << o | n << a | r, Xa = e
                }

                function eo(e) {
                    null !== e.return && (Ya(e, 1), Za(e, 1, 0))
                }

                function to(e) {
                    for (; e === $a;) $a = Wa[--Va], Wa[Va] = null, qa = Wa[--Va], Wa[Va] = null;
                    for (; e === Ga;) Ga = Qa[--Ka], Qa[Ka] = null, Xa = Qa[--Ka], Qa[Ka] = null, Ja = Qa[--Ka], Qa[Ka] = null
                }
                var no = null,
                    ro = null,
                    ao = !1,
                    oo = null;

                function lo(e, t) {
                    var n = Ru(5, null, null, 0);
                    n.elementType = "DELETED", n.stateNode = t, n.return = e, null === (t = e.deletions) ? (e.deletions = [n], e.flags |= 16) : t.push(n)
                }

                function io(e, t) {
                    switch (e.tag) {
                        case 5:
                            var n = e.type;
                            return null !== (t = 1 !== t.nodeType || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t) && (e.stateNode = t, no = e, ro = ua(t.firstChild), !0);
                        case 6:
                            return null !== (t = "" === e.pendingProps || 3 !== t.nodeType ? null : t) && (e.stateNode = t, no = e, ro = null, !0);
                        case 13:
                            return null !== (t = 8 !== t.nodeType ? null : t) && (n = null !== Ga ? {
                                id: Ja,
                                overflow: Xa
                            } : null, e.memoizedState = {
                                dehydrated: t,
                                treeContext: n,
                                retryLane: 1073741824
                            }, (n = Ru(18, null, null, 0)).stateNode = t, n.return = e, e.child = n, no = e, ro = null, !0);
                        default:
                            return !1
                    }
                }

                function so(e) {
                    return 0 !== (1 & e.mode) && 0 === (128 & e.flags)
                }

                function uo(e) {
                    if (ao) {
                        var t = ro;
                        if (t) {
                            var n = t;
                            if (!io(e, t)) {
                                if (so(e)) throw Error(o(418));
                                t = ua(n.nextSibling);
                                var r = no;
                                t && io(e, t) ? lo(r, n) : (e.flags = -4097 & e.flags | 2, ao = !1, no = e)
                            }
                        } else {
                            if (so(e)) throw Error(o(418));
                            e.flags = -4097 & e.flags | 2, ao = !1, no = e
                        }
                    }
                }

                function co(e) {
                    for (e = e.return; null !== e && 5 !== e.tag && 3 !== e.tag && 13 !== e.tag;) e = e.return;
                    no = e
                }

                function fo(e) {
                    if (e !== no) return !1;
                    if (!ao) return co(e), ao = !0, !1;
                    var t;
                    if ((t = 3 !== e.tag) && !(t = 5 !== e.tag) && (t = "head" !== (t = e.type) && "body" !== t && !na(e.type, e.memoizedProps)), t && (t = ro)) {
                        if (so(e)) throw po(), Error(o(418));
                        for (; t;) lo(e, t), t = ua(t.nextSibling)
                    }
                    if (co(e), 13 === e.tag) {
                        if (!(e = null !== (e = e.memoizedState) ? e.dehydrated : null)) throw Error(o(317));
                        e: {
                            for (e = e.nextSibling, t = 0; e;) {
                                if (8 === e.nodeType) {
                                    var n = e.data;
                                    if ("/$" === n) {
                                        if (0 === t) {
                                            ro = ua(e.nextSibling);
                                            break e
                                        }
                                        t--
                                    } else "$" !== n && "$!" !== n && "$?" !== n || t++
                                }
                                e = e.nextSibling
                            }
                            ro = null
                        }
                    } else ro = no ? ua(e.stateNode.nextSibling) : null;
                    return !0
                }

                function po() {
                    for (var e = ro; e;) e = ua(e.nextSibling)
                }

                function ho() {
                    ro = no = null, ao = !1
                }

                function mo(e) {
                    null === oo ? oo = [e] : oo.push(e)
                }
                var go = w.ReactCurrentBatchConfig;

                function yo(e, t) {
                    if (e && e.defaultProps) {
                        for (var n in t = I({}, t), e = e.defaultProps) void 0 === t[n] && (t[n] = e[n]);
                        return t
                    }
                    return t
                }
                var vo = Ea(null),
                    bo = null,
                    wo = null,
                    xo = null;

                function So() {
                    xo = wo = bo = null
                }

                function ko(e) {
                    var t = vo.current;
                    Ca(vo), e._currentValue = t
                }

                function Eo(e, t, n) {
                    for (; null !== e;) {
                        var r = e.alternate;
                        if ((e.childLanes & t) !== t ? (e.childLanes |= t, null !== r && (r.childLanes |= t)) : null !== r && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
                        e = e.return
                    }
                }

                function Co(e, t) {
                    bo = e, xo = wo = null, null !== (e = e.dependencies) && null !== e.firstContext && (0 !== (e.lanes & t) && (wi = !0), e.firstContext = null)
                }

                function No(e) {
                    var t = e._currentValue;
                    if (xo !== e)
                        if (e = {
                                context: e,
                                memoizedValue: t,
                                next: null
                            }, null === wo) {
                            if (null === bo) throw Error(o(308));
                            wo = e, bo.dependencies = {
                                lanes: 0,
                                firstContext: e
                            }
                        } else wo = wo.next = e;
                    return t
                }
                var jo = null;

                function _o(e) {
                    null === jo ? jo = [e] : jo.push(e)
                }

                function To(e, t, n, r) {
                    var a = t.interleaved;
                    return null === a ? (n.next = n, _o(t)) : (n.next = a.next, a.next = n), t.interleaved = n, Po(e, r)
                }

                function Po(e, t) {
                    e.lanes |= t;
                    var n = e.alternate;
                    for (null !== n && (n.lanes |= t), n = e, e = e.return; null !== e;) e.childLanes |= t, null !== (n = e.alternate) && (n.childLanes |= t), n = e, e = e.return;
                    return 3 === n.tag ? n.stateNode : null
                }
                var Oo = !1;

                function Ro(e) {
                    e.updateQueue = {
                        baseState: e.memoizedState,
                        firstBaseUpdate: null,
                        lastBaseUpdate: null,
                        shared: {
                            pending: null,
                            interleaved: null,
                            lanes: 0
                        },
                        effects: null
                    }
                }

                function Lo(e, t) {
                    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
                        baseState: e.baseState,
                        firstBaseUpdate: e.firstBaseUpdate,
                        lastBaseUpdate: e.lastBaseUpdate,
                        shared: e.shared,
                        effects: e.effects
                    })
                }

                function zo(e, t) {
                    return {
                        eventTime: e,
                        lane: t,
                        tag: 0,
                        payload: null,
                        callback: null,
                        next: null
                    }
                }

                function Do(e, t, n) {
                    var r = e.updateQueue;
                    if (null === r) return null;
                    if (r = r.shared, 0 !== (2 & Ts)) {
                        var a = r.pending;
                        return null === a ? t.next = t : (t.next = a.next, a.next = t), r.pending = t, Po(e, n)
                    }
                    return null === (a = r.interleaved) ? (t.next = t, _o(r)) : (t.next = a.next, a.next = t), r.interleaved = t, Po(e, n)
                }

                function Ao(e, t, n) {
                    if (null !== (t = t.updateQueue) && (t = t.shared, 0 !== (4194240 & n))) {
                        var r = t.lanes;
                        n |= r &= e.pendingLanes, t.lanes = n, vt(e, n)
                    }
                }

                function Io(e, t) {
                    var n = e.updateQueue,
                        r = e.alternate;
                    if (null !== r && n === (r = r.updateQueue)) {
                        var a = null,
                            o = null;
                        if (null !== (n = n.firstBaseUpdate)) {
                            do {
                                var l = {
                                    eventTime: n.eventTime,
                                    lane: n.lane,
                                    tag: n.tag,
                                    payload: n.payload,
                                    callback: n.callback,
                                    next: null
                                };
                                null === o ? a = o = l : o = o.next = l, n = n.next
                            } while (null !== n);
                            null === o ? a = o = t : o = o.next = t
                        } else a = o = t;
                        return n = {
                            baseState: r.baseState,
                            firstBaseUpdate: a,
                            lastBaseUpdate: o,
                            shared: r.shared,
                            effects: r.effects
                        }, void(e.updateQueue = n)
                    }
                    null === (e = n.lastBaseUpdate) ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
                }

                function Fo(e, t, n, r) {
                    var a = e.updateQueue;
                    Oo = !1;
                    var o = a.firstBaseUpdate,
                        l = a.lastBaseUpdate,
                        i = a.shared.pending;
                    if (null !== i) {
                        a.shared.pending = null;
                        var s = i,
                            u = s.next;
                        s.next = null, null === l ? o = u : l.next = u, l = s;
                        var c = e.alternate;
                        null !== c && ((i = (c = c.updateQueue).lastBaseUpdate) !== l && (null === i ? c.firstBaseUpdate = u : i.next = u, c.lastBaseUpdate = s))
                    }
                    if (null !== o) {
                        var d = a.baseState;
                        for (l = 0, c = u = s = null, i = o;;) {
                            var f = i.lane,
                                p = i.eventTime;
                            if ((r & f) === f) {
                                null !== c && (c = c.next = {
                                    eventTime: p,
                                    lane: 0,
                                    tag: i.tag,
                                    payload: i.payload,
                                    callback: i.callback,
                                    next: null
                                });
                                e: {
                                    var h = e,
                                        m = i;
                                    switch (f = t, p = n, m.tag) {
                                        case 1:
                                            if ("function" === typeof(h = m.payload)) {
                                                d = h.call(p, d, f);
                                                break e
                                            }
                                            d = h;
                                            break e;
                                        case 3:
                                            h.flags = -65537 & h.flags | 128;
                                        case 0:
                                            if (null === (f = "function" === typeof(h = m.payload) ? h.call(p, d, f) : h) || void 0 === f) break e;
                                            d = I({}, d, f);
                                            break e;
                                        case 2:
                                            Oo = !0
                                    }
                                }
                                null !== i.callback && 0 !== i.lane && (e.flags |= 64, null === (f = a.effects) ? a.effects = [i] : f.push(i))
                            } else p = {
                                eventTime: p,
                                lane: f,
                                tag: i.tag,
                                payload: i.payload,
                                callback: i.callback,
                                next: null
                            }, null === c ? (u = c = p, s = d) : c = c.next = p, l |= f;
                            if (null === (i = i.next)) {
                                if (null === (i = a.shared.pending)) break;
                                i = (f = i).next, f.next = null, a.lastBaseUpdate = f, a.shared.pending = null
                            }
                        }
                        if (null === c && (s = d), a.baseState = s, a.firstBaseUpdate = u, a.lastBaseUpdate = c, null !== (t = a.shared.interleaved)) {
                            a = t;
                            do {
                                l |= a.lane, a = a.next
                            } while (a !== t)
                        } else null === o && (a.shared.lanes = 0);
                        Is |= l, e.lanes = l, e.memoizedState = d
                    }
                }

                function Uo(e, t, n) {
                    if (e = t.effects, t.effects = null, null !== e)
                        for (t = 0; t < e.length; t++) {
                            var r = e[t],
                                a = r.callback;
                            if (null !== a) {
                                if (r.callback = null, r = n, "function" !== typeof a) throw Error(o(191, a));
                                a.call(r)
                            }
                        }
                }
                var Mo = (new r.Component).refs;

                function Bo(e, t, n, r) {
                    n = null === (n = n(r, t = e.memoizedState)) || void 0 === n ? t : I({}, t, n), e.memoizedState = n, 0 === e.lanes && (e.updateQueue.baseState = n)
                }
                var Ho = {
                    isMounted: function(e) {
                        return !!(e = e._reactInternals) && He(e) === e
                    },
                    enqueueSetState: function(e, t, n) {
                        e = e._reactInternals;
                        var r = tu(),
                            a = nu(e),
                            o = zo(r, a);
                        o.payload = t, void 0 !== n && null !== n && (o.callback = n), null !== (t = Do(e, o, a)) && (ru(t, e, a, r), Ao(t, e, a))
                    },
                    enqueueReplaceState: function(e, t, n) {
                        e = e._reactInternals;
                        var r = tu(),
                            a = nu(e),
                            o = zo(r, a);
                        o.tag = 1, o.payload = t, void 0 !== n && null !== n && (o.callback = n), null !== (t = Do(e, o, a)) && (ru(t, e, a, r), Ao(t, e, a))
                    },
                    enqueueForceUpdate: function(e, t) {
                        e = e._reactInternals;
                        var n = tu(),
                            r = nu(e),
                            a = zo(n, r);
                        a.tag = 2, void 0 !== t && null !== t && (a.callback = t), null !== (t = Do(e, a, r)) && (ru(t, e, r, n), Ao(t, e, r))
                    }
                };

                function Wo(e, t, n, r, a, o, l) {
                    return "function" === typeof(e = e.stateNode).shouldComponentUpdate ? e.shouldComponentUpdate(r, o, l) : !t.prototype || !t.prototype.isPureReactComponent || (!sr(n, r) || !sr(a, o))
                }

                function Vo(e, t, n) {
                    var r = !1,
                        a = ja,
                        o = t.contextType;
                    return "object" === typeof o && null !== o ? o = No(o) : (a = Ra(t) ? Pa : _a.current, o = (r = null !== (r = t.contextTypes) && void 0 !== r) ? Oa(e, a) : ja), t = new t(n, o), e.memoizedState = null !== t.state && void 0 !== t.state ? t.state : null, t.updater = Ho, e.stateNode = t, t._reactInternals = e, r && ((e = e.stateNode).__reactInternalMemoizedUnmaskedChildContext = a, e.__reactInternalMemoizedMaskedChildContext = o), t
                }

                function $o(e, t, n, r) {
                    e = t.state, "function" === typeof t.componentWillReceiveProps && t.componentWillReceiveProps(n, r), "function" === typeof t.UNSAFE_componentWillReceiveProps && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ho.enqueueReplaceState(t, t.state, null)
                }

                function qo(e, t, n, r) {
                    var a = e.stateNode;
                    a.props = n, a.state = e.memoizedState, a.refs = Mo, Ro(e);
                    var o = t.contextType;
                    "object" === typeof o && null !== o ? a.context = No(o) : (o = Ra(t) ? Pa : _a.current, a.context = Oa(e, o)), a.state = e.memoizedState, "function" === typeof(o = t.getDerivedStateFromProps) && (Bo(e, t, o, n), a.state = e.memoizedState), "function" === typeof t.getDerivedStateFromProps || "function" === typeof a.getSnapshotBeforeUpdate || "function" !== typeof a.UNSAFE_componentWillMount && "function" !== typeof a.componentWillMount || (t = a.state, "function" === typeof a.componentWillMount && a.componentWillMount(), "function" === typeof a.UNSAFE_componentWillMount && a.UNSAFE_componentWillMount(), t !== a.state && Ho.enqueueReplaceState(a, a.state, null), Fo(e, n, a, r), a.state = e.memoizedState), "function" === typeof a.componentDidMount && (e.flags |= 4194308)
                }

                function Qo(e, t, n) {
                    if (null !== (e = n.ref) && "function" !== typeof e && "object" !== typeof e) {
                        if (n._owner) {
                            if (n = n._owner) {
                                if (1 !== n.tag) throw Error(o(309));
                                var r = n.stateNode
                            }
                            if (!r) throw Error(o(147, e));
                            var a = r,
                                l = "" + e;
                            return null !== t && null !== t.ref && "function" === typeof t.ref && t.ref._stringRef === l ? t.ref : (t = function(e) {
                                var t = a.refs;
                                t === Mo && (t = a.refs = {}), null === e ? delete t[l] : t[l] = e
                            }, t._stringRef = l, t)
                        }
                        if ("string" !== typeof e) throw Error(o(284));
                        if (!n._owner) throw Error(o(290, e))
                    }
                    return e
                }

                function Ko(e, t) {
                    throw e = Object.prototype.toString.call(t), Error(o(31, "[object Object]" === e ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
                }

                function Go(e) {
                    return (0, e._init)(e._payload)
                }

                function Jo(e) {
                    function t(t, n) {
                        if (e) {
                            var r = t.deletions;
                            null === r ? (t.deletions = [n], t.flags |= 16) : r.push(n)
                        }
                    }

                    function n(n, r) {
                        if (!e) return null;
                        for (; null !== r;) t(n, r), r = r.sibling;
                        return null
                    }

                    function r(e, t) {
                        for (e = new Map; null !== t;) null !== t.key ? e.set(t.key, t) : e.set(t.index, t), t = t.sibling;
                        return e
                    }

                    function a(e, t) {
                        return (e = zu(e, t)).index = 0, e.sibling = null, e
                    }

                    function l(t, n, r) {
                        return t.index = r, e ? null !== (r = t.alternate) ? (r = r.index) < n ? (t.flags |= 2, n) : r : (t.flags |= 2, n) : (t.flags |= 1048576, n)
                    }

                    function i(t) {
                        return e && null === t.alternate && (t.flags |= 2), t
                    }

                    function s(e, t, n, r) {
                        return null === t || 6 !== t.tag ? ((t = Fu(n, e.mode, r)).return = e, t) : ((t = a(t, n)).return = e, t)
                    }

                    function u(e, t, n, r) {
                        var o = n.type;
                        return o === k ? d(e, t, n.props.children, r, n.key) : null !== t && (t.elementType === o || "object" === typeof o && null !== o && o.$$typeof === R && Go(o) === t.type) ? ((r = a(t, n.props)).ref = Qo(e, t, n), r.return = e, r) : ((r = Du(n.type, n.key, n.props, null, e.mode, r)).ref = Qo(e, t, n), r.return = e, r)
                    }

                    function c(e, t, n, r) {
                        return null === t || 4 !== t.tag || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? ((t = Uu(n, e.mode, r)).return = e, t) : ((t = a(t, n.children || [])).return = e, t)
                    }

                    function d(e, t, n, r, o) {
                        return null === t || 7 !== t.tag ? ((t = Au(n, e.mode, r, o)).return = e, t) : ((t = a(t, n)).return = e, t)
                    }

                    function f(e, t, n) {
                        if ("string" === typeof t && "" !== t || "number" === typeof t) return (t = Fu("" + t, e.mode, n)).return = e, t;
                        if ("object" === typeof t && null !== t) {
                            switch (t.$$typeof) {
                                case x:
                                    return (n = Du(t.type, t.key, t.props, null, e.mode, n)).ref = Qo(e, null, t), n.return = e, n;
                                case S:
                                    return (t = Uu(t, e.mode, n)).return = e, t;
                                case R:
                                    return f(e, (0, t._init)(t._payload), n)
                            }
                            if (te(t) || D(t)) return (t = Au(t, e.mode, n, null)).return = e, t;
                            Ko(e, t)
                        }
                        return null
                    }

                    function p(e, t, n, r) {
                        var a = null !== t ? t.key : null;
                        if ("string" === typeof n && "" !== n || "number" === typeof n) return null !== a ? null : s(e, t, "" + n, r);
                        if ("object" === typeof n && null !== n) {
                            switch (n.$$typeof) {
                                case x:
                                    return n.key === a ? u(e, t, n, r) : null;
                                case S:
                                    return n.key === a ? c(e, t, n, r) : null;
                                case R:
                                    return p(e, t, (a = n._init)(n._payload), r)
                            }
                            if (te(n) || D(n)) return null !== a ? null : d(e, t, n, r, null);
                            Ko(e, n)
                        }
                        return null
                    }

                    function h(e, t, n, r, a) {
                        if ("string" === typeof r && "" !== r || "number" === typeof r) return s(t, e = e.get(n) || null, "" + r, a);
                        if ("object" === typeof r && null !== r) {
                            switch (r.$$typeof) {
                                case x:
                                    return u(t, e = e.get(null === r.key ? n : r.key) || null, r, a);
                                case S:
                                    return c(t, e = e.get(null === r.key ? n : r.key) || null, r, a);
                                case R:
                                    return h(e, t, n, (0, r._init)(r._payload), a)
                            }
                            if (te(r) || D(r)) return d(t, e = e.get(n) || null, r, a, null);
                            Ko(t, r)
                        }
                        return null
                    }

                    function m(a, o, i, s) {
                        for (var u = null, c = null, d = o, m = o = 0, g = null; null !== d && m < i.length; m++) {
                            d.index > m ? (g = d, d = null) : g = d.sibling;
                            var y = p(a, d, i[m], s);
                            if (null === y) {
                                null === d && (d = g);
                                break
                            }
                            e && d && null === y.alternate && t(a, d), o = l(y, o, m), null === c ? u = y : c.sibling = y, c = y, d = g
                        }
                        if (m === i.length) return n(a, d), ao && Ya(a, m), u;
                        if (null === d) {
                            for (; m < i.length; m++) null !== (d = f(a, i[m], s)) && (o = l(d, o, m), null === c ? u = d : c.sibling = d, c = d);
                            return ao && Ya(a, m), u
                        }
                        for (d = r(a, d); m < i.length; m++) null !== (g = h(d, a, m, i[m], s)) && (e && null !== g.alternate && d.delete(null === g.key ? m : g.key), o = l(g, o, m), null === c ? u = g : c.sibling = g, c = g);
                        return e && d.forEach((function(e) {
                            return t(a, e)
                        })), ao && Ya(a, m), u
                    }

                    function g(a, i, s, u) {
                        var c = D(s);
                        if ("function" !== typeof c) throw Error(o(150));
                        if (null == (s = c.call(s))) throw Error(o(151));
                        for (var d = c = null, m = i, g = i = 0, y = null, v = s.next(); null !== m && !v.done; g++, v = s.next()) {
                            m.index > g ? (y = m, m = null) : y = m.sibling;
                            var b = p(a, m, v.value, u);
                            if (null === b) {
                                null === m && (m = y);
                                break
                            }
                            e && m && null === b.alternate && t(a, m), i = l(b, i, g), null === d ? c = b : d.sibling = b, d = b, m = y
                        }
                        if (v.done) return n(a, m), ao && Ya(a, g), c;
                        if (null === m) {
                            for (; !v.done; g++, v = s.next()) null !== (v = f(a, v.value, u)) && (i = l(v, i, g), null === d ? c = v : d.sibling = v, d = v);
                            return ao && Ya(a, g), c
                        }
                        for (m = r(a, m); !v.done; g++, v = s.next()) null !== (v = h(m, a, g, v.value, u)) && (e && null !== v.alternate && m.delete(null === v.key ? g : v.key), i = l(v, i, g), null === d ? c = v : d.sibling = v, d = v);
                        return e && m.forEach((function(e) {
                            return t(a, e)
                        })), ao && Ya(a, g), c
                    }
                    return function e(r, o, l, s) {
                        if ("object" === typeof l && null !== l && l.type === k && null === l.key && (l = l.props.children), "object" === typeof l && null !== l) {
                            switch (l.$$typeof) {
                                case x:
                                    e: {
                                        for (var u = l.key, c = o; null !== c;) {
                                            if (c.key === u) {
                                                if ((u = l.type) === k) {
                                                    if (7 === c.tag) {
                                                        n(r, c.sibling), (o = a(c, l.props.children)).return = r, r = o;
                                                        break e
                                                    }
                                                } else if (c.elementType === u || "object" === typeof u && null !== u && u.$$typeof === R && Go(u) === c.type) {
                                                    n(r, c.sibling), (o = a(c, l.props)).ref = Qo(r, c, l), o.return = r, r = o;
                                                    break e
                                                }
                                                n(r, c);
                                                break
                                            }
                                            t(r, c), c = c.sibling
                                        }
                                        l.type === k ? ((o = Au(l.props.children, r.mode, s, l.key)).return = r, r = o) : ((s = Du(l.type, l.key, l.props, null, r.mode, s)).ref = Qo(r, o, l), s.return = r, r = s)
                                    }
                                    return i(r);
                                case S:
                                    e: {
                                        for (c = l.key; null !== o;) {
                                            if (o.key === c) {
                                                if (4 === o.tag && o.stateNode.containerInfo === l.containerInfo && o.stateNode.implementation === l.implementation) {
                                                    n(r, o.sibling), (o = a(o, l.children || [])).return = r, r = o;
                                                    break e
                                                }
                                                n(r, o);
                                                break
                                            }
                                            t(r, o), o = o.sibling
                                        }(o = Uu(l, r.mode, s)).return = r,
                                        r = o
                                    }
                                    return i(r);
                                case R:
                                    return e(r, o, (c = l._init)(l._payload), s)
                            }
                            if (te(l)) return m(r, o, l, s);
                            if (D(l)) return g(r, o, l, s);
                            Ko(r, l)
                        }
                        return "string" === typeof l && "" !== l || "number" === typeof l ? (l = "" + l, null !== o && 6 === o.tag ? (n(r, o.sibling), (o = a(o, l)).return = r, r = o) : (n(r, o), (o = Fu(l, r.mode, s)).return = r, r = o), i(r)) : n(r, o)
                    }
                }
                var Xo = Jo(!0),
                    Yo = Jo(!1),
                    Zo = {},
                    el = Ea(Zo),
                    tl = Ea(Zo),
                    nl = Ea(Zo);

                function rl(e) {
                    if (e === Zo) throw Error(o(174));
                    return e
                }

                function al(e, t) {
                    switch (Na(nl, t), Na(tl, e), Na(el, Zo), e = t.nodeType) {
                        case 9:
                        case 11:
                            t = (t = t.documentElement) ? t.namespaceURI : se(null, "");
                            break;
                        default:
                            t = se(t = (e = 8 === e ? t.parentNode : t).namespaceURI || null, e = e.tagName)
                    }
                    Ca(el), Na(el, t)
                }

                function ol() {
                    Ca(el), Ca(tl), Ca(nl)
                }

                function ll(e) {
                    rl(nl.current);
                    var t = rl(el.current),
                        n = se(t, e.type);
                    t !== n && (Na(tl, e), Na(el, n))
                }

                function il(e) {
                    tl.current === e && (Ca(el), Ca(tl))
                }
                var sl = Ea(0);

                function ul(e) {
                    for (var t = e; null !== t;) {
                        if (13 === t.tag) {
                            var n = t.memoizedState;
                            if (null !== n && (null === (n = n.dehydrated) || "$?" === n.data || "$!" === n.data)) return t
                        } else if (19 === t.tag && void 0 !== t.memoizedProps.revealOrder) {
                            if (0 !== (128 & t.flags)) return t
                        } else if (null !== t.child) {
                            t.child.return = t, t = t.child;
                            continue
                        }
                        if (t === e) break;
                        for (; null === t.sibling;) {
                            if (null === t.return || t.return === e) return null;
                            t = t.return
                        }
                        t.sibling.return = t.return, t = t.sibling
                    }
                    return null
                }
                var cl = [];

                function dl() {
                    for (var e = 0; e < cl.length; e++) cl[e]._workInProgressVersionPrimary = null;
                    cl.length = 0
                }
                var fl = w.ReactCurrentDispatcher,
                    pl = w.ReactCurrentBatchConfig,
                    hl = 0,
                    ml = null,
                    gl = null,
                    yl = null,
                    vl = !1,
                    bl = !1,
                    wl = 0,
                    xl = 0;

                function Sl() {
                    throw Error(o(321))
                }

                function kl(e, t) {
                    if (null === t) return !1;
                    for (var n = 0; n < t.length && n < e.length; n++)
                        if (!ir(e[n], t[n])) return !1;
                    return !0
                }

                function El(e, t, n, r, a, l) {
                    if (hl = l, ml = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, fl.current = null === e || null === e.memoizedState ? ii : si, e = n(r, a), bl) {
                        l = 0;
                        do {
                            if (bl = !1, wl = 0, 25 <= l) throw Error(o(301));
                            l += 1, yl = gl = null, t.updateQueue = null, fl.current = ui, e = n(r, a)
                        } while (bl)
                    }
                    if (fl.current = li, t = null !== gl && null !== gl.next, hl = 0, yl = gl = ml = null, vl = !1, t) throw Error(o(300));
                    return e
                }

                function Cl() {
                    var e = 0 !== wl;
                    return wl = 0, e
                }

                function Nl() {
                    var e = {
                        memoizedState: null,
                        baseState: null,
                        baseQueue: null,
                        queue: null,
                        next: null
                    };
                    return null === yl ? ml.memoizedState = yl = e : yl = yl.next = e, yl
                }

                function jl() {
                    if (null === gl) {
                        var e = ml.alternate;
                        e = null !== e ? e.memoizedState : null
                    } else e = gl.next;
                    var t = null === yl ? ml.memoizedState : yl.next;
                    if (null !== t) yl = t, gl = e;
                    else {
                        if (null === e) throw Error(o(310));
                        e = {
                            memoizedState: (gl = e).memoizedState,
                            baseState: gl.baseState,
                            baseQueue: gl.baseQueue,
                            queue: gl.queue,
                            next: null
                        }, null === yl ? ml.memoizedState = yl = e : yl = yl.next = e
                    }
                    return yl
                }

                function _l(e, t) {
                    return "function" === typeof t ? t(e) : t
                }

                function Tl(e) {
                    var t = jl(),
                        n = t.queue;
                    if (null === n) throw Error(o(311));
                    n.lastRenderedReducer = e;
                    var r = gl,
                        a = r.baseQueue,
                        l = n.pending;
                    if (null !== l) {
                        if (null !== a) {
                            var i = a.next;
                            a.next = l.next, l.next = i
                        }
                        r.baseQueue = a = l, n.pending = null
                    }
                    if (null !== a) {
                        l = a.next, r = r.baseState;
                        var s = i = null,
                            u = null,
                            c = l;
                        do {
                            var d = c.lane;
                            if ((hl & d) === d) null !== u && (u = u.next = {
                                lane: 0,
                                action: c.action,
                                hasEagerState: c.hasEagerState,
                                eagerState: c.eagerState,
                                next: null
                            }), r = c.hasEagerState ? c.eagerState : e(r, c.action);
                            else {
                                var f = {
                                    lane: d,
                                    action: c.action,
                                    hasEagerState: c.hasEagerState,
                                    eagerState: c.eagerState,
                                    next: null
                                };
                                null === u ? (s = u = f, i = r) : u = u.next = f, ml.lanes |= d, Is |= d
                            }
                            c = c.next
                        } while (null !== c && c !== l);
                        null === u ? i = r : u.next = s, ir(r, t.memoizedState) || (wi = !0), t.memoizedState = r, t.baseState = i, t.baseQueue = u, n.lastRenderedState = r
                    }
                    if (null !== (e = n.interleaved)) {
                        a = e;
                        do {
                            l = a.lane, ml.lanes |= l, Is |= l, a = a.next
                        } while (a !== e)
                    } else null === a && (n.lanes = 0);
                    return [t.memoizedState, n.dispatch]
                }

                function Pl(e) {
                    var t = jl(),
                        n = t.queue;
                    if (null === n) throw Error(o(311));
                    n.lastRenderedReducer = e;
                    var r = n.dispatch,
                        a = n.pending,
                        l = t.memoizedState;
                    if (null !== a) {
                        n.pending = null;
                        var i = a = a.next;
                        do {
                            l = e(l, i.action), i = i.next
                        } while (i !== a);
                        ir(l, t.memoizedState) || (wi = !0), t.memoizedState = l, null === t.baseQueue && (t.baseState = l), n.lastRenderedState = l
                    }
                    return [l, r]
                }

                function Ol() {}

                function Rl(e, t) {
                    var n = ml,
                        r = jl(),
                        a = t(),
                        l = !ir(r.memoizedState, a);
                    if (l && (r.memoizedState = a, wi = !0), r = r.queue, Vl(Dl.bind(null, n, r, e), [e]), r.getSnapshot !== t || l || null !== yl && 1 & yl.memoizedState.tag) {
                        if (n.flags |= 2048, Ul(9, zl.bind(null, n, r, a, t), void 0, null), null === Ps) throw Error(o(349));
                        0 !== (30 & hl) || Ll(n, t, a)
                    }
                    return a
                }

                function Ll(e, t, n) {
                    e.flags |= 16384, e = {
                        getSnapshot: t,
                        value: n
                    }, null === (t = ml.updateQueue) ? (t = {
                        lastEffect: null,
                        stores: null
                    }, ml.updateQueue = t, t.stores = [e]) : null === (n = t.stores) ? t.stores = [e] : n.push(e)
                }

                function zl(e, t, n, r) {
                    t.value = n, t.getSnapshot = r, Al(t) && Il(e)
                }

                function Dl(e, t, n) {
                    return n((function() {
                        Al(t) && Il(e)
                    }))
                }

                function Al(e) {
                    var t = e.getSnapshot;
                    e = e.value;
                    try {
                        var n = t();
                        return !ir(e, n)
                    } catch (r) {
                        return !0
                    }
                }

                function Il(e) {
                    var t = Po(e, 1);
                    null !== t && ru(t, e, 1, -1)
                }

                function Fl(e) {
                    var t = Nl();
                    return "function" === typeof e && (e = e()), t.memoizedState = t.baseState = e, e = {
                        pending: null,
                        interleaved: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: _l,
                        lastRenderedState: e
                    }, t.queue = e, e = e.dispatch = ni.bind(null, ml, e), [t.memoizedState, e]
                }

                function Ul(e, t, n, r) {
                    return e = {
                        tag: e,
                        create: t,
                        destroy: n,
                        deps: r,
                        next: null
                    }, null === (t = ml.updateQueue) ? (t = {
                        lastEffect: null,
                        stores: null
                    }, ml.updateQueue = t, t.lastEffect = e.next = e) : null === (n = t.lastEffect) ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e
                }

                function Ml() {
                    return jl().memoizedState
                }

                function Bl(e, t, n, r) {
                    var a = Nl();
                    ml.flags |= e, a.memoizedState = Ul(1 | t, n, void 0, void 0 === r ? null : r)
                }

                function Hl(e, t, n, r) {
                    var a = jl();
                    r = void 0 === r ? null : r;
                    var o = void 0;
                    if (null !== gl) {
                        var l = gl.memoizedState;
                        if (o = l.destroy, null !== r && kl(r, l.deps)) return void(a.memoizedState = Ul(t, n, o, r))
                    }
                    ml.flags |= e, a.memoizedState = Ul(1 | t, n, o, r)
                }

                function Wl(e, t) {
                    return Bl(8390656, 8, e, t)
                }

                function Vl(e, t) {
                    return Hl(2048, 8, e, t)
                }

                function $l(e, t) {
                    return Hl(4, 2, e, t)
                }

                function ql(e, t) {
                    return Hl(4, 4, e, t)
                }

                function Ql(e, t) {
                    return "function" === typeof t ? (e = e(), t(e), function() {
                        t(null)
                    }) : null !== t && void 0 !== t ? (e = e(), t.current = e, function() {
                        t.current = null
                    }) : void 0
                }

                function Kl(e, t, n) {
                    return n = null !== n && void 0 !== n ? n.concat([e]) : null, Hl(4, 4, Ql.bind(null, t, e), n)
                }

                function Gl() {}

                function Jl(e, t) {
                    var n = jl();
                    t = void 0 === t ? null : t;
                    var r = n.memoizedState;
                    return null !== r && null !== t && kl(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
                }

                function Xl(e, t) {
                    var n = jl();
                    t = void 0 === t ? null : t;
                    var r = n.memoizedState;
                    return null !== r && null !== t && kl(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
                }

                function Yl(e, t, n) {
                    return 0 === (21 & hl) ? (e.baseState && (e.baseState = !1, wi = !0), e.memoizedState = n) : (ir(n, t) || (n = mt(), ml.lanes |= n, Is |= n, e.baseState = !0), t)
                }

                function Zl(e, t) {
                    var n = bt;
                    bt = 0 !== n && 4 > n ? n : 4, e(!0);
                    var r = pl.transition;
                    pl.transition = {};
                    try {
                        e(!1), t()
                    } finally {
                        bt = n, pl.transition = r
                    }
                }

                function ei() {
                    return jl().memoizedState
                }

                function ti(e, t, n) {
                    var r = nu(e);
                    if (n = {
                            lane: r,
                            action: n,
                            hasEagerState: !1,
                            eagerState: null,
                            next: null
                        }, ri(e)) ai(t, n);
                    else if (null !== (n = To(e, t, n, r))) {
                        ru(n, e, r, tu()), oi(n, t, r)
                    }
                }

                function ni(e, t, n) {
                    var r = nu(e),
                        a = {
                            lane: r,
                            action: n,
                            hasEagerState: !1,
                            eagerState: null,
                            next: null
                        };
                    if (ri(e)) ai(t, a);
                    else {
                        var o = e.alternate;
                        if (0 === e.lanes && (null === o || 0 === o.lanes) && null !== (o = t.lastRenderedReducer)) try {
                            var l = t.lastRenderedState,
                                i = o(l, n);
                            if (a.hasEagerState = !0, a.eagerState = i, ir(i, l)) {
                                var s = t.interleaved;
                                return null === s ? (a.next = a, _o(t)) : (a.next = s.next, s.next = a), void(t.interleaved = a)
                            }
                        } catch (u) {}
                        null !== (n = To(e, t, a, r)) && (ru(n, e, r, a = tu()), oi(n, t, r))
                    }
                }

                function ri(e) {
                    var t = e.alternate;
                    return e === ml || null !== t && t === ml
                }

                function ai(e, t) {
                    bl = vl = !0;
                    var n = e.pending;
                    null === n ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
                }

                function oi(e, t, n) {
                    if (0 !== (4194240 & n)) {
                        var r = t.lanes;
                        n |= r &= e.pendingLanes, t.lanes = n, vt(e, n)
                    }
                }
                var li = {
                        readContext: No,
                        useCallback: Sl,
                        useContext: Sl,
                        useEffect: Sl,
                        useImperativeHandle: Sl,
                        useInsertionEffect: Sl,
                        useLayoutEffect: Sl,
                        useMemo: Sl,
                        useReducer: Sl,
                        useRef: Sl,
                        useState: Sl,
                        useDebugValue: Sl,
                        useDeferredValue: Sl,
                        useTransition: Sl,
                        useMutableSource: Sl,
                        useSyncExternalStore: Sl,
                        useId: Sl,
                        unstable_isNewReconciler: !1
                    },
                    ii = {
                        readContext: No,
                        useCallback: function(e, t) {
                            return Nl().memoizedState = [e, void 0 === t ? null : t], e
                        },
                        useContext: No,
                        useEffect: Wl,
                        useImperativeHandle: function(e, t, n) {
                            return n = null !== n && void 0 !== n ? n.concat([e]) : null, Bl(4194308, 4, Ql.bind(null, t, e), n)
                        },
                        useLayoutEffect: function(e, t) {
                            return Bl(4194308, 4, e, t)
                        },
                        useInsertionEffect: function(e, t) {
                            return Bl(4, 2, e, t)
                        },
                        useMemo: function(e, t) {
                            var n = Nl();
                            return t = void 0 === t ? null : t, e = e(), n.memoizedState = [e, t], e
                        },
                        useReducer: function(e, t, n) {
                            var r = Nl();
                            return t = void 0 !== n ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                                pending: null,
                                interleaved: null,
                                lanes: 0,
                                dispatch: null,
                                lastRenderedReducer: e,
                                lastRenderedState: t
                            }, r.queue = e, e = e.dispatch = ti.bind(null, ml, e), [r.memoizedState, e]
                        },
                        useRef: function(e) {
                            return e = {
                                current: e
                            }, Nl().memoizedState = e
                        },
                        useState: Fl,
                        useDebugValue: Gl,
                        useDeferredValue: function(e) {
                            return Nl().memoizedState = e
                        },
                        useTransition: function() {
                            var e = Fl(!1),
                                t = e[0];
                            return e = Zl.bind(null, e[1]), Nl().memoizedState = e, [t, e]
                        },
                        useMutableSource: function() {},
                        useSyncExternalStore: function(e, t, n) {
                            var r = ml,
                                a = Nl();
                            if (ao) {
                                if (void 0 === n) throw Error(o(407));
                                n = n()
                            } else {
                                if (n = t(), null === Ps) throw Error(o(349));
                                0 !== (30 & hl) || Ll(r, t, n)
                            }
                            a.memoizedState = n;
                            var l = {
                                value: n,
                                getSnapshot: t
                            };
                            return a.queue = l, Wl(Dl.bind(null, r, l, e), [e]), r.flags |= 2048, Ul(9, zl.bind(null, r, l, n, t), void 0, null), n
                        },
                        useId: function() {
                            var e = Nl(),
                                t = Ps.identifierPrefix;
                            if (ao) {
                                var n = Xa;
                                t = ":" + t + "R" + (n = (Ja & ~(1 << 32 - lt(Ja) - 1)).toString(32) + n), 0 < (n = wl++) && (t += "H" + n.toString(32)), t += ":"
                            } else t = ":" + t + "r" + (n = xl++).toString(32) + ":";
                            return e.memoizedState = t
                        },
                        unstable_isNewReconciler: !1
                    },
                    si = {
                        readContext: No,
                        useCallback: Jl,
                        useContext: No,
                        useEffect: Vl,
                        useImperativeHandle: Kl,
                        useInsertionEffect: $l,
                        useLayoutEffect: ql,
                        useMemo: Xl,
                        useReducer: Tl,
                        useRef: Ml,
                        useState: function() {
                            return Tl(_l)
                        },
                        useDebugValue: Gl,
                        useDeferredValue: function(e) {
                            return Yl(jl(), gl.memoizedState, e)
                        },
                        useTransition: function() {
                            return [Tl(_l)[0], jl().memoizedState]
                        },
                        useMutableSource: Ol,
                        useSyncExternalStore: Rl,
                        useId: ei,
                        unstable_isNewReconciler: !1
                    },
                    ui = {
                        readContext: No,
                        useCallback: Jl,
                        useContext: No,
                        useEffect: Vl,
                        useImperativeHandle: Kl,
                        useInsertionEffect: $l,
                        useLayoutEffect: ql,
                        useMemo: Xl,
                        useReducer: Pl,
                        useRef: Ml,
                        useState: function() {
                            return Pl(_l)
                        },
                        useDebugValue: Gl,
                        useDeferredValue: function(e) {
                            var t = jl();
                            return null === gl ? t.memoizedState = e : Yl(t, gl.memoizedState, e)
                        },
                        useTransition: function() {
                            return [Pl(_l)[0], jl().memoizedState]
                        },
                        useMutableSource: Ol,
                        useSyncExternalStore: Rl,
                        useId: ei,
                        unstable_isNewReconciler: !1
                    };

                function ci(e, t) {
                    try {
                        var n = "",
                            r = t;
                        do {
                            n += B(r), r = r.return
                        } while (r);
                        var a = n
                    } catch (o) {
                        a = "\nError generating stack: " + o.message + "\n" + o.stack
                    }
                    return {
                        value: e,
                        source: t,
                        stack: a,
                        digest: null
                    }
                }

                function di(e, t, n) {
                    return {
                        value: e,
                        source: null,
                        stack: null != n ? n : null,
                        digest: null != t ? t : null
                    }
                }

                function fi(e, t) {
                    try {
                        console.error(t.value)
                    } catch (n) {
                        setTimeout((function() {
                            throw n
                        }))
                    }
                }
                var pi = "function" === typeof WeakMap ? WeakMap : Map;

                function hi(e, t, n) {
                    (n = zo(-1, n)).tag = 3, n.payload = {
                        element: null
                    };
                    var r = t.value;
                    return n.callback = function() {
                        $s || ($s = !0, qs = r), fi(0, t)
                    }, n
                }

                function mi(e, t, n) {
                    (n = zo(-1, n)).tag = 3;
                    var r = e.type.getDerivedStateFromError;
                    if ("function" === typeof r) {
                        var a = t.value;
                        n.payload = function() {
                            return r(a)
                        }, n.callback = function() {
                            fi(0, t)
                        }
                    }
                    var o = e.stateNode;
                    return null !== o && "function" === typeof o.componentDidCatch && (n.callback = function() {
                        fi(0, t), "function" !== typeof r && (null === Qs ? Qs = new Set([this]) : Qs.add(this));
                        var e = t.stack;
                        this.componentDidCatch(t.value, {
                            componentStack: null !== e ? e : ""
                        })
                    }), n
                }

                function gi(e, t, n) {
                    var r = e.pingCache;
                    if (null === r) {
                        r = e.pingCache = new pi;
                        var a = new Set;
                        r.set(t, a)
                    } else void 0 === (a = r.get(t)) && (a = new Set, r.set(t, a));
                    a.has(n) || (a.add(n), e = Nu.bind(null, e, t, n), t.then(e, e))
                }

                function yi(e) {
                    do {
                        var t;
                        if ((t = 13 === e.tag) && (t = null === (t = e.memoizedState) || null !== t.dehydrated), t) return e;
                        e = e.return
                    } while (null !== e);
                    return null
                }

                function vi(e, t, n, r, a) {
                    return 0 === (1 & e.mode) ? (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, 1 === n.tag && (null === n.alternate ? n.tag = 17 : ((t = zo(-1, 1)).tag = 2, Do(n, t, 1))), n.lanes |= 1), e) : (e.flags |= 65536, e.lanes = a, e)
                }
                var bi = w.ReactCurrentOwner,
                    wi = !1;

                function xi(e, t, n, r) {
                    t.child = null === e ? Yo(t, null, n, r) : Xo(t, e.child, n, r)
                }

                function Si(e, t, n, r, a) {
                    n = n.render;
                    var o = t.ref;
                    return Co(t, a), r = El(e, t, n, r, o, a), n = Cl(), null === e || wi ? (ao && n && eo(t), t.flags |= 1, xi(e, t, r, a), t.child) : (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a, $i(e, t, a))
                }

                function ki(e, t, n, r, a) {
                    if (null === e) {
                        var o = n.type;
                        return "function" !== typeof o || Lu(o) || void 0 !== o.defaultProps || null !== n.compare || void 0 !== n.defaultProps ? ((e = Du(n.type, null, r, t, t.mode, a)).ref = t.ref, e.return = t, t.child = e) : (t.tag = 15, t.type = o, Ei(e, t, o, r, a))
                    }
                    if (o = e.child, 0 === (e.lanes & a)) {
                        var l = o.memoizedProps;
                        if ((n = null !== (n = n.compare) ? n : sr)(l, r) && e.ref === t.ref) return $i(e, t, a)
                    }
                    return t.flags |= 1, (e = zu(o, r)).ref = t.ref, e.return = t, t.child = e
                }

                function Ei(e, t, n, r, a) {
                    if (null !== e) {
                        var o = e.memoizedProps;
                        if (sr(o, r) && e.ref === t.ref) {
                            if (wi = !1, t.pendingProps = r = o, 0 === (e.lanes & a)) return t.lanes = e.lanes, $i(e, t, a);
                            0 !== (131072 & e.flags) && (wi = !0)
                        }
                    }
                    return ji(e, t, n, r, a)
                }

                function Ci(e, t, n) {
                    var r = t.pendingProps,
                        a = r.children,
                        o = null !== e ? e.memoizedState : null;
                    if ("hidden" === r.mode)
                        if (0 === (1 & t.mode)) t.memoizedState = {
                            baseLanes: 0,
                            cachePool: null,
                            transitions: null
                        }, Na(zs, Ls), Ls |= n;
                        else {
                            if (0 === (1073741824 & n)) return e = null !== o ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                                baseLanes: e,
                                cachePool: null,
                                transitions: null
                            }, t.updateQueue = null, Na(zs, Ls), Ls |= e, null;
                            t.memoizedState = {
                                baseLanes: 0,
                                cachePool: null,
                                transitions: null
                            }, r = null !== o ? o.baseLanes : n, Na(zs, Ls), Ls |= r
                        }
                    else null !== o ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, Na(zs, Ls), Ls |= r;
                    return xi(e, t, a, n), t.child
                }

                function Ni(e, t) {
                    var n = t.ref;
                    (null === e && null !== n || null !== e && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
                }

                function ji(e, t, n, r, a) {
                    var o = Ra(n) ? Pa : _a.current;
                    return o = Oa(t, o), Co(t, a), n = El(e, t, n, r, o, a), r = Cl(), null === e || wi ? (ao && r && eo(t), t.flags |= 1, xi(e, t, n, a), t.child) : (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a, $i(e, t, a))
                }

                function _i(e, t, n, r, a) {
                    if (Ra(n)) {
                        var o = !0;
                        Aa(t)
                    } else o = !1;
                    if (Co(t, a), null === t.stateNode) Vi(e, t), Vo(t, n, r), qo(t, n, r, a), r = !0;
                    else if (null === e) {
                        var l = t.stateNode,
                            i = t.memoizedProps;
                        l.props = i;
                        var s = l.context,
                            u = n.contextType;
                        "object" === typeof u && null !== u ? u = No(u) : u = Oa(t, u = Ra(n) ? Pa : _a.current);
                        var c = n.getDerivedStateFromProps,
                            d = "function" === typeof c || "function" === typeof l.getSnapshotBeforeUpdate;
                        d || "function" !== typeof l.UNSAFE_componentWillReceiveProps && "function" !== typeof l.componentWillReceiveProps || (i !== r || s !== u) && $o(t, l, r, u), Oo = !1;
                        var f = t.memoizedState;
                        l.state = f, Fo(t, r, l, a), s = t.memoizedState, i !== r || f !== s || Ta.current || Oo ? ("function" === typeof c && (Bo(t, n, c, r), s = t.memoizedState), (i = Oo || Wo(t, n, i, r, f, s, u)) ? (d || "function" !== typeof l.UNSAFE_componentWillMount && "function" !== typeof l.componentWillMount || ("function" === typeof l.componentWillMount && l.componentWillMount(), "function" === typeof l.UNSAFE_componentWillMount && l.UNSAFE_componentWillMount()), "function" === typeof l.componentDidMount && (t.flags |= 4194308)) : ("function" === typeof l.componentDidMount && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = s), l.props = r, l.state = s, l.context = u, r = i) : ("function" === typeof l.componentDidMount && (t.flags |= 4194308), r = !1)
                    } else {
                        l = t.stateNode, Lo(e, t), i = t.memoizedProps, u = t.type === t.elementType ? i : yo(t.type, i), l.props = u, d = t.pendingProps, f = l.context, "object" === typeof(s = n.contextType) && null !== s ? s = No(s) : s = Oa(t, s = Ra(n) ? Pa : _a.current);
                        var p = n.getDerivedStateFromProps;
                        (c = "function" === typeof p || "function" === typeof l.getSnapshotBeforeUpdate) || "function" !== typeof l.UNSAFE_componentWillReceiveProps && "function" !== typeof l.componentWillReceiveProps || (i !== d || f !== s) && $o(t, l, r, s), Oo = !1, f = t.memoizedState, l.state = f, Fo(t, r, l, a);
                        var h = t.memoizedState;
                        i !== d || f !== h || Ta.current || Oo ? ("function" === typeof p && (Bo(t, n, p, r), h = t.memoizedState), (u = Oo || Wo(t, n, u, r, f, h, s) || !1) ? (c || "function" !== typeof l.UNSAFE_componentWillUpdate && "function" !== typeof l.componentWillUpdate || ("function" === typeof l.componentWillUpdate && l.componentWillUpdate(r, h, s), "function" === typeof l.UNSAFE_componentWillUpdate && l.UNSAFE_componentWillUpdate(r, h, s)), "function" === typeof l.componentDidUpdate && (t.flags |= 4), "function" === typeof l.getSnapshotBeforeUpdate && (t.flags |= 1024)) : ("function" !== typeof l.componentDidUpdate || i === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" !== typeof l.getSnapshotBeforeUpdate || i === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = h), l.props = r, l.state = h, l.context = s, r = u) : ("function" !== typeof l.componentDidUpdate || i === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), "function" !== typeof l.getSnapshotBeforeUpdate || i === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
                    }
                    return Ti(e, t, n, r, o, a)
                }

                function Ti(e, t, n, r, a, o) {
                    Ni(e, t);
                    var l = 0 !== (128 & t.flags);
                    if (!r && !l) return a && Ia(t, n, !1), $i(e, t, o);
                    r = t.stateNode, bi.current = t;
                    var i = l && "function" !== typeof n.getDerivedStateFromError ? null : r.render();
                    return t.flags |= 1, null !== e && l ? (t.child = Xo(t, e.child, null, o), t.child = Xo(t, null, i, o)) : xi(e, t, i, o), t.memoizedState = r.state, a && Ia(t, n, !0), t.child
                }

                function Pi(e) {
                    var t = e.stateNode;
                    t.pendingContext ? za(0, t.pendingContext, t.pendingContext !== t.context) : t.context && za(0, t.context, !1), al(e, t.containerInfo)
                }

                function Oi(e, t, n, r, a) {
                    return ho(), mo(a), t.flags |= 256, xi(e, t, n, r), t.child
                }
                var Ri, Li, zi, Di, Ai = {
                    dehydrated: null,
                    treeContext: null,
                    retryLane: 0
                };

                function Ii(e) {
                    return {
                        baseLanes: e,
                        cachePool: null,
                        transitions: null
                    }
                }

                function Fi(e, t, n) {
                    var r, a = t.pendingProps,
                        l = sl.current,
                        i = !1,
                        s = 0 !== (128 & t.flags);
                    if ((r = s) || (r = (null === e || null !== e.memoizedState) && 0 !== (2 & l)), r ? (i = !0, t.flags &= -129) : null !== e && null === e.memoizedState || (l |= 1), Na(sl, 1 & l), null === e) return uo(t), null !== (e = t.memoizedState) && null !== (e = e.dehydrated) ? (0 === (1 & t.mode) ? t.lanes = 1 : "$!" === e.data ? t.lanes = 8 : t.lanes = 1073741824, null) : (s = a.children, e = a.fallback, i ? (a = t.mode, i = t.child, s = {
                        mode: "hidden",
                        children: s
                    }, 0 === (1 & a) && null !== i ? (i.childLanes = 0, i.pendingProps = s) : i = Iu(s, a, 0, null), e = Au(e, a, n, null), i.return = t, e.return = t, i.sibling = e, t.child = i, t.child.memoizedState = Ii(n), t.memoizedState = Ai, e) : Ui(t, s));
                    if (null !== (l = e.memoizedState) && null !== (r = l.dehydrated)) return function(e, t, n, r, a, l, i) {
                        if (n) return 256 & t.flags ? (t.flags &= -257, Mi(e, t, i, r = di(Error(o(422))))) : null !== t.memoizedState ? (t.child = e.child, t.flags |= 128, null) : (l = r.fallback, a = t.mode, r = Iu({
                            mode: "visible",
                            children: r.children
                        }, a, 0, null), (l = Au(l, a, i, null)).flags |= 2, r.return = t, l.return = t, r.sibling = l, t.child = r, 0 !== (1 & t.mode) && Xo(t, e.child, null, i), t.child.memoizedState = Ii(i), t.memoizedState = Ai, l);
                        if (0 === (1 & t.mode)) return Mi(e, t, i, null);
                        if ("$!" === a.data) {
                            if (r = a.nextSibling && a.nextSibling.dataset) var s = r.dgst;
                            return r = s, Mi(e, t, i, r = di(l = Error(o(419)), r, void 0))
                        }
                        if (s = 0 !== (i & e.childLanes), wi || s) {
                            if (null !== (r = Ps)) {
                                switch (i & -i) {
                                    case 4:
                                        a = 2;
                                        break;
                                    case 16:
                                        a = 8;
                                        break;
                                    case 64:
                                    case 128:
                                    case 256:
                                    case 512:
                                    case 1024:
                                    case 2048:
                                    case 4096:
                                    case 8192:
                                    case 16384:
                                    case 32768:
                                    case 65536:
                                    case 131072:
                                    case 262144:
                                    case 524288:
                                    case 1048576:
                                    case 2097152:
                                    case 4194304:
                                    case 8388608:
                                    case 16777216:
                                    case 33554432:
                                    case 67108864:
                                        a = 32;
                                        break;
                                    case 536870912:
                                        a = 268435456;
                                        break;
                                    default:
                                        a = 0
                                }
                                0 !== (a = 0 !== (a & (r.suspendedLanes | i)) ? 0 : a) && a !== l.retryLane && (l.retryLane = a, Po(e, a), ru(r, e, a, -1))
                            }
                            return gu(), Mi(e, t, i, r = di(Error(o(421))))
                        }
                        return "$?" === a.data ? (t.flags |= 128, t.child = e.child, t = _u.bind(null, e), a._reactRetry = t, null) : (e = l.treeContext, ro = ua(a.nextSibling), no = t, ao = !0, oo = null, null !== e && (Qa[Ka++] = Ja, Qa[Ka++] = Xa, Qa[Ka++] = Ga, Ja = e.id, Xa = e.overflow, Ga = t), t = Ui(t, r.children), t.flags |= 4096, t)
                    }(e, t, s, a, r, l, n);
                    if (i) {
                        i = a.fallback, s = t.mode, r = (l = e.child).sibling;
                        var u = {
                            mode: "hidden",
                            children: a.children
                        };
                        return 0 === (1 & s) && t.child !== l ? ((a = t.child).childLanes = 0, a.pendingProps = u, t.deletions = null) : (a = zu(l, u)).subtreeFlags = 14680064 & l.subtreeFlags, null !== r ? i = zu(r, i) : (i = Au(i, s, n, null)).flags |= 2, i.return = t, a.return = t, a.sibling = i, t.child = a, a = i, i = t.child, s = null === (s = e.child.memoizedState) ? Ii(n) : {
                            baseLanes: s.baseLanes | n,
                            cachePool: null,
                            transitions: s.transitions
                        }, i.memoizedState = s, i.childLanes = e.childLanes & ~n, t.memoizedState = Ai, a
                    }
                    return e = (i = e.child).sibling, a = zu(i, {
                        mode: "visible",
                        children: a.children
                    }), 0 === (1 & t.mode) && (a.lanes = n), a.return = t, a.sibling = null, null !== e && (null === (n = t.deletions) ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = a, t.memoizedState = null, a
                }

                function Ui(e, t) {
                    return (t = Iu({
                        mode: "visible",
                        children: t
                    }, e.mode, 0, null)).return = e, e.child = t
                }

                function Mi(e, t, n, r) {
                    return null !== r && mo(r), Xo(t, e.child, null, n), (e = Ui(t, t.pendingProps.children)).flags |= 2, t.memoizedState = null, e
                }

                function Bi(e, t, n) {
                    e.lanes |= t;
                    var r = e.alternate;
                    null !== r && (r.lanes |= t), Eo(e.return, t, n)
                }

                function Hi(e, t, n, r, a) {
                    var o = e.memoizedState;
                    null === o ? e.memoizedState = {
                        isBackwards: t,
                        rendering: null,
                        renderingStartTime: 0,
                        last: r,
                        tail: n,
                        tailMode: a
                    } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = a)
                }

                function Wi(e, t, n) {
                    var r = t.pendingProps,
                        a = r.revealOrder,
                        o = r.tail;
                    if (xi(e, t, r.children, n), 0 !== (2 & (r = sl.current))) r = 1 & r | 2, t.flags |= 128;
                    else {
                        if (null !== e && 0 !== (128 & e.flags)) e: for (e = t.child; null !== e;) {
                            if (13 === e.tag) null !== e.memoizedState && Bi(e, n, t);
                            else if (19 === e.tag) Bi(e, n, t);
                            else if (null !== e.child) {
                                e.child.return = e, e = e.child;
                                continue
                            }
                            if (e === t) break e;
                            for (; null === e.sibling;) {
                                if (null === e.return || e.return === t) break e;
                                e = e.return
                            }
                            e.sibling.return = e.return, e = e.sibling
                        }
                        r &= 1
                    }
                    if (Na(sl, r), 0 === (1 & t.mode)) t.memoizedState = null;
                    else switch (a) {
                        case "forwards":
                            for (n = t.child, a = null; null !== n;) null !== (e = n.alternate) && null === ul(e) && (a = n), n = n.sibling;
                            null === (n = a) ? (a = t.child, t.child = null) : (a = n.sibling, n.sibling = null), Hi(t, !1, a, n, o);
                            break;
                        case "backwards":
                            for (n = null, a = t.child, t.child = null; null !== a;) {
                                if (null !== (e = a.alternate) && null === ul(e)) {
                                    t.child = a;
                                    break
                                }
                                e = a.sibling, a.sibling = n, n = a, a = e
                            }
                            Hi(t, !0, n, null, o);
                            break;
                        case "together":
                            Hi(t, !1, null, null, void 0);
                            break;
                        default:
                            t.memoizedState = null
                    }
                    return t.child
                }

                function Vi(e, t) {
                    0 === (1 & t.mode) && null !== e && (e.alternate = null, t.alternate = null, t.flags |= 2)
                }

                function $i(e, t, n) {
                    if (null !== e && (t.dependencies = e.dependencies), Is |= t.lanes, 0 === (n & t.childLanes)) return null;
                    if (null !== e && t.child !== e.child) throw Error(o(153));
                    if (null !== t.child) {
                        for (n = zu(e = t.child, e.pendingProps), t.child = n, n.return = t; null !== e.sibling;) e = e.sibling, (n = n.sibling = zu(e, e.pendingProps)).return = t;
                        n.sibling = null
                    }
                    return t.child
                }

                function qi(e, t) {
                    if (!ao) switch (e.tailMode) {
                        case "hidden":
                            t = e.tail;
                            for (var n = null; null !== t;) null !== t.alternate && (n = t), t = t.sibling;
                            null === n ? e.tail = null : n.sibling = null;
                            break;
                        case "collapsed":
                            n = e.tail;
                            for (var r = null; null !== n;) null !== n.alternate && (r = n), n = n.sibling;
                            null === r ? t || null === e.tail ? e.tail = null : e.tail.sibling = null : r.sibling = null
                    }
                }

                function Qi(e) {
                    var t = null !== e.alternate && e.alternate.child === e.child,
                        n = 0,
                        r = 0;
                    if (t)
                        for (var a = e.child; null !== a;) n |= a.lanes | a.childLanes, r |= 14680064 & a.subtreeFlags, r |= 14680064 & a.flags, a.return = e, a = a.sibling;
                    else
                        for (a = e.child; null !== a;) n |= a.lanes | a.childLanes, r |= a.subtreeFlags, r |= a.flags, a.return = e, a = a.sibling;
                    return e.subtreeFlags |= r, e.childLanes = n, t
                }

                function Ki(e, t, n) {
                    var r = t.pendingProps;
                    switch (to(t), t.tag) {
                        case 2:
                        case 16:
                        case 15:
                        case 0:
                        case 11:
                        case 7:
                        case 8:
                        case 12:
                        case 9:
                        case 14:
                            return Qi(t), null;
                        case 1:
                        case 17:
                            return Ra(t.type) && La(), Qi(t), null;
                        case 3:
                            return r = t.stateNode, ol(), Ca(Ta), Ca(_a), dl(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), null !== e && null !== e.child || (fo(t) ? t.flags |= 4 : null === e || e.memoizedState.isDehydrated && 0 === (256 & t.flags) || (t.flags |= 1024, null !== oo && (iu(oo), oo = null))), Li(e, t), Qi(t), null;
                        case 5:
                            il(t);
                            var a = rl(nl.current);
                            if (n = t.type, null !== e && null != t.stateNode) zi(e, t, n, r, a), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
                            else {
                                if (!r) {
                                    if (null === t.stateNode) throw Error(o(166));
                                    return Qi(t), null
                                }
                                if (e = rl(el.current), fo(t)) {
                                    r = t.stateNode, n = t.type;
                                    var l = t.memoizedProps;
                                    switch (r[fa] = t, r[pa] = l, e = 0 !== (1 & t.mode), n) {
                                        case "dialog":
                                            Ur("cancel", r), Ur("close", r);
                                            break;
                                        case "iframe":
                                        case "object":
                                        case "embed":
                                            Ur("load", r);
                                            break;
                                        case "video":
                                        case "audio":
                                            for (a = 0; a < Dr.length; a++) Ur(Dr[a], r);
                                            break;
                                        case "source":
                                            Ur("error", r);
                                            break;
                                        case "img":
                                        case "image":
                                        case "link":
                                            Ur("error", r), Ur("load", r);
                                            break;
                                        case "details":
                                            Ur("toggle", r);
                                            break;
                                        case "input":
                                            J(r, l), Ur("invalid", r);
                                            break;
                                        case "select":
                                            r._wrapperState = {
                                                wasMultiple: !!l.multiple
                                            }, Ur("invalid", r);
                                            break;
                                        case "textarea":
                                            ae(r, l), Ur("invalid", r)
                                    }
                                    for (var s in ve(n, l), a = null, l)
                                        if (l.hasOwnProperty(s)) {
                                            var u = l[s];
                                            "children" === s ? "string" === typeof u ? r.textContent !== u && (!0 !== l.suppressHydrationWarning && Yr(r.textContent, u, e), a = ["children", u]) : "number" === typeof u && r.textContent !== "" + u && (!0 !== l.suppressHydrationWarning && Yr(r.textContent, u, e), a = ["children", "" + u]) : i.hasOwnProperty(s) && null != u && "onScroll" === s && Ur("scroll", r)
                                        }
                                    switch (n) {
                                        case "input":
                                            q(r), Z(r, l, !0);
                                            break;
                                        case "textarea":
                                            q(r), le(r);
                                            break;
                                        case "select":
                                        case "option":
                                            break;
                                        default:
                                            "function" === typeof l.onClick && (r.onclick = Zr)
                                    }
                                    r = a, t.updateQueue = r, null !== r && (t.flags |= 4)
                                } else {
                                    s = 9 === a.nodeType ? a : a.ownerDocument, "http://www.w3.org/1999/xhtml" === e && (e = ie(n)), "http://www.w3.org/1999/xhtml" === e ? "script" === n ? ((e = s.createElement("div")).innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : "string" === typeof r.is ? e = s.createElement(n, {
                                        is: r.is
                                    }) : (e = s.createElement(n), "select" === n && (s = e, r.multiple ? s.multiple = !0 : r.size && (s.size = r.size))) : e = s.createElementNS(e, n), e[fa] = t, e[pa] = r, Ri(e, t, !1, !1), t.stateNode = e;
                                    e: {
                                        switch (s = be(n, r), n) {
                                            case "dialog":
                                                Ur("cancel", e), Ur("close", e), a = r;
                                                break;
                                            case "iframe":
                                            case "object":
                                            case "embed":
                                                Ur("load", e), a = r;
                                                break;
                                            case "video":
                                            case "audio":
                                                for (a = 0; a < Dr.length; a++) Ur(Dr[a], e);
                                                a = r;
                                                break;
                                            case "source":
                                                Ur("error", e), a = r;
                                                break;
                                            case "img":
                                            case "image":
                                            case "link":
                                                Ur("error", e), Ur("load", e), a = r;
                                                break;
                                            case "details":
                                                Ur("toggle", e), a = r;
                                                break;
                                            case "input":
                                                J(e, r), a = G(e, r), Ur("invalid", e);
                                                break;
                                            case "option":
                                            default:
                                                a = r;
                                                break;
                                            case "select":
                                                e._wrapperState = {
                                                    wasMultiple: !!r.multiple
                                                }, a = I({}, r, {
                                                    value: void 0
                                                }), Ur("invalid", e);
                                                break;
                                            case "textarea":
                                                ae(e, r), a = re(e, r), Ur("invalid", e)
                                        }
                                        for (l in ve(n, a), u = a)
                                            if (u.hasOwnProperty(l)) {
                                                var c = u[l];
                                                "style" === l ? ge(e, c) : "dangerouslySetInnerHTML" === l ? null != (c = c ? c.__html : void 0) && de(e, c) : "children" === l ? "string" === typeof c ? ("textarea" !== n || "" !== c) && fe(e, c) : "number" === typeof c && fe(e, "" + c) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (i.hasOwnProperty(l) ? null != c && "onScroll" === l && Ur("scroll", e) : null != c && b(e, l, c, s))
                                            }
                                        switch (n) {
                                            case "input":
                                                q(e), Z(e, r, !1);
                                                break;
                                            case "textarea":
                                                q(e), le(e);
                                                break;
                                            case "option":
                                                null != r.value && e.setAttribute("value", "" + V(r.value));
                                                break;
                                            case "select":
                                                e.multiple = !!r.multiple, null != (l = r.value) ? ne(e, !!r.multiple, l, !1) : null != r.defaultValue && ne(e, !!r.multiple, r.defaultValue, !0);
                                                break;
                                            default:
                                                "function" === typeof a.onClick && (e.onclick = Zr)
                                        }
                                        switch (n) {
                                            case "button":
                                            case "input":
                                            case "select":
                                            case "textarea":
                                                r = !!r.autoFocus;
                                                break e;
                                            case "img":
                                                r = !0;
                                                break e;
                                            default:
                                                r = !1
                                        }
                                    }
                                    r && (t.flags |= 4)
                                }
                                null !== t.ref && (t.flags |= 512, t.flags |= 2097152)
                            }
                            return Qi(t), null;
                        case 6:
                            if (e && null != t.stateNode) Di(e, t, e.memoizedProps, r);
                            else {
                                if ("string" !== typeof r && null === t.stateNode) throw Error(o(166));
                                if (n = rl(nl.current), rl(el.current), fo(t)) {
                                    if (r = t.stateNode, n = t.memoizedProps, r[fa] = t, (l = r.nodeValue !== n) && null !== (e = no)) switch (e.tag) {
                                        case 3:
                                            Yr(r.nodeValue, n, 0 !== (1 & e.mode));
                                            break;
                                        case 5:
                                            !0 !== e.memoizedProps.suppressHydrationWarning && Yr(r.nodeValue, n, 0 !== (1 & e.mode))
                                    }
                                    l && (t.flags |= 4)
                                } else(r = (9 === n.nodeType ? n : n.ownerDocument).createTextNode(r))[fa] = t, t.stateNode = r
                            }
                            return Qi(t), null;
                        case 13:
                            if (Ca(sl), r = t.memoizedState, null === e || null !== e.memoizedState && null !== e.memoizedState.dehydrated) {
                                if (ao && null !== ro && 0 !== (1 & t.mode) && 0 === (128 & t.flags)) po(), ho(), t.flags |= 98560, l = !1;
                                else if (l = fo(t), null !== r && null !== r.dehydrated) {
                                    if (null === e) {
                                        if (!l) throw Error(o(318));
                                        if (!(l = null !== (l = t.memoizedState) ? l.dehydrated : null)) throw Error(o(317));
                                        l[fa] = t
                                    } else ho(), 0 === (128 & t.flags) && (t.memoizedState = null), t.flags |= 4;
                                    Qi(t), l = !1
                                } else null !== oo && (iu(oo), oo = null), l = !0;
                                if (!l) return 65536 & t.flags ? t : null
                            }
                            return 0 !== (128 & t.flags) ? (t.lanes = n, t) : ((r = null !== r) !== (null !== e && null !== e.memoizedState) && r && (t.child.flags |= 8192, 0 !== (1 & t.mode) && (null === e || 0 !== (1 & sl.current) ? 0 === Ds && (Ds = 3) : gu())), null !== t.updateQueue && (t.flags |= 4), Qi(t), null);
                        case 4:
                            return ol(), Li(e, t), null === e && Hr(t.stateNode.containerInfo), Qi(t), null;
                        case 10:
                            return ko(t.type._context), Qi(t), null;
                        case 19:
                            if (Ca(sl), null === (l = t.memoizedState)) return Qi(t), null;
                            if (r = 0 !== (128 & t.flags), null === (s = l.rendering))
                                if (r) qi(l, !1);
                                else {
                                    if (0 !== Ds || null !== e && 0 !== (128 & e.flags))
                                        for (e = t.child; null !== e;) {
                                            if (null !== (s = ul(e))) {
                                                for (t.flags |= 128, qi(l, !1), null !== (r = s.updateQueue) && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; null !== n;) e = r, (l = n).flags &= 14680066, null === (s = l.alternate) ? (l.childLanes = 0, l.lanes = e, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = s.childLanes, l.lanes = s.lanes, l.child = s.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = s.memoizedProps, l.memoizedState = s.memoizedState, l.updateQueue = s.updateQueue, l.type = s.type, e = s.dependencies, l.dependencies = null === e ? null : {
                                                    lanes: e.lanes,
                                                    firstContext: e.firstContext
                                                }), n = n.sibling;
                                                return Na(sl, 1 & sl.current | 2), t.child
                                            }
                                            e = e.sibling
                                        }
                                    null !== l.tail && Xe() > Ws && (t.flags |= 128, r = !0, qi(l, !1), t.lanes = 4194304)
                                }
                            else {
                                if (!r)
                                    if (null !== (e = ul(s))) {
                                        if (t.flags |= 128, r = !0, null !== (n = e.updateQueue) && (t.updateQueue = n, t.flags |= 4), qi(l, !0), null === l.tail && "hidden" === l.tailMode && !s.alternate && !ao) return Qi(t), null
                                    } else 2 * Xe() - l.renderingStartTime > Ws && 1073741824 !== n && (t.flags |= 128, r = !0, qi(l, !1), t.lanes = 4194304);
                                l.isBackwards ? (s.sibling = t.child, t.child = s) : (null !== (n = l.last) ? n.sibling = s : t.child = s, l.last = s)
                            }
                            return null !== l.tail ? (t = l.tail, l.rendering = t, l.tail = t.sibling, l.renderingStartTime = Xe(), t.sibling = null, n = sl.current, Na(sl, r ? 1 & n | 2 : 1 & n), t) : (Qi(t), null);
                        case 22:
                        case 23:
                            return fu(), r = null !== t.memoizedState, null !== e && null !== e.memoizedState !== r && (t.flags |= 8192), r && 0 !== (1 & t.mode) ? 0 !== (1073741824 & Ls) && (Qi(t), 6 & t.subtreeFlags && (t.flags |= 8192)) : Qi(t), null;
                        case 24:
                        case 25:
                            return null
                    }
                    throw Error(o(156, t.tag))
                }

                function Gi(e, t) {
                    switch (to(t), t.tag) {
                        case 1:
                            return Ra(t.type) && La(), 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
                        case 3:
                            return ol(), Ca(Ta), Ca(_a), dl(), 0 !== (65536 & (e = t.flags)) && 0 === (128 & e) ? (t.flags = -65537 & e | 128, t) : null;
                        case 5:
                            return il(t), null;
                        case 13:
                            if (Ca(sl), null !== (e = t.memoizedState) && null !== e.dehydrated) {
                                if (null === t.alternate) throw Error(o(340));
                                ho()
                            }
                            return 65536 & (e = t.flags) ? (t.flags = -65537 & e | 128, t) : null;
                        case 19:
                            return Ca(sl), null;
                        case 4:
                            return ol(), null;
                        case 10:
                            return ko(t.type._context), null;
                        case 22:
                        case 23:
                            return fu(), null;
                        default:
                            return null
                    }
                }
                Ri = function(e, t) {
                    for (var n = t.child; null !== n;) {
                        if (5 === n.tag || 6 === n.tag) e.appendChild(n.stateNode);
                        else if (4 !== n.tag && null !== n.child) {
                            n.child.return = n, n = n.child;
                            continue
                        }
                        if (n === t) break;
                        for (; null === n.sibling;) {
                            if (null === n.return || n.return === t) return;
                            n = n.return
                        }
                        n.sibling.return = n.return, n = n.sibling
                    }
                }, Li = function() {}, zi = function(e, t, n, r) {
                    var a = e.memoizedProps;
                    if (a !== r) {
                        e = t.stateNode, rl(el.current);
                        var o, l = null;
                        switch (n) {
                            case "input":
                                a = G(e, a), r = G(e, r), l = [];
                                break;
                            case "select":
                                a = I({}, a, {
                                    value: void 0
                                }), r = I({}, r, {
                                    value: void 0
                                }), l = [];
                                break;
                            case "textarea":
                                a = re(e, a), r = re(e, r), l = [];
                                break;
                            default:
                                "function" !== typeof a.onClick && "function" === typeof r.onClick && (e.onclick = Zr)
                        }
                        for (c in ve(n, r), n = null, a)
                            if (!r.hasOwnProperty(c) && a.hasOwnProperty(c) && null != a[c])
                                if ("style" === c) {
                                    var s = a[c];
                                    for (o in s) s.hasOwnProperty(o) && (n || (n = {}), n[o] = "")
                                } else "dangerouslySetInnerHTML" !== c && "children" !== c && "suppressContentEditableWarning" !== c && "suppressHydrationWarning" !== c && "autoFocus" !== c && (i.hasOwnProperty(c) ? l || (l = []) : (l = l || []).push(c, null));
                        for (c in r) {
                            var u = r[c];
                            if (s = null != a ? a[c] : void 0, r.hasOwnProperty(c) && u !== s && (null != u || null != s))
                                if ("style" === c)
                                    if (s) {
                                        for (o in s) !s.hasOwnProperty(o) || u && u.hasOwnProperty(o) || (n || (n = {}), n[o] = "");
                                        for (o in u) u.hasOwnProperty(o) && s[o] !== u[o] && (n || (n = {}), n[o] = u[o])
                                    } else n || (l || (l = []), l.push(c, n)), n = u;
                            else "dangerouslySetInnerHTML" === c ? (u = u ? u.__html : void 0, s = s ? s.__html : void 0, null != u && s !== u && (l = l || []).push(c, u)) : "children" === c ? "string" !== typeof u && "number" !== typeof u || (l = l || []).push(c, "" + u) : "suppressContentEditableWarning" !== c && "suppressHydrationWarning" !== c && (i.hasOwnProperty(c) ? (null != u && "onScroll" === c && Ur("scroll", e), l || s === u || (l = [])) : (l = l || []).push(c, u))
                        }
                        n && (l = l || []).push("style", n);
                        var c = l;
                        (t.updateQueue = c) && (t.flags |= 4)
                    }
                }, Di = function(e, t, n, r) {
                    n !== r && (t.flags |= 4)
                };
                var Ji = !1,
                    Xi = !1,
                    Yi = "function" === typeof WeakSet ? WeakSet : Set,
                    Zi = null;

                function es(e, t) {
                    var n = e.ref;
                    if (null !== n)
                        if ("function" === typeof n) try {
                            n(null)
                        } catch (r) {
                            Cu(e, t, r)
                        } else n.current = null
                }

                function ts(e, t, n) {
                    try {
                        n()
                    } catch (r) {
                        Cu(e, t, r)
                    }
                }
                var ns = !1;

                function rs(e, t, n) {
                    var r = t.updateQueue;
                    if (null !== (r = null !== r ? r.lastEffect : null)) {
                        var a = r = r.next;
                        do {
                            if ((a.tag & e) === e) {
                                var o = a.destroy;
                                a.destroy = void 0, void 0 !== o && ts(t, n, o)
                            }
                            a = a.next
                        } while (a !== r)
                    }
                }

                function as(e, t) {
                    if (null !== (t = null !== (t = t.updateQueue) ? t.lastEffect : null)) {
                        var n = t = t.next;
                        do {
                            if ((n.tag & e) === e) {
                                var r = n.create;
                                n.destroy = r()
                            }
                            n = n.next
                        } while (n !== t)
                    }
                }

                function os(e) {
                    var t = e.ref;
                    if (null !== t) {
                        var n = e.stateNode;
                        e.tag, e = n, "function" === typeof t ? t(e) : t.current = e
                    }
                }

                function ls(e) {
                    var t = e.alternate;
                    null !== t && (e.alternate = null, ls(t)), e.child = null, e.deletions = null, e.sibling = null, 5 === e.tag && (null !== (t = e.stateNode) && (delete t[fa], delete t[pa], delete t[ma], delete t[ga], delete t[ya])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
                }

                function is(e) {
                    return 5 === e.tag || 3 === e.tag || 4 === e.tag
                }

                function ss(e) {
                    e: for (;;) {
                        for (; null === e.sibling;) {
                            if (null === e.return || is(e.return)) return null;
                            e = e.return
                        }
                        for (e.sibling.return = e.return, e = e.sibling; 5 !== e.tag && 6 !== e.tag && 18 !== e.tag;) {
                            if (2 & e.flags) continue e;
                            if (null === e.child || 4 === e.tag) continue e;
                            e.child.return = e, e = e.child
                        }
                        if (!(2 & e.flags)) return e.stateNode
                    }
                }

                function us(e, t, n) {
                    var r = e.tag;
                    if (5 === r || 6 === r) e = e.stateNode, t ? 8 === n.nodeType ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (8 === n.nodeType ? (t = n.parentNode).insertBefore(e, n) : (t = n).appendChild(e), null !== (n = n._reactRootContainer) && void 0 !== n || null !== t.onclick || (t.onclick = Zr));
                    else if (4 !== r && null !== (e = e.child))
                        for (us(e, t, n), e = e.sibling; null !== e;) us(e, t, n), e = e.sibling
                }

                function cs(e, t, n) {
                    var r = e.tag;
                    if (5 === r || 6 === r) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
                    else if (4 !== r && null !== (e = e.child))
                        for (cs(e, t, n), e = e.sibling; null !== e;) cs(e, t, n), e = e.sibling
                }
                var ds = null,
                    fs = !1;

                function ps(e, t, n) {
                    for (n = n.child; null !== n;) hs(e, t, n), n = n.sibling
                }

                function hs(e, t, n) {
                    if (ot && "function" === typeof ot.onCommitFiberUnmount) try {
                        ot.onCommitFiberUnmount(at, n)
                    } catch (i) {}
                    switch (n.tag) {
                        case 5:
                            Xi || es(n, t);
                        case 6:
                            var r = ds,
                                a = fs;
                            ds = null, ps(e, t, n), fs = a, null !== (ds = r) && (fs ? (e = ds, n = n.stateNode, 8 === e.nodeType ? e.parentNode.removeChild(n) : e.removeChild(n)) : ds.removeChild(n.stateNode));
                            break;
                        case 18:
                            null !== ds && (fs ? (e = ds, n = n.stateNode, 8 === e.nodeType ? sa(e.parentNode, n) : 1 === e.nodeType && sa(e, n), Ht(e)) : sa(ds, n.stateNode));
                            break;
                        case 4:
                            r = ds, a = fs, ds = n.stateNode.containerInfo, fs = !0, ps(e, t, n), ds = r, fs = a;
                            break;
                        case 0:
                        case 11:
                        case 14:
                        case 15:
                            if (!Xi && (null !== (r = n.updateQueue) && null !== (r = r.lastEffect))) {
                                a = r = r.next;
                                do {
                                    var o = a,
                                        l = o.destroy;
                                    o = o.tag, void 0 !== l && (0 !== (2 & o) || 0 !== (4 & o)) && ts(n, t, l), a = a.next
                                } while (a !== r)
                            }
                            ps(e, t, n);
                            break;
                        case 1:
                            if (!Xi && (es(n, t), "function" === typeof(r = n.stateNode).componentWillUnmount)) try {
                                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
                            } catch (i) {
                                Cu(n, t, i)
                            }
                            ps(e, t, n);
                            break;
                        case 21:
                            ps(e, t, n);
                            break;
                        case 22:
                            1 & n.mode ? (Xi = (r = Xi) || null !== n.memoizedState, ps(e, t, n), Xi = r) : ps(e, t, n);
                            break;
                        default:
                            ps(e, t, n)
                    }
                }

                function ms(e) {
                    var t = e.updateQueue;
                    if (null !== t) {
                        e.updateQueue = null;
                        var n = e.stateNode;
                        null === n && (n = e.stateNode = new Yi), t.forEach((function(t) {
                            var r = Tu.bind(null, e, t);
                            n.has(t) || (n.add(t), t.then(r, r))
                        }))
                    }
                }

                function gs(e, t) {
                    var n = t.deletions;
                    if (null !== n)
                        for (var r = 0; r < n.length; r++) {
                            var a = n[r];
                            try {
                                var l = e,
                                    i = t,
                                    s = i;
                                e: for (; null !== s;) {
                                    switch (s.tag) {
                                        case 5:
                                            ds = s.stateNode, fs = !1;
                                            break e;
                                        case 3:
                                        case 4:
                                            ds = s.stateNode.containerInfo, fs = !0;
                                            break e
                                    }
                                    s = s.return
                                }
                                if (null === ds) throw Error(o(160));
                                hs(l, i, a), ds = null, fs = !1;
                                var u = a.alternate;
                                null !== u && (u.return = null), a.return = null
                            } catch (c) {
                                Cu(a, t, c)
                            }
                        }
                    if (12854 & t.subtreeFlags)
                        for (t = t.child; null !== t;) ys(t, e), t = t.sibling
                }

                function ys(e, t) {
                    var n = e.alternate,
                        r = e.flags;
                    switch (e.tag) {
                        case 0:
                        case 11:
                        case 14:
                        case 15:
                            if (gs(t, e), vs(e), 4 & r) {
                                try {
                                    rs(3, e, e.return), as(3, e)
                                } catch (g) {
                                    Cu(e, e.return, g)
                                }
                                try {
                                    rs(5, e, e.return)
                                } catch (g) {
                                    Cu(e, e.return, g)
                                }
                            }
                            break;
                        case 1:
                            gs(t, e), vs(e), 512 & r && null !== n && es(n, n.return);
                            break;
                        case 5:
                            if (gs(t, e), vs(e), 512 & r && null !== n && es(n, n.return), 32 & e.flags) {
                                var a = e.stateNode;
                                try {
                                    fe(a, "")
                                } catch (g) {
                                    Cu(e, e.return, g)
                                }
                            }
                            if (4 & r && null != (a = e.stateNode)) {
                                var l = e.memoizedProps,
                                    i = null !== n ? n.memoizedProps : l,
                                    s = e.type,
                                    u = e.updateQueue;
                                if (e.updateQueue = null, null !== u) try {
                                    "input" === s && "radio" === l.type && null != l.name && X(a, l), be(s, i);
                                    var c = be(s, l);
                                    for (i = 0; i < u.length; i += 2) {
                                        var d = u[i],
                                            f = u[i + 1];
                                        "style" === d ? ge(a, f) : "dangerouslySetInnerHTML" === d ? de(a, f) : "children" === d ? fe(a, f) : b(a, d, f, c)
                                    }
                                    switch (s) {
                                        case "input":
                                            Y(a, l);
                                            break;
                                        case "textarea":
                                            oe(a, l);
                                            break;
                                        case "select":
                                            var p = a._wrapperState.wasMultiple;
                                            a._wrapperState.wasMultiple = !!l.multiple;
                                            var h = l.value;
                                            null != h ? ne(a, !!l.multiple, h, !1) : p !== !!l.multiple && (null != l.defaultValue ? ne(a, !!l.multiple, l.defaultValue, !0) : ne(a, !!l.multiple, l.multiple ? [] : "", !1))
                                    }
                                    a[pa] = l
                                } catch (g) {
                                    Cu(e, e.return, g)
                                }
                            }
                            break;
                        case 6:
                            if (gs(t, e), vs(e), 4 & r) {
                                if (null === e.stateNode) throw Error(o(162));
                                a = e.stateNode, l = e.memoizedProps;
                                try {
                                    a.nodeValue = l
                                } catch (g) {
                                    Cu(e, e.return, g)
                                }
                            }
                            break;
                        case 3:
                            if (gs(t, e), vs(e), 4 & r && null !== n && n.memoizedState.isDehydrated) try {
                                Ht(t.containerInfo)
                            } catch (g) {
                                Cu(e, e.return, g)
                            }
                            break;
                        case 4:
                        default:
                            gs(t, e), vs(e);
                            break;
                        case 13:
                            gs(t, e), vs(e), 8192 & (a = e.child).flags && (l = null !== a.memoizedState, a.stateNode.isHidden = l, !l || null !== a.alternate && null !== a.alternate.memoizedState || (Hs = Xe())), 4 & r && ms(e);
                            break;
                        case 22:
                            if (d = null !== n && null !== n.memoizedState, 1 & e.mode ? (Xi = (c = Xi) || d, gs(t, e), Xi = c) : gs(t, e), vs(e), 8192 & r) {
                                if (c = null !== e.memoizedState, (e.stateNode.isHidden = c) && !d && 0 !== (1 & e.mode))
                                    for (Zi = e, d = e.child; null !== d;) {
                                        for (f = Zi = d; null !== Zi;) {
                                            switch (h = (p = Zi).child, p.tag) {
                                                case 0:
                                                case 11:
                                                case 14:
                                                case 15:
                                                    rs(4, p, p.return);
                                                    break;
                                                case 1:
                                                    es(p, p.return);
                                                    var m = p.stateNode;
                                                    if ("function" === typeof m.componentWillUnmount) {
                                                        r = p, n = p.return;
                                                        try {
                                                            t = r, m.props = t.memoizedProps, m.state = t.memoizedState, m.componentWillUnmount()
                                                        } catch (g) {
                                                            Cu(r, n, g)
                                                        }
                                                    }
                                                    break;
                                                case 5:
                                                    es(p, p.return);
                                                    break;
                                                case 22:
                                                    if (null !== p.memoizedState) {
                                                        Ss(f);
                                                        continue
                                                    }
                                            }
                                            null !== h ? (h.return = p, Zi = h) : Ss(f)
                                        }
                                        d = d.sibling
                                    }
                                e: for (d = null, f = e;;) {
                                    if (5 === f.tag) {
                                        if (null === d) {
                                            d = f;
                                            try {
                                                a = f.stateNode, c ? "function" === typeof(l = a.style).setProperty ? l.setProperty("display", "none", "important") : l.display = "none" : (s = f.stateNode, i = void 0 !== (u = f.memoizedProps.style) && null !== u && u.hasOwnProperty("display") ? u.display : null, s.style.display = me("display", i))
                                            } catch (g) {
                                                Cu(e, e.return, g)
                                            }
                                        }
                                    } else if (6 === f.tag) {
                                        if (null === d) try {
                                            f.stateNode.nodeValue = c ? "" : f.memoizedProps
                                        } catch (g) {
                                            Cu(e, e.return, g)
                                        }
                                    } else if ((22 !== f.tag && 23 !== f.tag || null === f.memoizedState || f === e) && null !== f.child) {
                                        f.child.return = f, f = f.child;
                                        continue
                                    }
                                    if (f === e) break e;
                                    for (; null === f.sibling;) {
                                        if (null === f.return || f.return === e) break e;
                                        d === f && (d = null), f = f.return
                                    }
                                    d === f && (d = null), f.sibling.return = f.return, f = f.sibling
                                }
                            }
                            break;
                        case 19:
                            gs(t, e), vs(e), 4 & r && ms(e);
                        case 21:
                    }
                }

                function vs(e) {
                    var t = e.flags;
                    if (2 & t) {
                        try {
                            e: {
                                for (var n = e.return; null !== n;) {
                                    if (is(n)) {
                                        var r = n;
                                        break e
                                    }
                                    n = n.return
                                }
                                throw Error(o(160))
                            }
                            switch (r.tag) {
                                case 5:
                                    var a = r.stateNode;
                                    32 & r.flags && (fe(a, ""), r.flags &= -33), cs(e, ss(e), a);
                                    break;
                                case 3:
                                case 4:
                                    var l = r.stateNode.containerInfo;
                                    us(e, ss(e), l);
                                    break;
                                default:
                                    throw Error(o(161))
                            }
                        }
                        catch (i) {
                            Cu(e, e.return, i)
                        }
                        e.flags &= -3
                    }
                    4096 & t && (e.flags &= -4097)
                }

                function bs(e, t, n) {
                    Zi = e, ws(e, t, n)
                }

                function ws(e, t, n) {
                    for (var r = 0 !== (1 & e.mode); null !== Zi;) {
                        var a = Zi,
                            o = a.child;
                        if (22 === a.tag && r) {
                            var l = null !== a.memoizedState || Ji;
                            if (!l) {
                                var i = a.alternate,
                                    s = null !== i && null !== i.memoizedState || Xi;
                                i = Ji;
                                var u = Xi;
                                if (Ji = l, (Xi = s) && !u)
                                    for (Zi = a; null !== Zi;) s = (l = Zi).child, 22 === l.tag && null !== l.memoizedState ? ks(a) : null !== s ? (s.return = l, Zi = s) : ks(a);
                                for (; null !== o;) Zi = o, ws(o, t, n), o = o.sibling;
                                Zi = a, Ji = i, Xi = u
                            }
                            xs(e)
                        } else 0 !== (8772 & a.subtreeFlags) && null !== o ? (o.return = a, Zi = o) : xs(e)
                    }
                }

                function xs(e) {
                    for (; null !== Zi;) {
                        var t = Zi;
                        if (0 !== (8772 & t.flags)) {
                            var n = t.alternate;
                            try {
                                if (0 !== (8772 & t.flags)) switch (t.tag) {
                                    case 0:
                                    case 11:
                                    case 15:
                                        Xi || as(5, t);
                                        break;
                                    case 1:
                                        var r = t.stateNode;
                                        if (4 & t.flags && !Xi)
                                            if (null === n) r.componentDidMount();
                                            else {
                                                var a = t.elementType === t.type ? n.memoizedProps : yo(t.type, n.memoizedProps);
                                                r.componentDidUpdate(a, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                                            }
                                        var l = t.updateQueue;
                                        null !== l && Uo(t, l, r);
                                        break;
                                    case 3:
                                        var i = t.updateQueue;
                                        if (null !== i) {
                                            if (n = null, null !== t.child) switch (t.child.tag) {
                                                case 5:
                                                case 1:
                                                    n = t.child.stateNode
                                            }
                                            Uo(t, i, n)
                                        }
                                        break;
                                    case 5:
                                        var s = t.stateNode;
                                        if (null === n && 4 & t.flags) {
                                            n = s;
                                            var u = t.memoizedProps;
                                            switch (t.type) {
                                                case "button":
                                                case "input":
                                                case "select":
                                                case "textarea":
                                                    u.autoFocus && n.focus();
                                                    break;
                                                case "img":
                                                    u.src && (n.src = u.src)
                                            }
                                        }
                                        break;
                                    case 6:
                                    case 4:
                                    case 12:
                                    case 19:
                                    case 17:
                                    case 21:
                                    case 22:
                                    case 23:
                                    case 25:
                                        break;
                                    case 13:
                                        if (null === t.memoizedState) {
                                            var c = t.alternate;
                                            if (null !== c) {
                                                var d = c.memoizedState;
                                                if (null !== d) {
                                                    var f = d.dehydrated;
                                                    null !== f && Ht(f)
                                                }
                                            }
                                        }
                                        break;
                                    default:
                                        throw Error(o(163))
                                }
                                Xi || 512 & t.flags && os(t)
                            } catch (p) {
                                Cu(t, t.return, p)
                            }
                        }
                        if (t === e) {
                            Zi = null;
                            break
                        }
                        if (null !== (n = t.sibling)) {
                            n.return = t.return, Zi = n;
                            break
                        }
                        Zi = t.return
                    }
                }

                function Ss(e) {
                    for (; null !== Zi;) {
                        var t = Zi;
                        if (t === e) {
                            Zi = null;
                            break
                        }
                        var n = t.sibling;
                        if (null !== n) {
                            n.return = t.return, Zi = n;
                            break
                        }
                        Zi = t.return
                    }
                }

                function ks(e) {
                    for (; null !== Zi;) {
                        var t = Zi;
                        try {
                            switch (t.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    var n = t.return;
                                    try {
                                        as(4, t)
                                    } catch (s) {
                                        Cu(t, n, s)
                                    }
                                    break;
                                case 1:
                                    var r = t.stateNode;
                                    if ("function" === typeof r.componentDidMount) {
                                        var a = t.return;
                                        try {
                                            r.componentDidMount()
                                        } catch (s) {
                                            Cu(t, a, s)
                                        }
                                    }
                                    var o = t.return;
                                    try {
                                        os(t)
                                    } catch (s) {
                                        Cu(t, o, s)
                                    }
                                    break;
                                case 5:
                                    var l = t.return;
                                    try {
                                        os(t)
                                    } catch (s) {
                                        Cu(t, l, s)
                                    }
                            }
                        } catch (s) {
                            Cu(t, t.return, s)
                        }
                        if (t === e) {
                            Zi = null;
                            break
                        }
                        var i = t.sibling;
                        if (null !== i) {
                            i.return = t.return, Zi = i;
                            break
                        }
                        Zi = t.return
                    }
                }
                var Es, Cs = Math.ceil,
                    Ns = w.ReactCurrentDispatcher,
                    js = w.ReactCurrentOwner,
                    _s = w.ReactCurrentBatchConfig,
                    Ts = 0,
                    Ps = null,
                    Os = null,
                    Rs = 0,
                    Ls = 0,
                    zs = Ea(0),
                    Ds = 0,
                    As = null,
                    Is = 0,
                    Fs = 0,
                    Us = 0,
                    Ms = null,
                    Bs = null,
                    Hs = 0,
                    Ws = 1 / 0,
                    Vs = null,
                    $s = !1,
                    qs = null,
                    Qs = null,
                    Ks = !1,
                    Gs = null,
                    Js = 0,
                    Xs = 0,
                    Ys = null,
                    Zs = -1,
                    eu = 0;

                function tu() {
                    return 0 !== (6 & Ts) ? Xe() : -1 !== Zs ? Zs : Zs = Xe()
                }

                function nu(e) {
                    return 0 === (1 & e.mode) ? 1 : 0 !== (2 & Ts) && 0 !== Rs ? Rs & -Rs : null !== go.transition ? (0 === eu && (eu = mt()), eu) : 0 !== (e = bt) ? e : e = void 0 === (e = window.event) ? 16 : Jt(e.type)
                }

                function ru(e, t, n, r) {
                    if (50 < Xs) throw Xs = 0, Ys = null, Error(o(185));
                    yt(e, n, r), 0 !== (2 & Ts) && e === Ps || (e === Ps && (0 === (2 & Ts) && (Fs |= n), 4 === Ds && su(e, Rs)), au(e, r), 1 === n && 0 === Ts && 0 === (1 & t.mode) && (Ws = Xe() + 500, Ua && Ha()))
                }

                function au(e, t) {
                    var n = e.callbackNode;
                    ! function(e, t) {
                        for (var n = e.suspendedLanes, r = e.pingedLanes, a = e.expirationTimes, o = e.pendingLanes; 0 < o;) {
                            var l = 31 - lt(o),
                                i = 1 << l,
                                s = a[l]; - 1 === s ? 0 !== (i & n) && 0 === (i & r) || (a[l] = pt(i, t)) : s <= t && (e.expiredLanes |= i), o &= ~i
                        }
                    }(e, t);
                    var r = ft(e, e === Ps ? Rs : 0);
                    if (0 === r) null !== n && Ke(n), e.callbackNode = null, e.callbackPriority = 0;
                    else if (t = r & -r, e.callbackPriority !== t) {
                        if (null != n && Ke(n), 1 === t) 0 === e.tag ? function(e) {
                            Ua = !0, Ba(e)
                        }(uu.bind(null, e)) : Ba(uu.bind(null, e)), la((function() {
                            0 === (6 & Ts) && Ha()
                        })), n = null;
                        else {
                            switch (wt(r)) {
                                case 1:
                                    n = Ze;
                                    break;
                                case 4:
                                    n = et;
                                    break;
                                case 16:
                                default:
                                    n = tt;
                                    break;
                                case 536870912:
                                    n = rt
                            }
                            n = Pu(n, ou.bind(null, e))
                        }
                        e.callbackPriority = t, e.callbackNode = n
                    }
                }

                function ou(e, t) {
                    if (Zs = -1, eu = 0, 0 !== (6 & Ts)) throw Error(o(327));
                    var n = e.callbackNode;
                    if (ku() && e.callbackNode !== n) return null;
                    var r = ft(e, e === Ps ? Rs : 0);
                    if (0 === r) return null;
                    if (0 !== (30 & r) || 0 !== (r & e.expiredLanes) || t) t = yu(e, r);
                    else {
                        t = r;
                        var a = Ts;
                        Ts |= 2;
                        var l = mu();
                        for (Ps === e && Rs === t || (Vs = null, Ws = Xe() + 500, pu(e, t));;) try {
                            bu();
                            break
                        } catch (s) {
                            hu(e, s)
                        }
                        So(), Ns.current = l, Ts = a, null !== Os ? t = 0 : (Ps = null, Rs = 0, t = Ds)
                    }
                    if (0 !== t) {
                        if (2 === t && (0 !== (a = ht(e)) && (r = a, t = lu(e, a))), 1 === t) throw n = As, pu(e, 0), su(e, r), au(e, Xe()), n;
                        if (6 === t) su(e, r);
                        else {
                            if (a = e.current.alternate, 0 === (30 & r) && ! function(e) {
                                    for (var t = e;;) {
                                        if (16384 & t.flags) {
                                            var n = t.updateQueue;
                                            if (null !== n && null !== (n = n.stores))
                                                for (var r = 0; r < n.length; r++) {
                                                    var a = n[r],
                                                        o = a.getSnapshot;
                                                    a = a.value;
                                                    try {
                                                        if (!ir(o(), a)) return !1
                                                    } catch (i) {
                                                        return !1
                                                    }
                                                }
                                        }
                                        if (n = t.child, 16384 & t.subtreeFlags && null !== n) n.return = t, t = n;
                                        else {
                                            if (t === e) break;
                                            for (; null === t.sibling;) {
                                                if (null === t.return || t.return === e) return !0;
                                                t = t.return
                                            }
                                            t.sibling.return = t.return, t = t.sibling
                                        }
                                    }
                                    return !0
                                }(a) && (2 === (t = yu(e, r)) && (0 !== (l = ht(e)) && (r = l, t = lu(e, l))), 1 === t)) throw n = As, pu(e, 0), su(e, r), au(e, Xe()), n;
                            switch (e.finishedWork = a, e.finishedLanes = r, t) {
                                case 0:
                                case 1:
                                    throw Error(o(345));
                                case 2:
                                case 5:
                                    Su(e, Bs, Vs);
                                    break;
                                case 3:
                                    if (su(e, r), (130023424 & r) === r && 10 < (t = Hs + 500 - Xe())) {
                                        if (0 !== ft(e, 0)) break;
                                        if (((a = e.suspendedLanes) & r) !== r) {
                                            tu(), e.pingedLanes |= e.suspendedLanes & a;
                                            break
                                        }
                                        e.timeoutHandle = ra(Su.bind(null, e, Bs, Vs), t);
                                        break
                                    }
                                    Su(e, Bs, Vs);
                                    break;
                                case 4:
                                    if (su(e, r), (4194240 & r) === r) break;
                                    for (t = e.eventTimes, a = -1; 0 < r;) {
                                        var i = 31 - lt(r);
                                        l = 1 << i, (i = t[i]) > a && (a = i), r &= ~l
                                    }
                                    if (r = a, 10 < (r = (120 > (r = Xe() - r) ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * Cs(r / 1960)) - r)) {
                                        e.timeoutHandle = ra(Su.bind(null, e, Bs, Vs), r);
                                        break
                                    }
                                    Su(e, Bs, Vs);
                                    break;
                                default:
                                    throw Error(o(329))
                            }
                        }
                    }
                    return au(e, Xe()), e.callbackNode === n ? ou.bind(null, e) : null
                }

                function lu(e, t) {
                    var n = Ms;
                    return e.current.memoizedState.isDehydrated && (pu(e, t).flags |= 256), 2 !== (e = yu(e, t)) && (t = Bs, Bs = n, null !== t && iu(t)), e
                }

                function iu(e) {
                    null === Bs ? Bs = e : Bs.push.apply(Bs, e)
                }

                function su(e, t) {
                    for (t &= ~Us, t &= ~Fs, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
                        var n = 31 - lt(t),
                            r = 1 << n;
                        e[n] = -1, t &= ~r
                    }
                }

                function uu(e) {
                    if (0 !== (6 & Ts)) throw Error(o(327));
                    ku();
                    var t = ft(e, 0);
                    if (0 === (1 & t)) return au(e, Xe()), null;
                    var n = yu(e, t);
                    if (0 !== e.tag && 2 === n) {
                        var r = ht(e);
                        0 !== r && (t = r, n = lu(e, r))
                    }
                    if (1 === n) throw n = As, pu(e, 0), su(e, t), au(e, Xe()), n;
                    if (6 === n) throw Error(o(345));
                    return e.finishedWork = e.current.alternate, e.finishedLanes = t, Su(e, Bs, Vs), au(e, Xe()), null
                }

                function cu(e, t) {
                    var n = Ts;
                    Ts |= 1;
                    try {
                        return e(t)
                    } finally {
                        0 === (Ts = n) && (Ws = Xe() + 500, Ua && Ha())
                    }
                }

                function du(e) {
                    null !== Gs && 0 === Gs.tag && 0 === (6 & Ts) && ku();
                    var t = Ts;
                    Ts |= 1;
                    var n = _s.transition,
                        r = bt;
                    try {
                        if (_s.transition = null, bt = 1, e) return e()
                    } finally {
                        bt = r, _s.transition = n, 0 === (6 & (Ts = t)) && Ha()
                    }
                }

                function fu() {
                    Ls = zs.current, Ca(zs)
                }

                function pu(e, t) {
                    e.finishedWork = null, e.finishedLanes = 0;
                    var n = e.timeoutHandle;
                    if (-1 !== n && (e.timeoutHandle = -1, aa(n)), null !== Os)
                        for (n = Os.return; null !== n;) {
                            var r = n;
                            switch (to(r), r.tag) {
                                case 1:
                                    null !== (r = r.type.childContextTypes) && void 0 !== r && La();
                                    break;
                                case 3:
                                    ol(), Ca(Ta), Ca(_a), dl();
                                    break;
                                case 5:
                                    il(r);
                                    break;
                                case 4:
                                    ol();
                                    break;
                                case 13:
                                case 19:
                                    Ca(sl);
                                    break;
                                case 10:
                                    ko(r.type._context);
                                    break;
                                case 22:
                                case 23:
                                    fu()
                            }
                            n = n.return
                        }
                    if (Ps = e, Os = e = zu(e.current, null), Rs = Ls = t, Ds = 0, As = null, Us = Fs = Is = 0, Bs = Ms = null, null !== jo) {
                        for (t = 0; t < jo.length; t++)
                            if (null !== (r = (n = jo[t]).interleaved)) {
                                n.interleaved = null;
                                var a = r.next,
                                    o = n.pending;
                                if (null !== o) {
                                    var l = o.next;
                                    o.next = a, r.next = l
                                }
                                n.pending = r
                            }
                        jo = null
                    }
                    return e
                }

                function hu(e, t) {
                    for (;;) {
                        var n = Os;
                        try {
                            if (So(), fl.current = li, vl) {
                                for (var r = ml.memoizedState; null !== r;) {
                                    var a = r.queue;
                                    null !== a && (a.pending = null), r = r.next
                                }
                                vl = !1
                            }
                            if (hl = 0, yl = gl = ml = null, bl = !1, wl = 0, js.current = null, null === n || null === n.return) {
                                Ds = 1, As = t, Os = null;
                                break
                            }
                            e: {
                                var l = e,
                                    i = n.return,
                                    s = n,
                                    u = t;
                                if (t = Rs, s.flags |= 32768, null !== u && "object" === typeof u && "function" === typeof u.then) {
                                    var c = u,
                                        d = s,
                                        f = d.tag;
                                    if (0 === (1 & d.mode) && (0 === f || 11 === f || 15 === f)) {
                                        var p = d.alternate;
                                        p ? (d.updateQueue = p.updateQueue, d.memoizedState = p.memoizedState, d.lanes = p.lanes) : (d.updateQueue = null, d.memoizedState = null)
                                    }
                                    var h = yi(i);
                                    if (null !== h) {
                                        h.flags &= -257, vi(h, i, s, 0, t), 1 & h.mode && gi(l, c, t), u = c;
                                        var m = (t = h).updateQueue;
                                        if (null === m) {
                                            var g = new Set;
                                            g.add(u), t.updateQueue = g
                                        } else m.add(u);
                                        break e
                                    }
                                    if (0 === (1 & t)) {
                                        gi(l, c, t), gu();
                                        break e
                                    }
                                    u = Error(o(426))
                                } else if (ao && 1 & s.mode) {
                                    var y = yi(i);
                                    if (null !== y) {
                                        0 === (65536 & y.flags) && (y.flags |= 256), vi(y, i, s, 0, t), mo(ci(u, s));
                                        break e
                                    }
                                }
                                l = u = ci(u, s),
                                4 !== Ds && (Ds = 2),
                                null === Ms ? Ms = [l] : Ms.push(l),
                                l = i;do {
                                    switch (l.tag) {
                                        case 3:
                                            l.flags |= 65536, t &= -t, l.lanes |= t, Io(l, hi(0, u, t));
                                            break e;
                                        case 1:
                                            s = u;
                                            var v = l.type,
                                                b = l.stateNode;
                                            if (0 === (128 & l.flags) && ("function" === typeof v.getDerivedStateFromError || null !== b && "function" === typeof b.componentDidCatch && (null === Qs || !Qs.has(b)))) {
                                                l.flags |= 65536, t &= -t, l.lanes |= t, Io(l, mi(l, s, t));
                                                break e
                                            }
                                    }
                                    l = l.return
                                } while (null !== l)
                            }
                            xu(n)
                        } catch (w) {
                            t = w, Os === n && null !== n && (Os = n = n.return);
                            continue
                        }
                        break
                    }
                }

                function mu() {
                    var e = Ns.current;
                    return Ns.current = li, null === e ? li : e
                }

                function gu() {
                    0 !== Ds && 3 !== Ds && 2 !== Ds || (Ds = 4), null === Ps || 0 === (268435455 & Is) && 0 === (268435455 & Fs) || su(Ps, Rs)
                }

                function yu(e, t) {
                    var n = Ts;
                    Ts |= 2;
                    var r = mu();
                    for (Ps === e && Rs === t || (Vs = null, pu(e, t));;) try {
                        vu();
                        break
                    } catch (a) {
                        hu(e, a)
                    }
                    if (So(), Ts = n, Ns.current = r, null !== Os) throw Error(o(261));
                    return Ps = null, Rs = 0, Ds
                }

                function vu() {
                    for (; null !== Os;) wu(Os)
                }

                function bu() {
                    for (; null !== Os && !Ge();) wu(Os)
                }

                function wu(e) {
                    var t = Es(e.alternate, e, Ls);
                    e.memoizedProps = e.pendingProps, null === t ? xu(e) : Os = t, js.current = null
                }

                function xu(e) {
                    var t = e;
                    do {
                        var n = t.alternate;
                        if (e = t.return, 0 === (32768 & t.flags)) {
                            if (null !== (n = Ki(n, t, Ls))) return void(Os = n)
                        } else {
                            if (null !== (n = Gi(n, t))) return n.flags &= 32767, void(Os = n);
                            if (null === e) return Ds = 6, void(Os = null);
                            e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null
                        }
                        if (null !== (t = t.sibling)) return void(Os = t);
                        Os = t = e
                    } while (null !== t);
                    0 === Ds && (Ds = 5)
                }

                function Su(e, t, n) {
                    var r = bt,
                        a = _s.transition;
                    try {
                        _s.transition = null, bt = 1,
                            function(e, t, n, r) {
                                do {
                                    ku()
                                } while (null !== Gs);
                                if (0 !== (6 & Ts)) throw Error(o(327));
                                n = e.finishedWork;
                                var a = e.finishedLanes;
                                if (null === n) return null;
                                if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(o(177));
                                e.callbackNode = null, e.callbackPriority = 0;
                                var l = n.lanes | n.childLanes;
                                if (function(e, t) {
                                        var n = e.pendingLanes & ~t;
                                        e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
                                        var r = e.eventTimes;
                                        for (e = e.expirationTimes; 0 < n;) {
                                            var a = 31 - lt(n),
                                                o = 1 << a;
                                            t[a] = 0, r[a] = -1, e[a] = -1, n &= ~o
                                        }
                                    }(e, l), e === Ps && (Os = Ps = null, Rs = 0), 0 === (2064 & n.subtreeFlags) && 0 === (2064 & n.flags) || Ks || (Ks = !0, Pu(tt, (function() {
                                        return ku(), null
                                    }))), l = 0 !== (15990 & n.flags), 0 !== (15990 & n.subtreeFlags) || l) {
                                    l = _s.transition, _s.transition = null;
                                    var i = bt;
                                    bt = 1;
                                    var s = Ts;
                                    Ts |= 4, js.current = null,
                                        function(e, t) {
                                            if (ea = Vt, pr(e = fr())) {
                                                if ("selectionStart" in e) var n = {
                                                    start: e.selectionStart,
                                                    end: e.selectionEnd
                                                };
                                                else e: {
                                                    var r = (n = (n = e.ownerDocument) && n.defaultView || window).getSelection && n.getSelection();
                                                    if (r && 0 !== r.rangeCount) {
                                                        n = r.anchorNode;
                                                        var a = r.anchorOffset,
                                                            l = r.focusNode;
                                                        r = r.focusOffset;
                                                        try {
                                                            n.nodeType, l.nodeType
                                                        } catch (x) {
                                                            n = null;
                                                            break e
                                                        }
                                                        var i = 0,
                                                            s = -1,
                                                            u = -1,
                                                            c = 0,
                                                            d = 0,
                                                            f = e,
                                                            p = null;
                                                        t: for (;;) {
                                                            for (var h; f !== n || 0 !== a && 3 !== f.nodeType || (s = i + a), f !== l || 0 !== r && 3 !== f.nodeType || (u = i + r), 3 === f.nodeType && (i += f.nodeValue.length), null !== (h = f.firstChild);) p = f, f = h;
                                                            for (;;) {
                                                                if (f === e) break t;
                                                                if (p === n && ++c === a && (s = i), p === l && ++d === r && (u = i), null !== (h = f.nextSibling)) break;
                                                                p = (f = p).parentNode
                                                            }
                                                            f = h
                                                        }
                                                        n = -1 === s || -1 === u ? null : {
                                                            start: s,
                                                            end: u
                                                        }
                                                    } else n = null
                                                }
                                                n = n || {
                                                    start: 0,
                                                    end: 0
                                                }
                                            } else n = null;
                                            for (ta = {
                                                    focusedElem: e,
                                                    selectionRange: n
                                                }, Vt = !1, Zi = t; null !== Zi;)
                                                if (e = (t = Zi).child, 0 !== (1028 & t.subtreeFlags) && null !== e) e.return = t, Zi = e;
                                                else
                                                    for (; null !== Zi;) {
                                                        t = Zi;
                                                        try {
                                                            var m = t.alternate;
                                                            if (0 !== (1024 & t.flags)) switch (t.tag) {
                                                                case 0:
                                                                case 11:
                                                                case 15:
                                                                case 5:
                                                                case 6:
                                                                case 4:
                                                                case 17:
                                                                    break;
                                                                case 1:
                                                                    if (null !== m) {
                                                                        var g = m.memoizedProps,
                                                                            y = m.memoizedState,
                                                                            v = t.stateNode,
                                                                            b = v.getSnapshotBeforeUpdate(t.elementType === t.type ? g : yo(t.type, g), y);
                                                                        v.__reactInternalSnapshotBeforeUpdate = b
                                                                    }
                                                                    break;
                                                                case 3:
                                                                    var w = t.stateNode.containerInfo;
                                                                    1 === w.nodeType ? w.textContent = "" : 9 === w.nodeType && w.documentElement && w.removeChild(w.documentElement);
                                                                    break;
                                                                default:
                                                                    throw Error(o(163))
                                                            }
                                                        } catch (x) {
                                                            Cu(t, t.return, x)
                                                        }
                                                        if (null !== (e = t.sibling)) {
                                                            e.return = t.return, Zi = e;
                                                            break
                                                        }
                                                        Zi = t.return
                                                    }
                                            m = ns, ns = !1
                                        }(e, n), ys(n, e), hr(ta), Vt = !!ea, ta = ea = null, e.current = n, bs(n, e, a), Je(), Ts = s, bt = i, _s.transition = l
                                } else e.current = n;
                                if (Ks && (Ks = !1, Gs = e, Js = a), l = e.pendingLanes, 0 === l && (Qs = null), function(e) {
                                        if (ot && "function" === typeof ot.onCommitFiberRoot) try {
                                            ot.onCommitFiberRoot(at, e, void 0, 128 === (128 & e.current.flags))
                                        } catch (t) {}
                                    }(n.stateNode), au(e, Xe()), null !== t)
                                    for (r = e.onRecoverableError, n = 0; n < t.length; n++) a = t[n], r(a.value, {
                                        componentStack: a.stack,
                                        digest: a.digest
                                    });
                                if ($s) throw $s = !1, e = qs, qs = null, e;
                                0 !== (1 & Js) && 0 !== e.tag && ku(), l = e.pendingLanes, 0 !== (1 & l) ? e === Ys ? Xs++ : (Xs = 0, Ys = e) : Xs = 0, Ha()
                            }(e, t, n, r)
                    } finally {
                        _s.transition = a, bt = r
                    }
                    return null
                }

                function ku() {
                    if (null !== Gs) {
                        var e = wt(Js),
                            t = _s.transition,
                            n = bt;
                        try {
                            if (_s.transition = null, bt = 16 > e ? 16 : e, null === Gs) var r = !1;
                            else {
                                if (e = Gs, Gs = null, Js = 0, 0 !== (6 & Ts)) throw Error(o(331));
                                var a = Ts;
                                for (Ts |= 4, Zi = e.current; null !== Zi;) {
                                    var l = Zi,
                                        i = l.child;
                                    if (0 !== (16 & Zi.flags)) {
                                        var s = l.deletions;
                                        if (null !== s) {
                                            for (var u = 0; u < s.length; u++) {
                                                var c = s[u];
                                                for (Zi = c; null !== Zi;) {
                                                    var d = Zi;
                                                    switch (d.tag) {
                                                        case 0:
                                                        case 11:
                                                        case 15:
                                                            rs(8, d, l)
                                                    }
                                                    var f = d.child;
                                                    if (null !== f) f.return = d, Zi = f;
                                                    else
                                                        for (; null !== Zi;) {
                                                            var p = (d = Zi).sibling,
                                                                h = d.return;
                                                            if (ls(d), d === c) {
                                                                Zi = null;
                                                                break
                                                            }
                                                            if (null !== p) {
                                                                p.return = h, Zi = p;
                                                                break
                                                            }
                                                            Zi = h
                                                        }
                                                }
                                            }
                                            var m = l.alternate;
                                            if (null !== m) {
                                                var g = m.child;
                                                if (null !== g) {
                                                    m.child = null;
                                                    do {
                                                        var y = g.sibling;
                                                        g.sibling = null, g = y
                                                    } while (null !== g)
                                                }
                                            }
                                            Zi = l
                                        }
                                    }
                                    if (0 !== (2064 & l.subtreeFlags) && null !== i) i.return = l, Zi = i;
                                    else e: for (; null !== Zi;) {
                                        if (0 !== (2048 & (l = Zi).flags)) switch (l.tag) {
                                            case 0:
                                            case 11:
                                            case 15:
                                                rs(9, l, l.return)
                                        }
                                        var v = l.sibling;
                                        if (null !== v) {
                                            v.return = l.return, Zi = v;
                                            break e
                                        }
                                        Zi = l.return
                                    }
                                }
                                var b = e.current;
                                for (Zi = b; null !== Zi;) {
                                    var w = (i = Zi).child;
                                    if (0 !== (2064 & i.subtreeFlags) && null !== w) w.return = i, Zi = w;
                                    else e: for (i = b; null !== Zi;) {
                                        if (0 !== (2048 & (s = Zi).flags)) try {
                                            switch (s.tag) {
                                                case 0:
                                                case 11:
                                                case 15:
                                                    as(9, s)
                                            }
                                        } catch (S) {
                                            Cu(s, s.return, S)
                                        }
                                        if (s === i) {
                                            Zi = null;
                                            break e
                                        }
                                        var x = s.sibling;
                                        if (null !== x) {
                                            x.return = s.return, Zi = x;
                                            break e
                                        }
                                        Zi = s.return
                                    }
                                }
                                if (Ts = a, Ha(), ot && "function" === typeof ot.onPostCommitFiberRoot) try {
                                    ot.onPostCommitFiberRoot(at, e)
                                } catch (S) {}
                                r = !0
                            }
                            return r
                        } finally {
                            bt = n, _s.transition = t
                        }
                    }
                    return !1
                }

                function Eu(e, t, n) {
                    e = Do(e, t = hi(0, t = ci(n, t), 1), 1), t = tu(), null !== e && (yt(e, 1, t), au(e, t))
                }

                function Cu(e, t, n) {
                    if (3 === e.tag) Eu(e, e, n);
                    else
                        for (; null !== t;) {
                            if (3 === t.tag) {
                                Eu(t, e, n);
                                break
                            }
                            if (1 === t.tag) {
                                var r = t.stateNode;
                                if ("function" === typeof t.type.getDerivedStateFromError || "function" === typeof r.componentDidCatch && (null === Qs || !Qs.has(r))) {
                                    t = Do(t, e = mi(t, e = ci(n, e), 1), 1), e = tu(), null !== t && (yt(t, 1, e), au(t, e));
                                    break
                                }
                            }
                            t = t.return
                        }
                }

                function Nu(e, t, n) {
                    var r = e.pingCache;
                    null !== r && r.delete(t), t = tu(), e.pingedLanes |= e.suspendedLanes & n, Ps === e && (Rs & n) === n && (4 === Ds || 3 === Ds && (130023424 & Rs) === Rs && 500 > Xe() - Hs ? pu(e, 0) : Us |= n), au(e, t)
                }

                function ju(e, t) {
                    0 === t && (0 === (1 & e.mode) ? t = 1 : (t = ct, 0 === (130023424 & (ct <<= 1)) && (ct = 4194304)));
                    var n = tu();
                    null !== (e = Po(e, t)) && (yt(e, t, n), au(e, n))
                }

                function _u(e) {
                    var t = e.memoizedState,
                        n = 0;
                    null !== t && (n = t.retryLane), ju(e, n)
                }

                function Tu(e, t) {
                    var n = 0;
                    switch (e.tag) {
                        case 13:
                            var r = e.stateNode,
                                a = e.memoizedState;
                            null !== a && (n = a.retryLane);
                            break;
                        case 19:
                            r = e.stateNode;
                            break;
                        default:
                            throw Error(o(314))
                    }
                    null !== r && r.delete(t), ju(e, n)
                }

                function Pu(e, t) {
                    return Qe(e, t)
                }

                function Ou(e, t, n, r) {
                    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
                }

                function Ru(e, t, n, r) {
                    return new Ou(e, t, n, r)
                }

                function Lu(e) {
                    return !(!(e = e.prototype) || !e.isReactComponent)
                }

                function zu(e, t) {
                    var n = e.alternate;
                    return null === n ? ((n = Ru(e.tag, t, e.key, e.mode)).elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = 14680064 & e.flags, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = null === t ? null : {
                        lanes: t.lanes,
                        firstContext: t.firstContext
                    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
                }

                function Du(e, t, n, r, a, l) {
                    var i = 2;
                    if (r = e, "function" === typeof e) Lu(e) && (i = 1);
                    else if ("string" === typeof e) i = 5;
                    else e: switch (e) {
                        case k:
                            return Au(n.children, a, l, t);
                        case E:
                            i = 8, a |= 8;
                            break;
                        case C:
                            return (e = Ru(12, n, t, 2 | a)).elementType = C, e.lanes = l, e;
                        case T:
                            return (e = Ru(13, n, t, a)).elementType = T, e.lanes = l, e;
                        case P:
                            return (e = Ru(19, n, t, a)).elementType = P, e.lanes = l, e;
                        case L:
                            return Iu(n, a, l, t);
                        default:
                            if ("object" === typeof e && null !== e) switch (e.$$typeof) {
                                case N:
                                    i = 10;
                                    break e;
                                case j:
                                    i = 9;
                                    break e;
                                case _:
                                    i = 11;
                                    break e;
                                case O:
                                    i = 14;
                                    break e;
                                case R:
                                    i = 16, r = null;
                                    break e
                            }
                            throw Error(o(130, null == e ? e : typeof e, ""))
                    }
                    return (t = Ru(i, n, t, a)).elementType = e, t.type = r, t.lanes = l, t
                }

                function Au(e, t, n, r) {
                    return (e = Ru(7, e, r, t)).lanes = n, e
                }

                function Iu(e, t, n, r) {
                    return (e = Ru(22, e, r, t)).elementType = L, e.lanes = n, e.stateNode = {
                        isHidden: !1
                    }, e
                }

                function Fu(e, t, n) {
                    return (e = Ru(6, e, null, t)).lanes = n, e
                }

                function Uu(e, t, n) {
                    return (t = Ru(4, null !== e.children ? e.children : [], e.key, t)).lanes = n, t.stateNode = {
                        containerInfo: e.containerInfo,
                        pendingChildren: null,
                        implementation: e.implementation
                    }, t
                }

                function Mu(e, t, n, r, a) {
                    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = gt(0), this.expirationTimes = gt(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = gt(0), this.identifierPrefix = r, this.onRecoverableError = a, this.mutableSourceEagerHydrationData = null
                }

                function Bu(e, t, n, r, a, o, l, i, s) {
                    return e = new Mu(e, t, n, i, s), 1 === t ? (t = 1, !0 === o && (t |= 8)) : t = 0, o = Ru(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = {
                        element: r,
                        isDehydrated: n,
                        cache: null,
                        transitions: null,
                        pendingSuspenseBoundaries: null
                    }, Ro(o), e
                }

                function Hu(e) {
                    if (!e) return ja;
                    e: {
                        if (He(e = e._reactInternals) !== e || 1 !== e.tag) throw Error(o(170));
                        var t = e;do {
                            switch (t.tag) {
                                case 3:
                                    t = t.stateNode.context;
                                    break e;
                                case 1:
                                    if (Ra(t.type)) {
                                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                                        break e
                                    }
                            }
                            t = t.return
                        } while (null !== t);
                        throw Error(o(171))
                    }
                    if (1 === e.tag) {
                        var n = e.type;
                        if (Ra(n)) return Da(e, n, t)
                    }
                    return t
                }

                function Wu(e, t, n, r, a, o, l, i, s) {
                    return (e = Bu(n, r, !0, e, 0, o, 0, i, s)).context = Hu(null), n = e.current, (o = zo(r = tu(), a = nu(n))).callback = void 0 !== t && null !== t ? t : null, Do(n, o, a), e.current.lanes = a, yt(e, a, r), au(e, r), e
                }

                function Vu(e, t, n, r) {
                    var a = t.current,
                        o = tu(),
                        l = nu(a);
                    return n = Hu(n), null === t.context ? t.context = n : t.pendingContext = n, (t = zo(o, l)).payload = {
                        element: e
                    }, null !== (r = void 0 === r ? null : r) && (t.callback = r), null !== (e = Do(a, t, l)) && (ru(e, a, l, o), Ao(e, a, l)), l
                }

                function $u(e) {
                    return (e = e.current).child ? (e.child.tag, e.child.stateNode) : null
                }

                function qu(e, t) {
                    if (null !== (e = e.memoizedState) && null !== e.dehydrated) {
                        var n = e.retryLane;
                        e.retryLane = 0 !== n && n < t ? n : t
                    }
                }

                function Qu(e, t) {
                    qu(e, t), (e = e.alternate) && qu(e, t)
                }
                Es = function(e, t, n) {
                    if (null !== e)
                        if (e.memoizedProps !== t.pendingProps || Ta.current) wi = !0;
                        else {
                            if (0 === (e.lanes & n) && 0 === (128 & t.flags)) return wi = !1,
                                function(e, t, n) {
                                    switch (t.tag) {
                                        case 3:
                                            Pi(t), ho();
                                            break;
                                        case 5:
                                            ll(t);
                                            break;
                                        case 1:
                                            Ra(t.type) && Aa(t);
                                            break;
                                        case 4:
                                            al(t, t.stateNode.containerInfo);
                                            break;
                                        case 10:
                                            var r = t.type._context,
                                                a = t.memoizedProps.value;
                                            Na(vo, r._currentValue), r._currentValue = a;
                                            break;
                                        case 13:
                                            if (null !== (r = t.memoizedState)) return null !== r.dehydrated ? (Na(sl, 1 & sl.current), t.flags |= 128, null) : 0 !== (n & t.child.childLanes) ? Fi(e, t, n) : (Na(sl, 1 & sl.current), null !== (e = $i(e, t, n)) ? e.sibling : null);
                                            Na(sl, 1 & sl.current);
                                            break;
                                        case 19:
                                            if (r = 0 !== (n & t.childLanes), 0 !== (128 & e.flags)) {
                                                if (r) return Wi(e, t, n);
                                                t.flags |= 128
                                            }
                                            if (null !== (a = t.memoizedState) && (a.rendering = null, a.tail = null, a.lastEffect = null), Na(sl, sl.current), r) break;
                                            return null;
                                        case 22:
                                        case 23:
                                            return t.lanes = 0, Ci(e, t, n)
                                    }
                                    return $i(e, t, n)
                                }(e, t, n);
                            wi = 0 !== (131072 & e.flags)
                        }
                    else wi = !1, ao && 0 !== (1048576 & t.flags) && Za(t, qa, t.index);
                    switch (t.lanes = 0, t.tag) {
                        case 2:
                            var r = t.type;
                            Vi(e, t), e = t.pendingProps;
                            var a = Oa(t, _a.current);
                            Co(t, n), a = El(null, t, r, e, a, n);
                            var l = Cl();
                            return t.flags |= 1, "object" === typeof a && null !== a && "function" === typeof a.render && void 0 === a.$$typeof ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Ra(r) ? (l = !0, Aa(t)) : l = !1, t.memoizedState = null !== a.state && void 0 !== a.state ? a.state : null, Ro(t), a.updater = Ho, t.stateNode = a, a._reactInternals = t, qo(t, r, e, n), t = Ti(null, t, r, !0, l, n)) : (t.tag = 0, ao && l && eo(t), xi(null, t, a, n), t = t.child), t;
                        case 16:
                            r = t.elementType;
                            e: {
                                switch (Vi(e, t), e = t.pendingProps, r = (a = r._init)(r._payload), t.type = r, a = t.tag = function(e) {
                                    if ("function" === typeof e) return Lu(e) ? 1 : 0;
                                    if (void 0 !== e && null !== e) {
                                        if ((e = e.$$typeof) === _) return 11;
                                        if (e === O) return 14
                                    }
                                    return 2
                                }(r), e = yo(r, e), a) {
                                    case 0:
                                        t = ji(null, t, r, e, n);
                                        break e;
                                    case 1:
                                        t = _i(null, t, r, e, n);
                                        break e;
                                    case 11:
                                        t = Si(null, t, r, e, n);
                                        break e;
                                    case 14:
                                        t = ki(null, t, r, yo(r.type, e), n);
                                        break e
                                }
                                throw Error(o(306, r, ""))
                            }
                            return t;
                        case 0:
                            return r = t.type, a = t.pendingProps, ji(e, t, r, a = t.elementType === r ? a : yo(r, a), n);
                        case 1:
                            return r = t.type, a = t.pendingProps, _i(e, t, r, a = t.elementType === r ? a : yo(r, a), n);
                        case 3:
                            e: {
                                if (Pi(t), null === e) throw Error(o(387));r = t.pendingProps,
                                a = (l = t.memoizedState).element,
                                Lo(e, t),
                                Fo(t, r, null, n);
                                var i = t.memoizedState;
                                if (r = i.element, l.isDehydrated) {
                                    if (l = {
                                            element: r,
                                            isDehydrated: !1,
                                            cache: i.cache,
                                            pendingSuspenseBoundaries: i.pendingSuspenseBoundaries,
                                            transitions: i.transitions
                                        }, t.updateQueue.baseState = l, t.memoizedState = l, 256 & t.flags) {
                                        t = Oi(e, t, r, n, a = ci(Error(o(423)), t));
                                        break e
                                    }
                                    if (r !== a) {
                                        t = Oi(e, t, r, n, a = ci(Error(o(424)), t));
                                        break e
                                    }
                                    for (ro = ua(t.stateNode.containerInfo.firstChild), no = t, ao = !0, oo = null, n = Yo(t, null, r, n), t.child = n; n;) n.flags = -3 & n.flags | 4096, n = n.sibling
                                } else {
                                    if (ho(), r === a) {
                                        t = $i(e, t, n);
                                        break e
                                    }
                                    xi(e, t, r, n)
                                }
                                t = t.child
                            }
                            return t;
                        case 5:
                            return ll(t), null === e && uo(t), r = t.type, a = t.pendingProps, l = null !== e ? e.memoizedProps : null, i = a.children, na(r, a) ? i = null : null !== l && na(r, l) && (t.flags |= 32), Ni(e, t), xi(e, t, i, n), t.child;
                        case 6:
                            return null === e && uo(t), null;
                        case 13:
                            return Fi(e, t, n);
                        case 4:
                            return al(t, t.stateNode.containerInfo), r = t.pendingProps, null === e ? t.child = Xo(t, null, r, n) : xi(e, t, r, n), t.child;
                        case 11:
                            return r = t.type, a = t.pendingProps, Si(e, t, r, a = t.elementType === r ? a : yo(r, a), n);
                        case 7:
                            return xi(e, t, t.pendingProps, n), t.child;
                        case 8:
                        case 12:
                            return xi(e, t, t.pendingProps.children, n), t.child;
                        case 10:
                            e: {
                                if (r = t.type._context, a = t.pendingProps, l = t.memoizedProps, i = a.value, Na(vo, r._currentValue), r._currentValue = i, null !== l)
                                    if (ir(l.value, i)) {
                                        if (l.children === a.children && !Ta.current) {
                                            t = $i(e, t, n);
                                            break e
                                        }
                                    } else
                                        for (null !== (l = t.child) && (l.return = t); null !== l;) {
                                            var s = l.dependencies;
                                            if (null !== s) {
                                                i = l.child;
                                                for (var u = s.firstContext; null !== u;) {
                                                    if (u.context === r) {
                                                        if (1 === l.tag) {
                                                            (u = zo(-1, n & -n)).tag = 2;
                                                            var c = l.updateQueue;
                                                            if (null !== c) {
                                                                var d = (c = c.shared).pending;
                                                                null === d ? u.next = u : (u.next = d.next, d.next = u), c.pending = u
                                                            }
                                                        }
                                                        l.lanes |= n, null !== (u = l.alternate) && (u.lanes |= n), Eo(l.return, n, t), s.lanes |= n;
                                                        break
                                                    }
                                                    u = u.next
                                                }
                                            } else if (10 === l.tag) i = l.type === t.type ? null : l.child;
                                            else if (18 === l.tag) {
                                                if (null === (i = l.return)) throw Error(o(341));
                                                i.lanes |= n, null !== (s = i.alternate) && (s.lanes |= n), Eo(i, n, t), i = l.sibling
                                            } else i = l.child;
                                            if (null !== i) i.return = l;
                                            else
                                                for (i = l; null !== i;) {
                                                    if (i === t) {
                                                        i = null;
                                                        break
                                                    }
                                                    if (null !== (l = i.sibling)) {
                                                        l.return = i.return, i = l;
                                                        break
                                                    }
                                                    i = i.return
                                                }
                                            l = i
                                        }
                                xi(e, t, a.children, n),
                                t = t.child
                            }
                            return t;
                        case 9:
                            return a = t.type, r = t.pendingProps.children, Co(t, n), r = r(a = No(a)), t.flags |= 1, xi(e, t, r, n), t.child;
                        case 14:
                            return a = yo(r = t.type, t.pendingProps), ki(e, t, r, a = yo(r.type, a), n);
                        case 15:
                            return Ei(e, t, t.type, t.pendingProps, n);
                        case 17:
                            return r = t.type, a = t.pendingProps, a = t.elementType === r ? a : yo(r, a), Vi(e, t), t.tag = 1, Ra(r) ? (e = !0, Aa(t)) : e = !1, Co(t, n), Vo(t, r, a), qo(t, r, a, n), Ti(null, t, r, !0, e, n);
                        case 19:
                            return Wi(e, t, n);
                        case 22:
                            return Ci(e, t, n)
                    }
                    throw Error(o(156, t.tag))
                };
                var Ku = "function" === typeof reportError ? reportError : function(e) {
                    console.error(e)
                };

                function Gu(e) {
                    this._internalRoot = e
                }

                function Ju(e) {
                    this._internalRoot = e
                }

                function Xu(e) {
                    return !(!e || 1 !== e.nodeType && 9 !== e.nodeType && 11 !== e.nodeType)
                }

                function Yu(e) {
                    return !(!e || 1 !== e.nodeType && 9 !== e.nodeType && 11 !== e.nodeType && (8 !== e.nodeType || " react-mount-point-unstable " !== e.nodeValue))
                }

                function Zu() {}

                function ec(e, t, n, r, a) {
                    var o = n._reactRootContainer;
                    if (o) {
                        var l = o;
                        if ("function" === typeof a) {
                            var i = a;
                            a = function() {
                                var e = $u(l);
                                i.call(e)
                            }
                        }
                        Vu(t, l, e, a)
                    } else l = function(e, t, n, r, a) {
                        if (a) {
                            if ("function" === typeof r) {
                                var o = r;
                                r = function() {
                                    var e = $u(l);
                                    o.call(e)
                                }
                            }
                            var l = Wu(t, r, e, 0, null, !1, 0, "", Zu);
                            return e._reactRootContainer = l, e[ha] = l.current, Hr(8 === e.nodeType ? e.parentNode : e), du(), l
                        }
                        for (; a = e.lastChild;) e.removeChild(a);
                        if ("function" === typeof r) {
                            var i = r;
                            r = function() {
                                var e = $u(s);
                                i.call(e)
                            }
                        }
                        var s = Bu(e, 0, !1, null, 0, !1, 0, "", Zu);
                        return e._reactRootContainer = s, e[ha] = s.current, Hr(8 === e.nodeType ? e.parentNode : e), du((function() {
                            Vu(t, s, n, r)
                        })), s
                    }(n, t, e, a, r);
                    return $u(l)
                }
                Ju.prototype.render = Gu.prototype.render = function(e) {
                    var t = this._internalRoot;
                    if (null === t) throw Error(o(409));
                    Vu(e, t, null, null)
                }, Ju.prototype.unmount = Gu.prototype.unmount = function() {
                    var e = this._internalRoot;
                    if (null !== e) {
                        this._internalRoot = null;
                        var t = e.containerInfo;
                        du((function() {
                            Vu(null, e, null, null)
                        })), t[ha] = null
                    }
                }, Ju.prototype.unstable_scheduleHydration = function(e) {
                    if (e) {
                        var t = Et();
                        e = {
                            blockedOn: null,
                            target: e,
                            priority: t
                        };
                        for (var n = 0; n < Lt.length && 0 !== t && t < Lt[n].priority; n++);
                        Lt.splice(n, 0, e), 0 === n && It(e)
                    }
                }, xt = function(e) {
                    switch (e.tag) {
                        case 3:
                            var t = e.stateNode;
                            if (t.current.memoizedState.isDehydrated) {
                                var n = dt(t.pendingLanes);
                                0 !== n && (vt(t, 1 | n), au(t, Xe()), 0 === (6 & Ts) && (Ws = Xe() + 500, Ha()))
                            }
                            break;
                        case 13:
                            du((function() {
                                var t = Po(e, 1);
                                if (null !== t) {
                                    var n = tu();
                                    ru(t, e, 1, n)
                                }
                            })), Qu(e, 1)
                    }
                }, St = function(e) {
                    if (13 === e.tag) {
                        var t = Po(e, 134217728);
                        if (null !== t) ru(t, e, 134217728, tu());
                        Qu(e, 134217728)
                    }
                }, kt = function(e) {
                    if (13 === e.tag) {
                        var t = nu(e),
                            n = Po(e, t);
                        if (null !== n) ru(n, e, t, tu());
                        Qu(e, t)
                    }
                }, Et = function() {
                    return bt
                }, Ct = function(e, t) {
                    var n = bt;
                    try {
                        return bt = e, t()
                    } finally {
                        bt = n
                    }
                }, Se = function(e, t, n) {
                    switch (t) {
                        case "input":
                            if (Y(e, n), t = n.name, "radio" === n.type && null != t) {
                                for (n = e; n.parentNode;) n = n.parentNode;
                                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                                    var r = n[t];
                                    if (r !== e && r.form === e.form) {
                                        var a = xa(r);
                                        if (!a) throw Error(o(90));
                                        Q(r), Y(r, a)
                                    }
                                }
                            }
                            break;
                        case "textarea":
                            oe(e, n);
                            break;
                        case "select":
                            null != (t = n.value) && ne(e, !!n.multiple, t, !1)
                    }
                }, _e = cu, Te = du;
                var tc = {
                        usingClientEntryPoint: !1,
                        Events: [ba, wa, xa, Ne, je, cu]
                    },
                    nc = {
                        findFiberByHostInstance: va,
                        bundleType: 0,
                        version: "18.2.0",
                        rendererPackageName: "react-dom"
                    },
                    rc = {
                        bundleType: nc.bundleType,
                        version: nc.version,
                        rendererPackageName: nc.rendererPackageName,
                        rendererConfig: nc.rendererConfig,
                        overrideHookState: null,
                        overrideHookStateDeletePath: null,
                        overrideHookStateRenamePath: null,
                        overrideProps: null,
                        overridePropsDeletePath: null,
                        overridePropsRenamePath: null,
                        setErrorHandler: null,
                        setSuspenseHandler: null,
                        scheduleUpdate: null,
                        currentDispatcherRef: w.ReactCurrentDispatcher,
                        findHostInstanceByFiber: function(e) {
                            return null === (e = $e(e)) ? null : e.stateNode
                        },
                        findFiberByHostInstance: nc.findFiberByHostInstance || function() {
                            return null
                        },
                        findHostInstancesForRefresh: null,
                        scheduleRefresh: null,
                        scheduleRoot: null,
                        setRefreshHandler: null,
                        getCurrentFiber: null,
                        reconcilerVersion: "18.2.0-next-9e3b772b8-20220608"
                    };
                if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
                    var ac = __REACT_DEVTOOLS_GLOBAL_HOOK__;
                    if (!ac.isDisabled && ac.supportsFiber) try {
                        at = ac.inject(rc), ot = ac
                    } catch (ce) {}
                }
                t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = tc, t.createPortal = function(e, t) {
                    var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
                    if (!Xu(t)) throw Error(o(200));
                    return function(e, t, n) {
                        var r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
                        return {
                            $$typeof: S,
                            key: null == r ? null : "" + r,
                            children: e,
                            containerInfo: t,
                            implementation: n
                        }
                    }(e, t, null, n)
                }, t.createRoot = function(e, t) {
                    if (!Xu(e)) throw Error(o(299));
                    var n = !1,
                        r = "",
                        a = Ku;
                    return null !== t && void 0 !== t && (!0 === t.unstable_strictMode && (n = !0), void 0 !== t.identifierPrefix && (r = t.identifierPrefix), void 0 !== t.onRecoverableError && (a = t.onRecoverableError)), t = Bu(e, 1, !1, null, 0, n, 0, r, a), e[ha] = t.current, Hr(8 === e.nodeType ? e.parentNode : e), new Gu(t)
                }, t.findDOMNode = function(e) {
                    if (null == e) return null;
                    if (1 === e.nodeType) return e;
                    var t = e._reactInternals;
                    if (void 0 === t) {
                        if ("function" === typeof e.render) throw Error(o(188));
                        throw e = Object.keys(e).join(","), Error(o(268, e))
                    }
                    return e = null === (e = $e(t)) ? null : e.stateNode
                }, t.flushSync = function(e) {
                    return du(e)
                }, t.hydrate = function(e, t, n) {
                    if (!Yu(t)) throw Error(o(200));
                    return ec(null, e, t, !0, n)
                }, t.hydrateRoot = function(e, t, n) {
                    if (!Xu(e)) throw Error(o(405));
                    var r = null != n && n.hydratedSources || null,
                        a = !1,
                        l = "",
                        i = Ku;
                    if (null !== n && void 0 !== n && (!0 === n.unstable_strictMode && (a = !0), void 0 !== n.identifierPrefix && (l = n.identifierPrefix), void 0 !== n.onRecoverableError && (i = n.onRecoverableError)), t = Wu(t, null, e, 1, null != n ? n : null, a, 0, l, i), e[ha] = t.current, Hr(e), r)
                        for (e = 0; e < r.length; e++) a = (a = (n = r[e])._getVersion)(n._source), null == t.mutableSourceEagerHydrationData ? t.mutableSourceEagerHydrationData = [n, a] : t.mutableSourceEagerHydrationData.push(n, a);
                    return new Ju(t)
                }, t.render = function(e, t, n) {
                    if (!Yu(t)) throw Error(o(200));
                    return ec(null, e, t, !1, n)
                }, t.unmountComponentAtNode = function(e) {
                    if (!Yu(e)) throw Error(o(40));
                    return !!e._reactRootContainer && (du((function() {
                        ec(null, null, e, !1, (function() {
                            e._reactRootContainer = null, e[ha] = null
                        }))
                    })), !0)
                }, t.unstable_batchedUpdates = cu, t.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
                    if (!Yu(n)) throw Error(o(200));
                    if (null == e || void 0 === e._reactInternals) throw Error(o(38));
                    return ec(e, t, n, !1, r)
                }, t.version = "18.2.0-next-9e3b772b8-20220608"
            },
            391: (e, t, n) => {
                var r = n(950);
                t.createRoot = r.createRoot, t.hydrateRoot = r.hydrateRoot
            },
            950: (e, t, n) => {
                ! function e() {
                    if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE) try {
                        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)
                    } catch (t) {
                        console.error(t)
                    }
                }(), e.exports = n(730)
            },
            153: (e, t, n) => {
                var r = n(43),
                    a = Symbol.for("react.element"),
                    o = Symbol.for("react.fragment"),
                    l = Object.prototype.hasOwnProperty,
                    i = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                    s = {
                        key: !0,
                        ref: !0,
                        __self: !0,
                        __source: !0
                    };

                function u(e, t, n) {
                    var r, o = {},
                        u = null,
                        c = null;
                    for (r in void 0 !== n && (u = "" + n), void 0 !== t.key && (u = "" + t.key), void 0 !== t.ref && (c = t.ref), t) l.call(t, r) && !s.hasOwnProperty(r) && (o[r] = t[r]);
                    if (e && e.defaultProps)
                        for (r in t = e.defaultProps) void 0 === o[r] && (o[r] = t[r]);
                    return {
                        $$typeof: a,
                        type: e,
                        key: u,
                        ref: c,
                        props: o,
                        _owner: i.current
                    }
                }
                t.Fragment = o, t.jsx = u, t.jsxs = u
            },
            202: (e, t) => {
                var n = Symbol.for("react.element"),
                    r = Symbol.for("react.portal"),
                    a = Symbol.for("react.fragment"),
                    o = Symbol.for("react.strict_mode"),
                    l = Symbol.for("react.profiler"),
                    i = Symbol.for("react.provider"),
                    s = Symbol.for("react.context"),
                    u = Symbol.for("react.forward_ref"),
                    c = Symbol.for("react.suspense"),
                    d = Symbol.for("react.memo"),
                    f = Symbol.for("react.lazy"),
                    p = Symbol.iterator;
                var h = {
                        isMounted: function() {
                            return !1
                        },
                        enqueueForceUpdate: function() {},
                        enqueueReplaceState: function() {},
                        enqueueSetState: function() {}
                    },
                    m = Object.assign,
                    g = {};

                function y(e, t, n) {
                    this.props = e, this.context = t, this.refs = g, this.updater = n || h
                }

                function v() {}

                function b(e, t, n) {
                    this.props = e, this.context = t, this.refs = g, this.updater = n || h
                }
                y.prototype.isReactComponent = {}, y.prototype.setState = function(e, t) {
                    if ("object" !== typeof e && "function" !== typeof e && null != e) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
                    this.updater.enqueueSetState(this, e, t, "setState")
                }, y.prototype.forceUpdate = function(e) {
                    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
                }, v.prototype = y.prototype;
                var w = b.prototype = new v;
                w.constructor = b, m(w, y.prototype), w.isPureReactComponent = !0;
                var x = Array.isArray,
                    S = Object.prototype.hasOwnProperty,
                    k = {
                        current: null
                    },
                    E = {
                        key: !0,
                        ref: !0,
                        __self: !0,
                        __source: !0
                    };

                function C(e, t, r) {
                    var a, o = {},
                        l = null,
                        i = null;
                    if (null != t)
                        for (a in void 0 !== t.ref && (i = t.ref), void 0 !== t.key && (l = "" + t.key), t) S.call(t, a) && !E.hasOwnProperty(a) && (o[a] = t[a]);
                    var s = arguments.length - 2;
                    if (1 === s) o.children = r;
                    else if (1 < s) {
                        for (var u = Array(s), c = 0; c < s; c++) u[c] = arguments[c + 2];
                        o.children = u
                    }
                    if (e && e.defaultProps)
                        for (a in s = e.defaultProps) void 0 === o[a] && (o[a] = s[a]);
                    return {
                        $$typeof: n,
                        type: e,
                        key: l,
                        ref: i,
                        props: o,
                        _owner: k.current
                    }
                }

                function N(e) {
                    return "object" === typeof e && null !== e && e.$$typeof === n
                }
                var j = /\/+/g;

                function _(e, t) {
                    return "object" === typeof e && null !== e && null != e.key ? function(e) {
                        var t = {
                            "=": "=0",
                            ":": "=2"
                        };
                        return "$" + e.replace(/[=:]/g, (function(e) {
                            return t[e]
                        }))
                    }("" + e.key) : t.toString(36)
                }

                function T(e, t, a, o, l) {
                    var i = typeof e;
                    "undefined" !== i && "boolean" !== i || (e = null);
                    var s = !1;
                    if (null === e) s = !0;
                    else switch (i) {
                        case "string":
                        case "number":
                            s = !0;
                            break;
                        case "object":
                            switch (e.$$typeof) {
                                case n:
                                case r:
                                    s = !0
                            }
                    }
                    if (s) return l = l(s = e), e = "" === o ? "." + _(s, 0) : o, x(l) ? (a = "", null != e && (a = e.replace(j, "$&/") + "/"), T(l, t, a, "", (function(e) {
                        return e
                    }))) : null != l && (N(l) && (l = function(e, t) {
                        return {
                            $$typeof: n,
                            type: e.type,
                            key: t,
                            ref: e.ref,
                            props: e.props,
                            _owner: e._owner
                        }
                    }(l, a + (!l.key || s && s.key === l.key ? "" : ("" + l.key).replace(j, "$&/") + "/") + e)), t.push(l)), 1;
                    if (s = 0, o = "" === o ? "." : o + ":", x(e))
                        for (var u = 0; u < e.length; u++) {
                            var c = o + _(i = e[u], u);
                            s += T(i, t, a, c, l)
                        } else if (c = function(e) {
                                return null === e || "object" !== typeof e ? null : "function" === typeof(e = p && e[p] || e["@@iterator"]) ? e : null
                            }(e), "function" === typeof c)
                            for (e = c.call(e), u = 0; !(i = e.next()).done;) s += T(i = i.value, t, a, c = o + _(i, u++), l);
                        else if ("object" === i) throw t = String(e), Error("Objects are not valid as a React child (found: " + ("[object Object]" === t ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
                    return s
                }

                function P(e, t, n) {
                    if (null == e) return e;
                    var r = [],
                        a = 0;
                    return T(e, r, "", "", (function(e) {
                        return t.call(n, e, a++)
                    })), r
                }

                function O(e) {
                    if (-1 === e._status) {
                        var t = e._result;
                        (t = t()).then((function(t) {
                            0 !== e._status && -1 !== e._status || (e._status = 1, e._result = t)
                        }), (function(t) {
                            0 !== e._status && -1 !== e._status || (e._status = 2, e._result = t)
                        })), -1 === e._status && (e._status = 0, e._result = t)
                    }
                    if (1 === e._status) return e._result.default;
                    throw e._result
                }
                var R = {
                        current: null
                    },
                    L = {
                        transition: null
                    },
                    z = {
                        ReactCurrentDispatcher: R,
                        ReactCurrentBatchConfig: L,
                        ReactCurrentOwner: k
                    };
                t.Children = {
                    map: P,
                    forEach: function(e, t, n) {
                        P(e, (function() {
                            t.apply(this, arguments)
                        }), n)
                    },
                    count: function(e) {
                        var t = 0;
                        return P(e, (function() {
                            t++
                        })), t
                    },
                    toArray: function(e) {
                        return P(e, (function(e) {
                            return e
                        })) || []
                    },
                    only: function(e) {
                        if (!N(e)) throw Error("React.Children.only expected to receive a single React element child.");
                        return e
                    }
                }, t.Component = y, t.Fragment = a, t.Profiler = l, t.PureComponent = b, t.StrictMode = o, t.Suspense = c, t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = z, t.cloneElement = function(e, t, r) {
                    if (null === e || void 0 === e) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
                    var a = m({}, e.props),
                        o = e.key,
                        l = e.ref,
                        i = e._owner;
                    if (null != t) {
                        if (void 0 !== t.ref && (l = t.ref, i = k.current), void 0 !== t.key && (o = "" + t.key), e.type && e.type.defaultProps) var s = e.type.defaultProps;
                        for (u in t) S.call(t, u) && !E.hasOwnProperty(u) && (a[u] = void 0 === t[u] && void 0 !== s ? s[u] : t[u])
                    }
                    var u = arguments.length - 2;
                    if (1 === u) a.children = r;
                    else if (1 < u) {
                        s = Array(u);
                        for (var c = 0; c < u; c++) s[c] = arguments[c + 2];
                        a.children = s
                    }
                    return {
                        $$typeof: n,
                        type: e.type,
                        key: o,
                        ref: l,
                        props: a,
                        _owner: i
                    }
                }, t.createContext = function(e) {
                    return (e = {
                        $$typeof: s,
                        _currentValue: e,
                        _currentValue2: e,
                        _threadCount: 0,
                        Provider: null,
                        Consumer: null,
                        _defaultValue: null,
                        _globalName: null
                    }).Provider = {
                        $$typeof: i,
                        _context: e
                    }, e.Consumer = e
                }, t.createElement = C, t.createFactory = function(e) {
                    var t = C.bind(null, e);
                    return t.type = e, t
                }, t.createRef = function() {
                    return {
                        current: null
                    }
                }, t.forwardRef = function(e) {
                    return {
                        $$typeof: u,
                        render: e
                    }
                }, t.isValidElement = N, t.lazy = function(e) {
                    return {
                        $$typeof: f,
                        _payload: {
                            _status: -1,
                            _result: e
                        },
                        _init: O
                    }
                }, t.memo = function(e, t) {
                    return {
                        $$typeof: d,
                        type: e,
                        compare: void 0 === t ? null : t
                    }
                }, t.startTransition = function(e) {
                    var t = L.transition;
                    L.transition = {};
                    try {
                        e()
                    } finally {
                        L.transition = t
                    }
                }, t.unstable_act = function() {
                    throw Error("act(...) is not supported in production builds of React.")
                }, t.useCallback = function(e, t) {
                    return R.current.useCallback(e, t)
                }, t.useContext = function(e) {
                    return R.current.useContext(e)
                }, t.useDebugValue = function() {}, t.useDeferredValue = function(e) {
                    return R.current.useDeferredValue(e)
                }, t.useEffect = function(e, t) {
                    return R.current.useEffect(e, t)
                }, t.useId = function() {
                    return R.current.useId()
                }, t.useImperativeHandle = function(e, t, n) {
                    return R.current.useImperativeHandle(e, t, n)
                }, t.useInsertionEffect = function(e, t) {
                    return R.current.useInsertionEffect(e, t)
                }, t.useLayoutEffect = function(e, t) {
                    return R.current.useLayoutEffect(e, t)
                }, t.useMemo = function(e, t) {
                    return R.current.useMemo(e, t)
                }, t.useReducer = function(e, t, n) {
                    return R.current.useReducer(e, t, n)
                }, t.useRef = function(e) {
                    return R.current.useRef(e)
                }, t.useState = function(e) {
                    return R.current.useState(e)
                }, t.useSyncExternalStore = function(e, t, n) {
                    return R.current.useSyncExternalStore(e, t, n)
                }, t.useTransition = function() {
                    return R.current.useTransition()
                }, t.version = "18.2.0"
            },
            43: (e, t, n) => {
                e.exports = n(202)
            },
            579: (e, t, n) => {
                e.exports = n(153)
            },
            234: (e, t) => {
                function n(e, t) {
                    var n = e.length;
                    e.push(t);
                    e: for (; 0 < n;) {
                        var r = n - 1 >>> 1,
                            a = e[r];
                        if (!(0 < o(a, t))) break e;
                        e[r] = t, e[n] = a, n = r
                    }
                }

                function r(e) {
                    return 0 === e.length ? null : e[0]
                }

                function a(e) {
                    if (0 === e.length) return null;
                    var t = e[0],
                        n = e.pop();
                    if (n !== t) {
                        e[0] = n;
                        e: for (var r = 0, a = e.length, l = a >>> 1; r < l;) {
                            var i = 2 * (r + 1) - 1,
                                s = e[i],
                                u = i + 1,
                                c = e[u];
                            if (0 > o(s, n)) u < a && 0 > o(c, s) ? (e[r] = c, e[u] = n, r = u) : (e[r] = s, e[i] = n, r = i);
                            else {
                                if (!(u < a && 0 > o(c, n))) break e;
                                e[r] = c, e[u] = n, r = u
                            }
                        }
                    }
                    return t
                }

                function o(e, t) {
                    var n = e.sortIndex - t.sortIndex;
                    return 0 !== n ? n : e.id - t.id
                }
                if ("object" === typeof performance && "function" === typeof performance.now) {
                    var l = performance;
                    t.unstable_now = function() {
                        return l.now()
                    }
                } else {
                    var i = Date,
                        s = i.now();
                    t.unstable_now = function() {
                        return i.now() - s
                    }
                }
                var u = [],
                    c = [],
                    d = 1,
                    f = null,
                    p = 3,
                    h = !1,
                    m = !1,
                    g = !1,
                    y = "function" === typeof setTimeout ? setTimeout : null,
                    v = "function" === typeof clearTimeout ? clearTimeout : null,
                    b = "undefined" !== typeof setImmediate ? setImmediate : null;

                function w(e) {
                    for (var t = r(c); null !== t;) {
                        if (null === t.callback) a(c);
                        else {
                            if (!(t.startTime <= e)) break;
                            a(c), t.sortIndex = t.expirationTime, n(u, t)
                        }
                        t = r(c)
                    }
                }

                function x(e) {
                    if (g = !1, w(e), !m)
                        if (null !== r(u)) m = !0, L(S);
                        else {
                            var t = r(c);
                            null !== t && z(x, t.startTime - e)
                        }
                }

                function S(e, n) {
                    m = !1, g && (g = !1, v(N), N = -1), h = !0;
                    var o = p;
                    try {
                        for (w(n), f = r(u); null !== f && (!(f.expirationTime > n) || e && !T());) {
                            var l = f.callback;
                            if ("function" === typeof l) {
                                f.callback = null, p = f.priorityLevel;
                                var i = l(f.expirationTime <= n);
                                n = t.unstable_now(), "function" === typeof i ? f.callback = i : f === r(u) && a(u), w(n)
                            } else a(u);
                            f = r(u)
                        }
                        if (null !== f) var s = !0;
                        else {
                            var d = r(c);
                            null !== d && z(x, d.startTime - n), s = !1
                        }
                        return s
                    } finally {
                        f = null, p = o, h = !1
                    }
                }
                "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
                var k, E = !1,
                    C = null,
                    N = -1,
                    j = 5,
                    _ = -1;

                function T() {
                    return !(t.unstable_now() - _ < j)
                }

                function P() {
                    if (null !== C) {
                        var e = t.unstable_now();
                        _ = e;
                        var n = !0;
                        try {
                            n = C(!0, e)
                        } finally {
                            n ? k() : (E = !1, C = null)
                        }
                    } else E = !1
                }
                if ("function" === typeof b) k = function() {
                    b(P)
                };
                else if ("undefined" !== typeof MessageChannel) {
                    var O = new MessageChannel,
                        R = O.port2;
                    O.port1.onmessage = P, k = function() {
                        R.postMessage(null)
                    }
                } else k = function() {
                    y(P, 0)
                };

                function L(e) {
                    C = e, E || (E = !0, k())
                }

                function z(e, n) {
                    N = y((function() {
                        e(t.unstable_now())
                    }), n)
                }
                t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function(e) {
                    e.callback = null
                }, t.unstable_continueExecution = function() {
                    m || h || (m = !0, L(S))
                }, t.unstable_forceFrameRate = function(e) {
                    0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : j = 0 < e ? Math.floor(1e3 / e) : 5
                }, t.unstable_getCurrentPriorityLevel = function() {
                    return p
                }, t.unstable_getFirstCallbackNode = function() {
                    return r(u)
                }, t.unstable_next = function(e) {
                    switch (p) {
                        case 1:
                        case 2:
                        case 3:
                            var t = 3;
                            break;
                        default:
                            t = p
                    }
                    var n = p;
                    p = t;
                    try {
                        return e()
                    } finally {
                        p = n
                    }
                }, t.unstable_pauseExecution = function() {}, t.unstable_requestPaint = function() {}, t.unstable_runWithPriority = function(e, t) {
                    switch (e) {
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                            break;
                        default:
                            e = 3
                    }
                    var n = p;
                    p = e;
                    try {
                        return t()
                    } finally {
                        p = n
                    }
                }, t.unstable_scheduleCallback = function(e, a, o) {
                    var l = t.unstable_now();
                    switch ("object" === typeof o && null !== o ? o = "number" === typeof(o = o.delay) && 0 < o ? l + o : l : o = l, e) {
                        case 1:
                            var i = -1;
                            break;
                        case 2:
                            i = 250;
                            break;
                        case 5:
                            i = 1073741823;
                            break;
                        case 4:
                            i = 1e4;
                            break;
                        default:
                            i = 5e3
                    }
                    return e = {
                        id: d++,
                        callback: a,
                        priorityLevel: e,
                        startTime: o,
                        expirationTime: i = o + i,
                        sortIndex: -1
                    }, o > l ? (e.sortIndex = o, n(c, e), null === r(u) && e === r(c) && (g ? (v(N), N = -1) : g = !0, z(x, o - l))) : (e.sortIndex = i, n(u, e), m || h || (m = !0, L(S))), e
                }, t.unstable_shouldYield = T, t.unstable_wrapCallback = function(e) {
                    var t = p;
                    return function() {
                        var n = p;
                        p = t;
                        try {
                            return e.apply(this, arguments)
                        } finally {
                            p = n
                        }
                    }
                }
            },
            853: (e, t, n) => {
                e.exports = n(234)
            }
        },
        t = {};

    function n(r) {
        var a = t[r];
        if (void 0 !== a) return a.exports;
        var o = t[r] = {
            exports: {}
        };
        return e[r](o, o.exports, n), o.exports
    }(() => {
        var e, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__;
        n.t = function(r, a) {
            if (1 & a && (r = this(r)), 8 & a) return r;
            if ("object" === typeof r && r) {
                if (4 & a && r.__esModule) return r;
                if (16 & a && "function" === typeof r.then) return r
            }
            var o = Object.create(null);
            n.r(o);
            var l = {};
            e = e || [null, t({}), t([]), t(t)];
            for (var i = 2 & a && r;
                "object" == typeof i && !~e.indexOf(i); i = t(i)) Object.getOwnPropertyNames(i).forEach((e => l[e] = () => r[e]));
            return l.default = () => r, n.d(o, l), o
        }
    })(), n.d = (e, t) => {
        for (var r in t) n.o(t, r) && !n.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, n.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), n.r = e => {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, (() => {
        var e = {};
        n.r(e), n.d(e, {
            hasBrowserEnv: () => rr,
            hasStandardBrowserEnv: () => ar,
            hasStandardBrowserWebWorkerEnv: () => lr,
            origin: () => ir
        });
        var t, r = n(43),
            a = n.t(r, 2),
            o = n(391),
            l = n(950),
            i = n.t(l, 2);

        function s() {
            return s = Object.assign ? Object.assign.bind() : function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            }, s.apply(this, arguments)
        }! function(e) {
            e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
        }(t || (t = {}));
        const u = "popstate";

        function c(e, t) {
            if (!1 === e || null === e || "undefined" === typeof e) throw new Error(t)
        }

        function d(e, t) {
            if (!e) {
                "undefined" !== typeof console && console.warn(t);
                try {
                    throw new Error(t)
                } catch (n) {}
            }
        }

        function f(e, t) {
            return {
                usr: e.state,
                key: e.key,
                idx: t
            }
        }

        function p(e, t, n, r) {
            return void 0 === n && (n = null), s({
                pathname: "string" === typeof e ? e : e.pathname,
                search: "",
                hash: ""
            }, "string" === typeof t ? m(t) : t, {
                state: n,
                key: t && t.key || r || Math.random().toString(36).substr(2, 8)
            })
        }

        function h(e) {
            let {
                pathname: t = "/",
                search: n = "",
                hash: r = ""
            } = e;
            return n && "?" !== n && (t += "?" === n.charAt(0) ? n : "?" + n), r && "#" !== r && (t += "#" === r.charAt(0) ? r : "#" + r), t
        }

        function m(e) {
            let t = {};
            if (e) {
                let n = e.indexOf("#");
                n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
                let r = e.indexOf("?");
                r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
            }
            return t
        }

        function g(e, n, r, a) {
            void 0 === a && (a = {});
            let {
                window: o = document.defaultView,
                v5Compat: l = !1
            } = a, i = o.history, d = t.Pop, m = null, g = y();

            function y() {
                return (i.state || {
                    idx: null
                }).idx
            }

            function v() {
                d = t.Pop;
                let e = y(),
                    n = null == e ? null : e - g;
                g = e, m && m({
                    action: d,
                    location: w.location,
                    delta: n
                })
            }

            function b(e) {
                let t = "null" !== o.location.origin ? o.location.origin : o.location.href,
                    n = "string" === typeof e ? e : h(e);
                return n = n.replace(/ $/, "%20"), c(t, "No window.location.(origin|href) available to create URL for href: " + n), new URL(n, t)
            }
            null == g && (g = 0, i.replaceState(s({}, i.state, {
                idx: g
            }), ""));
            let w = {
                get action() {
                    return d
                },
                get location() {
                    return e(o, i)
                },
                listen(e) {
                    if (m) throw new Error("A history only accepts one active listener");
                    return o.addEventListener(u, v), m = e, () => {
                        o.removeEventListener(u, v), m = null
                    }
                },
                createHref: e => n(o, e),
                createURL: b,
                encodeLocation(e) {
                    let t = b(e);
                    return {
                        pathname: t.pathname,
                        search: t.search,
                        hash: t.hash
                    }
                },
                push: function(e, n) {
                    d = t.Push;
                    let a = p(w.location, e, n);
                    r && r(a, e), g = y() + 1;
                    let s = f(a, g),
                        u = w.createHref(a);
                    try {
                        i.pushState(s, "", u)
                    } catch (c) {
                        if (c instanceof DOMException && "DataCloneError" === c.name) throw c;
                        o.location.assign(u)
                    }
                    l && m && m({
                        action: d,
                        location: w.location,
                        delta: 1
                    })
                },
                replace: function(e, n) {
                    d = t.Replace;
                    let a = p(w.location, e, n);
                    r && r(a, e), g = y();
                    let o = f(a, g),
                        s = w.createHref(a);
                    i.replaceState(o, "", s), l && m && m({
                        action: d,
                        location: w.location,
                        delta: 0
                    })
                },
                go: e => i.go(e)
            };
            return w
        }
        var y;
        ! function(e) {
            e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
        }(y || (y = {}));
        new Set(["lazy", "caseSensitive", "path", "id", "index", "children"]);

        function v(e, t, n) {
            void 0 === n && (n = "/");
            let r = R(("string" === typeof t ? m(t) : t).pathname || "/", n);
            if (null == r) return null;
            let a = b(e);
            ! function(e) {
                e.sort(((e, t) => e.score !== t.score ? t.score - e.score : function(e, t) {
                    let n = e.length === t.length && e.slice(0, -1).every(((e, n) => e === t[n]));
                    return n ? e[e.length - 1] - t[t.length - 1] : 0
                }(e.routesMeta.map((e => e.childrenIndex)), t.routesMeta.map((e => e.childrenIndex)))))
            }(a);
            let o = null;
            for (let l = 0; null == o && l < a.length; ++l) {
                let e = O(r);
                o = T(a[l], e)
            }
            return o
        }

        function b(e, t, n, r) {
            void 0 === t && (t = []), void 0 === n && (n = []), void 0 === r && (r = "");
            let a = (e, a, o) => {
                let l = {
                    relativePath: void 0 === o ? e.path || "" : o,
                    caseSensitive: !0 === e.caseSensitive,
                    childrenIndex: a,
                    route: e
                };
                l.relativePath.startsWith("/") && (c(l.relativePath.startsWith(r), 'Absolute route path "' + l.relativePath + '" nested under path "' + r + '" is not valid. An absolute child route path must start with the combined path of all its parent routes.'), l.relativePath = l.relativePath.slice(r.length));
                let i = I([r, l.relativePath]),
                    s = n.concat(l);
                e.children && e.children.length > 0 && (c(!0 !== e.index, 'Index routes must not have child routes. Please remove all child routes from route path "' + i + '".'), b(e.children, t, s, i)), (null != e.path || e.index) && t.push({
                    path: i,
                    score: _(i, e.index),
                    routesMeta: s
                })
            };
            return e.forEach(((e, t) => {
                var n;
                if ("" !== e.path && null != (n = e.path) && n.includes("?"))
                    for (let r of w(e.path)) a(e, t, r);
                else a(e, t)
            })), t
        }

        function w(e) {
            let t = e.split("/");
            if (0 === t.length) return [];
            let [n, ...r] = t, a = n.endsWith("?"), o = n.replace(/\?$/, "");
            if (0 === r.length) return a ? [o, ""] : [o];
            let l = w(r.join("/")),
                i = [];
            return i.push(...l.map((e => "" === e ? o : [o, e].join("/")))), a && i.push(...l), i.map((t => e.startsWith("/") && "" === t ? "/" : t))
        }
        const x = /^:[\w-]+$/,
            S = 3,
            k = 2,
            E = 1,
            C = 10,
            N = -2,
            j = e => "*" === e;

        function _(e, t) {
            let n = e.split("/"),
                r = n.length;
            return n.some(j) && (r += N), t && (r += k), n.filter((e => !j(e))).reduce(((e, t) => e + (x.test(t) ? S : "" === t ? E : C)), r)
        }

        function T(e, t) {
            let {
                routesMeta: n
            } = e, r = {}, a = "/", o = [];
            for (let l = 0; l < n.length; ++l) {
                let e = n[l],
                    i = l === n.length - 1,
                    s = "/" === a ? t : t.slice(a.length) || "/",
                    u = P({
                        path: e.relativePath,
                        caseSensitive: e.caseSensitive,
                        end: i
                    }, s);
                if (!u) return null;
                Object.assign(r, u.params);
                let c = e.route;
                o.push({
                    params: r,
                    pathname: I([a, u.pathname]),
                    pathnameBase: F(I([a, u.pathnameBase])),
                    route: c
                }), "/" !== u.pathnameBase && (a = I([a, u.pathnameBase]))
            }
            return o
        }

        function P(e, t) {
            "string" === typeof e && (e = {
                path: e,
                caseSensitive: !1,
                end: !0
            });
            let [n, r] = function(e, t, n) {
                void 0 === t && (t = !1);
                void 0 === n && (n = !0);
                d("*" === e || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were "' + e.replace(/\*$/, "/*") + '" because the `*` character must always follow a `/` in the pattern. To get rid of this warning, please change the route path to "' + e.replace(/\*$/, "/*") + '".');
                let r = [],
                    a = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, ((e, t, n) => (r.push({
                        paramName: t,
                        isOptional: null != n
                    }), n ? "/?([^\\/]+)?" : "/([^\\/]+)")));
                e.endsWith("*") ? (r.push({
                    paramName: "*"
                }), a += "*" === e || "/*" === e ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? a += "\\/*$" : "" !== e && "/" !== e && (a += "(?:(?=\\/|$))");
                let o = new RegExp(a, t ? void 0 : "i");
                return [o, r]
            }(e.path, e.caseSensitive, e.end), a = t.match(n);
            if (!a) return null;
            let o = a[0],
                l = o.replace(/(.)\/+$/, "$1"),
                i = a.slice(1);
            return {
                params: r.reduce(((e, t, n) => {
                    let {
                        paramName: r,
                        isOptional: a
                    } = t;
                    if ("*" === r) {
                        let e = i[n] || "";
                        l = o.slice(0, o.length - e.length).replace(/(.)\/+$/, "$1")
                    }
                    const s = i[n];
                    return e[r] = a && !s ? void 0 : (s || "").replace(/%2F/g, "/"), e
                }), {}),
                pathname: o,
                pathnameBase: l,
                pattern: e
            }
        }

        function O(e) {
            try {
                return e.split("/").map((e => decodeURIComponent(e).replace(/\//g, "%2F"))).join("/")
            } catch (t) {
                return d(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent encoding (' + t + ")."), e
            }
        }

        function R(e, t) {
            if ("/" === t) return e;
            if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
            let n = t.endsWith("/") ? t.length - 1 : t.length,
                r = e.charAt(n);
            return r && "/" !== r ? null : e.slice(n) || "/"
        }

        function L(e, t, n, r) {
            return "Cannot include a '" + e + "' character in a manually specified `to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the `to." + n + '` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.'
        }

        function z(e) {
            return e.filter(((e, t) => 0 === t || e.route.path && e.route.path.length > 0))
        }

        function D(e, t) {
            let n = z(e);
            return t ? n.map(((t, n) => n === e.length - 1 ? t.pathname : t.pathnameBase)) : n.map((e => e.pathnameBase))
        }

        function A(e, t, n, r) {
            let a;
            void 0 === r && (r = !1), "string" === typeof e ? a = m(e) : (a = s({}, e), c(!a.pathname || !a.pathname.includes("?"), L("?", "pathname", "search", a)), c(!a.pathname || !a.pathname.includes("#"), L("#", "pathname", "hash", a)), c(!a.search || !a.search.includes("#"), L("#", "search", "hash", a)));
            let o, l = "" === e || "" === a.pathname,
                i = l ? "/" : a.pathname;
            if (null == i) o = n;
            else {
                let e = t.length - 1;
                if (!r && i.startsWith("..")) {
                    let t = i.split("/");
                    for (;
                        ".." === t[0];) t.shift(), e -= 1;
                    a.pathname = t.join("/")
                }
                o = e >= 0 ? t[e] : "/"
            }
            let u = function(e, t) {
                    void 0 === t && (t = "/");
                    let {
                        pathname: n,
                        search: r = "",
                        hash: a = ""
                    } = "string" === typeof e ? m(e) : e, o = n ? n.startsWith("/") ? n : function(e, t) {
                        let n = t.replace(/\/+$/, "").split("/");
                        return e.split("/").forEach((e => {
                            ".." === e ? n.length > 1 && n.pop() : "." !== e && n.push(e)
                        })), n.length > 1 ? n.join("/") : "/"
                    }(n, t) : t;
                    return {
                        pathname: o,
                        search: U(r),
                        hash: M(a)
                    }
                }(a, o),
                d = i && "/" !== i && i.endsWith("/"),
                f = (l || "." === i) && n.endsWith("/");
            return u.pathname.endsWith("/") || !d && !f || (u.pathname += "/"), u
        }
        const I = e => e.join("/").replace(/\/\/+/g, "/"),
            F = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
            U = e => e && "?" !== e ? e.startsWith("?") ? e : "?" + e : "",
            M = e => e && "#" !== e ? e.startsWith("#") ? e : "#" + e : "";
        Error;

        function B(e) {
            return null != e && "number" === typeof e.status && "string" === typeof e.statusText && "boolean" === typeof e.internal && "data" in e
        }
        const H = ["post", "put", "patch", "delete"],
            W = (new Set(H), ["get", ...H]);
        new Set(W), new Set([301, 302, 303, 307, 308]), new Set([307, 308]);
        Symbol("deferred");

        function V() {
            return V = Object.assign ? Object.assign.bind() : function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            }, V.apply(this, arguments)
        }
        const $ = r.createContext(null);
        const q = r.createContext(null);
        const Q = r.createContext(null);
        const K = r.createContext(null);
        const G = r.createContext({
            outlet: null,
            matches: [],
            isDataRoute: !1
        });
        const J = r.createContext(null);

        function X() {
            return null != r.useContext(K)
        }

        function Y() {
            return X() || c(!1), r.useContext(K).location
        }

        function Z(e) {
            r.useContext(Q).static || r.useLayoutEffect(e)
        }

        function ee() {
            let {
                isDataRoute: e
            } = r.useContext(G);
            return e ? function() {
                let {
                    router: e
                } = de(ue.UseNavigateStable), t = pe(ce.UseNavigateStable), n = r.useRef(!1);
                return Z((() => {
                    n.current = !0
                })), r.useCallback((function(r, a) {
                    void 0 === a && (a = {}), n.current && ("number" === typeof r ? e.navigate(r) : e.navigate(r, V({
                        fromRouteId: t
                    }, a)))
                }), [e, t])
            }() : function() {
                X() || c(!1);
                let e = r.useContext($),
                    {
                        basename: t,
                        future: n,
                        navigator: a
                    } = r.useContext(Q),
                    {
                        matches: o
                    } = r.useContext(G),
                    {
                        pathname: l
                    } = Y(),
                    i = JSON.stringify(D(o, n.v7_relativeSplatPath)),
                    s = r.useRef(!1);
                return Z((() => {
                    s.current = !0
                })), r.useCallback((function(n, r) {
                    if (void 0 === r && (r = {}), !s.current) return;
                    if ("number" === typeof n) return void a.go(n);
                    let o = A(n, JSON.parse(i), l, "path" === r.relative);
                    null == e && "/" !== t && (o.pathname = "/" === o.pathname ? t : I([t, o.pathname])), (r.replace ? a.replace : a.push)(o, r.state, r)
                }), [t, a, i, l, e])
            }()
        }
        const te = r.createContext(null);

        function ne(e, t) {
            let {
                relative: n
            } = void 0 === t ? {} : t, {
                future: a
            } = r.useContext(Q), {
                matches: o
            } = r.useContext(G), {
                pathname: l
            } = Y(), i = JSON.stringify(D(o, a.v7_relativeSplatPath));
            return r.useMemo((() => A(e, JSON.parse(i), l, "path" === n)), [e, i, l, n])
        }

        function re(e, n, a, o) {
            X() || c(!1);
            let {
                navigator: l
            } = r.useContext(Q), {
                matches: i
            } = r.useContext(G), s = i[i.length - 1], u = s ? s.params : {}, d = (s && s.pathname, s ? s.pathnameBase : "/");
            s && s.route;
            let f, p = Y();
            if (n) {
                var h;
                let e = "string" === typeof n ? m(n) : n;
                "/" === d || (null == (h = e.pathname) ? void 0 : h.startsWith(d)) || c(!1), f = e
            } else f = p;
            let g = f.pathname || "/",
                y = g;
            if ("/" !== d) {
                let e = d.replace(/^\//, "").split("/");
                y = "/" + g.replace(/^\//, "").split("/").slice(e.length).join("/")
            }
            let b = v(e, {
                pathname: y
            });
            let w = se(b && b.map((e => Object.assign({}, e, {
                params: Object.assign({}, u, e.params),
                pathname: I([d, l.encodeLocation ? l.encodeLocation(e.pathname).pathname : e.pathname]),
                pathnameBase: "/" === e.pathnameBase ? d : I([d, l.encodeLocation ? l.encodeLocation(e.pathnameBase).pathname : e.pathnameBase])
            }))), i, a, o);
            return n && w ? r.createElement(K.Provider, {
                value: {
                    location: V({
                        pathname: "/",
                        search: "",
                        hash: "",
                        state: null,
                        key: "default"
                    }, f),
                    navigationType: t.Pop
                }
            }, w) : w
        }

        function ae() {
            let e = function() {
                    var e;
                    let t = r.useContext(J),
                        n = fe(ce.UseRouteError),
                        a = pe(ce.UseRouteError);
                    if (void 0 !== t) return t;
                    return null == (e = n.errors) ? void 0 : e[a]
                }(),
                t = B(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
                n = e instanceof Error ? e.stack : null,
                a = "rgba(200,200,200, 0.5)",
                o = {
                    padding: "0.5rem",
                    backgroundColor: a
                };
            return r.createElement(r.Fragment, null, r.createElement("h2", null, "Unexpected Application Error!"), r.createElement("h3", {
                style: {
                    fontStyle: "italic"
                }
            }, t), n ? r.createElement("pre", {
                style: o
            }, n) : null, null)
        }
        const oe = r.createElement(ae, null);
        class le extends r.Component {
            constructor(e) {
                super(e), this.state = {
                    location: e.location,
                    revalidation: e.revalidation,
                    error: e.error
                }
            }
            static getDerivedStateFromError(e) {
                return {
                    error: e
                }
            }
            static getDerivedStateFromProps(e, t) {
                return t.location !== e.location || "idle" !== t.revalidation && "idle" === e.revalidation ? {
                    error: e.error,
                    location: e.location,
                    revalidation: e.revalidation
                } : {
                    error: void 0 !== e.error ? e.error : t.error,
                    location: t.location,
                    revalidation: e.revalidation || t.revalidation
                }
            }
            componentDidCatch(e, t) {
                console.error("React Router caught the following error during render", e, t)
            }
            render() {
                return void 0 !== this.state.error ? r.createElement(G.Provider, {
                    value: this.props.routeContext
                }, r.createElement(J.Provider, {
                    value: this.state.error,
                    children: this.props.component
                })) : this.props.children
            }
        }

        function ie(e) {
            let {
                routeContext: t,
                match: n,
                children: a
            } = e, o = r.useContext($);
            return o && o.static && o.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (o.staticContext._deepestRenderedBoundaryId = n.route.id), r.createElement(G.Provider, {
                value: t
            }, a)
        }

        function se(e, t, n, a) {
            var o;
            if (void 0 === t && (t = []), void 0 === n && (n = null), void 0 === a && (a = null), null == e) {
                var l;
                if (null == (l = n) || !l.errors) return null;
                e = n.matches
            }
            let i = e,
                s = null == (o = n) ? void 0 : o.errors;
            if (null != s) {
                let e = i.findIndex((e => e.route.id && (null == s ? void 0 : s[e.route.id])));
                e >= 0 || c(!1), i = i.slice(0, Math.min(i.length, e + 1))
            }
            let u = !1,
                d = -1;
            if (n && a && a.v7_partialHydration)
                for (let r = 0; r < i.length; r++) {
                    let e = i[r];
                    if ((e.route.HydrateFallback || e.route.hydrateFallbackElement) && (d = r), e.route.id) {
                        let {
                            loaderData: t,
                            errors: r
                        } = n, a = e.route.loader && void 0 === t[e.route.id] && (!r || void 0 === r[e.route.id]);
                        if (e.route.lazy || a) {
                            u = !0, i = d >= 0 ? i.slice(0, d + 1) : [i[0]];
                            break
                        }
                    }
                }
            return i.reduceRight(((e, a, o) => {
                let l, c = !1,
                    f = null,
                    p = null;
                var h;
                n && (l = s && a.route.id ? s[a.route.id] : void 0, f = a.route.errorElement || oe, u && (d < 0 && 0 === o ? (h = "route-fallback", !1 || he[h] || (he[h] = !0), c = !0, p = null) : d === o && (c = !0, p = a.route.hydrateFallbackElement || null)));
                let m = t.concat(i.slice(0, o + 1)),
                    g = () => {
                        let t;
                        return t = l ? f : c ? p : a.route.Component ? r.createElement(a.route.Component, null) : a.route.element ? a.route.element : e, r.createElement(ie, {
                            match: a,
                            routeContext: {
                                outlet: e,
                                matches: m,
                                isDataRoute: null != n
                            },
                            children: t
                        })
                    };
                return n && (a.route.ErrorBoundary || a.route.errorElement || 0 === o) ? r.createElement(le, {
                    location: n.location,
                    revalidation: n.revalidation,
                    component: f,
                    error: l,
                    children: g(),
                    routeContext: {
                        outlet: null,
                        matches: m,
                        isDataRoute: !0
                    }
                }) : g()
            }), null)
        }
        var ue = function(e) {
                return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
            }(ue || {}),
            ce = function(e) {
                return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
            }(ce || {});

        function de(e) {
            let t = r.useContext($);
            return t || c(!1), t
        }

        function fe(e) {
            let t = r.useContext(q);
            return t || c(!1), t
        }

        function pe(e) {
            let t = function(e) {
                    let t = r.useContext(G);
                    return t || c(!1), t
                }(),
                n = t.matches[t.matches.length - 1];
            return n.route.id || c(!1), n.route.id
        }
        const he = {};
        a.startTransition;

        function me(e) {
            let {
                to: t,
                replace: n,
                state: a,
                relative: o
            } = e;
            X() || c(!1);
            let {
                future: l,
                static: i
            } = r.useContext(Q), {
                matches: s
            } = r.useContext(G), {
                pathname: u
            } = Y(), d = ee(), f = A(t, D(s, l.v7_relativeSplatPath), u, "path" === o), p = JSON.stringify(f);
            return r.useEffect((() => d(JSON.parse(p), {
                replace: n,
                state: a,
                relative: o
            })), [d, p, o, n, a]), null
        }

        function ge(e) {
            return function(e) {
                let t = r.useContext(G).outlet;
                return t ? r.createElement(te.Provider, {
                    value: e
                }, t) : t
            }(e.context)
        }

        function ye(e) {
            c(!1)
        }

        function ve(e) {
            let {
                basename: n = "/",
                children: a = null,
                location: o,
                navigationType: l = t.Pop,
                navigator: i,
                static: s = !1,
                future: u
            } = e;
            X() && c(!1);
            let d = n.replace(/^\/*/, "/"),
                f = r.useMemo((() => ({
                    basename: d,
                    navigator: i,
                    static: s,
                    future: V({
                        v7_relativeSplatPath: !1
                    }, u)
                })), [d, u, i, s]);
            "string" === typeof o && (o = m(o));
            let {
                pathname: p = "/",
                search: h = "",
                hash: g = "",
                state: y = null,
                key: v = "default"
            } = o, b = r.useMemo((() => {
                let e = R(p, d);
                return null == e ? null : {
                    location: {
                        pathname: e,
                        search: h,
                        hash: g,
                        state: y,
                        key: v
                    },
                    navigationType: l
                }
            }), [d, p, h, g, y, v, l]);
            return null == b ? null : r.createElement(Q.Provider, {
                value: f
            }, r.createElement(K.Provider, {
                children: a,
                value: b
            }))
        }

        function be(e) {
            let {
                children: t,
                location: n
            } = e;
            return re(we(t), n)
        }
        new Promise((() => {}));
        r.Component;

        function we(e, t) {
            void 0 === t && (t = []);
            let n = [];
            return r.Children.forEach(e, ((e, a) => {
                if (!r.isValidElement(e)) return;
                let o = [...t, a];
                if (e.type === r.Fragment) return void n.push.apply(n, we(e.props.children, o));
                e.type !== ye && c(!1), e.props.index && e.props.children && c(!1);
                let l = {
                    id: e.props.id || o.join("-"),
                    caseSensitive: e.props.caseSensitive,
                    element: e.props.element,
                    Component: e.props.Component,
                    index: e.props.index,
                    path: e.props.path,
                    loader: e.props.loader,
                    action: e.props.action,
                    errorElement: e.props.errorElement,
                    ErrorBoundary: e.props.ErrorBoundary,
                    hasErrorBoundary: null != e.props.ErrorBoundary || null != e.props.errorElement,
                    shouldRevalidate: e.props.shouldRevalidate,
                    handle: e.props.handle,
                    lazy: e.props.lazy
                };
                e.props.children && (l.children = we(e.props.children, o)), n.push(l)
            })), n
        }

        function xe() {
            return xe = Object.assign ? Object.assign.bind() : function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            }, xe.apply(this, arguments)
        }

        function Se(e, t) {
            if (null == e) return {};
            var n, r, a = {},
                o = Object.keys(e);
            for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || (a[n] = e[n]);
            return a
        }
        new Set(["application/x-www-form-urlencoded", "multipart/form-data", "text/plain"]);
        const ke = ["onClick", "relative", "reloadDocument", "replace", "state", "target", "to", "preventScrollReset", "unstable_viewTransition"],
            Ee = ["aria-current", "caseSensitive", "className", "end", "style", "to", "unstable_viewTransition", "children"];
        try {
            window.__reactRouterVersion = "6"
        } catch (ga) {}
        const Ce = r.createContext({
            isTransitioning: !1
        });
        new Map;
        const Ne = a.startTransition;
        i.flushSync, a.useId;

        function je(e) {
            let {
                basename: t,
                children: n,
                future: a,
                window: o
            } = e, l = r.useRef();
            var i;
            null == l.current && (l.current = (void 0 === (i = {
                window: o,
                v5Compat: !0
            }) && (i = {}), g((function(e, t) {
                let {
                    pathname: n,
                    search: r,
                    hash: a
                } = e.location;
                return p("", {
                    pathname: n,
                    search: r,
                    hash: a
                }, t.state && t.state.usr || null, t.state && t.state.key || "default")
            }), (function(e, t) {
                return "string" === typeof t ? t : h(t)
            }), null, i)));
            let s = l.current,
                [u, c] = r.useState({
                    action: s.action,
                    location: s.location
                }),
                {
                    v7_startTransition: d
                } = a || {},
                f = r.useCallback((e => {
                    d && Ne ? Ne((() => c(e))) : c(e)
                }), [c, d]);
            return r.useLayoutEffect((() => s.listen(f)), [s, f]), r.createElement(ve, {
                basename: t,
                children: n,
                location: u.location,
                navigationType: u.action,
                navigator: s,
                future: a
            })
        }
        const _e = "undefined" !== typeof window && "undefined" !== typeof window.document && "undefined" !== typeof window.document.createElement,
            Te = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
            Pe = r.forwardRef((function(e, t) {
                let n, {
                        onClick: a,
                        relative: o,
                        reloadDocument: l,
                        replace: i,
                        state: s,
                        target: u,
                        to: d,
                        preventScrollReset: f,
                        unstable_viewTransition: p
                    } = e,
                    m = Se(e, ke),
                    {
                        basename: g
                    } = r.useContext(Q),
                    y = !1;
                if ("string" === typeof d && Te.test(d) && (n = d, _e)) try {
                    let e = new URL(window.location.href),
                        t = d.startsWith("//") ? new URL(e.protocol + d) : new URL(d),
                        n = R(t.pathname, g);
                    t.origin === e.origin && null != n ? d = n + t.search + t.hash : y = !0
                } catch (ga) {}
                let v = function(e, t) {
                        let {
                            relative: n
                        } = void 0 === t ? {} : t;
                        X() || c(!1);
                        let {
                            basename: a,
                            navigator: o
                        } = r.useContext(Q), {
                            hash: l,
                            pathname: i,
                            search: s
                        } = ne(e, {
                            relative: n
                        }), u = i;
                        return "/" !== a && (u = "/" === i ? a : I([a, i])), o.createHref({
                            pathname: u,
                            search: s,
                            hash: l
                        })
                    }(d, {
                        relative: o
                    }),
                    b = function(e, t) {
                        let {
                            target: n,
                            replace: a,
                            state: o,
                            preventScrollReset: l,
                            relative: i,
                            unstable_viewTransition: s
                        } = void 0 === t ? {} : t, u = ee(), c = Y(), d = ne(e, {
                            relative: i
                        });
                        return r.useCallback((t => {
                            if (function(e, t) {
                                    return 0 === e.button && (!t || "_self" === t) && ! function(e) {
                                        return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
                                    }(e)
                                }(t, n)) {
                                t.preventDefault();
                                let n = void 0 !== a ? a : h(c) === h(d);
                                u(e, {
                                    replace: n,
                                    state: o,
                                    preventScrollReset: l,
                                    relative: i,
                                    unstable_viewTransition: s
                                })
                            }
                        }), [c, u, d, a, o, n, e, l, i, s])
                    }(d, {
                        replace: i,
                        state: s,
                        target: u,
                        preventScrollReset: f,
                        relative: o,
                        unstable_viewTransition: p
                    });
                return r.createElement("a", xe({}, m, {
                    href: n || v,
                    onClick: y || l ? a : function(e) {
                        a && a(e), e.defaultPrevented || b(e)
                    },
                    ref: t,
                    target: u
                }))
            }));
        const Oe = r.forwardRef((function(e, t) {
            let {
                "aria-current": n = "page",
                caseSensitive: a = !1,
                className: o = "",
                end: l = !1,
                style: i,
                to: s,
                unstable_viewTransition: u,
                children: d
            } = e, f = Se(e, Ee), p = ne(s, {
                relative: f.relative
            }), h = Y(), m = r.useContext(q), {
                navigator: g,
                basename: y
            } = r.useContext(Q), v = null != m && function(e, t) {
                void 0 === t && (t = {});
                let n = r.useContext(Ce);
                null == n && c(!1);
                let {
                    basename: a
                } = ze(Re.useViewTransitionState), o = ne(e, {
                    relative: t.relative
                });
                if (!n.isTransitioning) return !1;
                let l = R(n.currentLocation.pathname, a) || n.currentLocation.pathname,
                    i = R(n.nextLocation.pathname, a) || n.nextLocation.pathname;
                return null != P(o.pathname, i) || null != P(o.pathname, l)
            }(p) && !0 === u, b = g.encodeLocation ? g.encodeLocation(p).pathname : p.pathname, w = h.pathname, x = m && m.navigation && m.navigation.location ? m.navigation.location.pathname : null;
            a || (w = w.toLowerCase(), x = x ? x.toLowerCase() : null, b = b.toLowerCase()), x && y && (x = R(x, y) || x);
            const S = "/" !== b && b.endsWith("/") ? b.length - 1 : b.length;
            let k, E = w === b || !l && w.startsWith(b) && "/" === w.charAt(S),
                C = null != x && (x === b || !l && x.startsWith(b) && "/" === x.charAt(b.length)),
                N = {
                    isActive: E,
                    isPending: C,
                    isTransitioning: v
                },
                j = E ? n : void 0;
            k = "function" === typeof o ? o(N) : [o, E ? "active" : null, C ? "pending" : null, v ? "transitioning" : null].filter(Boolean).join(" ");
            let _ = "function" === typeof i ? i(N) : i;
            return r.createElement(Pe, xe({}, f, {
                "aria-current": j,
                className: k,
                ref: t,
                style: _,
                to: s,
                unstable_viewTransition: u
            }), "function" === typeof d ? d(N) : d)
        }));
        var Re, Le;

        function ze(e) {
            let t = r.useContext($);
            return t || c(!1), t
        }(function(e) {
            e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
        })(Re || (Re = {})),
        function(e) {
            e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
        }(Le || (Le = {}));
        const De = (e, t) => {
            switch (t.type) {
                case "LOADING":
                    return { ...e,
                        isLoading: !0,
                        isError: ""
                    };
                case "HANDLE_INPUT":
                    return { ...e,
                        data: { ...e.data,
                            [t.payload.name]: t.payload.value
                        }
                    };
                case "USER_SIGNUP":
                    return { ...e,
                        isLoading: !1
                    };
                case "USER_LOGIN":
                    return { ...e,
                        isAuth: !0,
                        isLoading: !1
                    };
                case "LOAD_USER":
                    return { ...e,
                        isAuth: !0,
                        isLoading: !1,
                        user: t.payload.user,
                        isSuccess: !0
                    };
                case "LOAD_USER_ERROR":
                    return { ...e,
                        isLoading: !1,
                        isSuccess: !1,
                        isAuth: !1
                    };
                case "USER_LOGOUT":
                    return { ...e,
                        isAuth: !1,
                        isLoading: !1,
                        user: {}
                    };
                default:
                    return e
            }
        };

        function Ae(e) {
            var t, n, r = "";
            if ("string" == typeof e || "number" == typeof e) r += e;
            else if ("object" == typeof e)
                if (Array.isArray(e)) {
                    var a = e.length;
                    for (t = 0; t < a; t++) e[t] && (n = Ae(e[t])) && (r && (r += " "), r += n)
                } else
                    for (n in e) e[n] && (r && (r += " "), r += n);
            return r
        }
        const Ie = function() {
                for (var e, t, n = 0, r = "", a = arguments.length; n < a; n++)(e = arguments[n]) && (t = Ae(e)) && (r && (r += " "), r += t);
                return r
            },
            Fe = e => "number" == typeof e && !isNaN(e),
            Ue = e => "string" == typeof e,
            Me = e => "function" == typeof e,
            Be = e => Ue(e) || Me(e) ? e : null,
            He = e => (0, r.isValidElement)(e) || Ue(e) || Me(e) || Fe(e);

        function We(e) {
            let {
                enter: t,
                exit: n,
                appendPosition: a = !1,
                collapse: o = !0,
                collapseDuration: l = 300
            } = e;
            return function(e) {
                let {
                    children: i,
                    position: s,
                    preventExitTransition: u,
                    done: c,
                    nodeRef: d,
                    isIn: f,
                    playToast: p
                } = e;
                const h = a ? "".concat(t, "--").concat(s) : t,
                    m = a ? "".concat(n, "--").concat(s) : n,
                    g = (0, r.useRef)(0);
                return (0, r.useLayoutEffect)((() => {
                    const e = d.current,
                        t = h.split(" "),
                        n = r => {
                            r.target === d.current && (p(), e.removeEventListener("animationend", n), e.removeEventListener("animationcancel", n), 0 === g.current && "animationcancel" !== r.type && e.classList.remove(...t))
                        };
                    e.classList.add(...t), e.addEventListener("animationend", n), e.addEventListener("animationcancel", n)
                }), []), (0, r.useEffect)((() => {
                    const e = d.current,
                        t = () => {
                            e.removeEventListener("animationend", t), o ? function(e, t, n) {
                                void 0 === n && (n = 300);
                                const {
                                    scrollHeight: r,
                                    style: a
                                } = e;
                                requestAnimationFrame((() => {
                                    a.minHeight = "initial", a.height = r + "px", a.transition = "all ".concat(n, "ms"), requestAnimationFrame((() => {
                                        a.height = "0", a.padding = "0", a.margin = "0", setTimeout(t, n)
                                    }))
                                }))
                            }(e, c, l) : c()
                        };
                    f || (u ? t() : (g.current = 1, e.className += " ".concat(m), e.addEventListener("animationend", t)))
                }), [f]), r.createElement(r.Fragment, null, i)
            }
        }

        function Ve(e, t) {
            return null != e ? {
                content: e.content,
                containerId: e.props.containerId,
                id: e.props.toastId,
                theme: e.props.theme,
                type: e.props.type,
                data: e.props.data || {},
                isLoading: e.props.isLoading,
                icon: e.props.icon,
                status: t
            } : {}
        }
        const $e = new Map;
        let qe = [];
        const Qe = new Set,
            Ke = e => Qe.forEach((t => t(e))),
            Ge = () => $e.size > 0;

        function Je(e, t) {
            var n;
            if (t) return !(null == (n = $e.get(t)) || !n.isToastActive(e));
            let r = !1;
            return $e.forEach((t => {
                t.isToastActive(e) && (r = !0)
            })), r
        }

        function Xe(e, t) {
            He(e) && (Ge() || qe.push({
                content: e,
                options: t
            }), $e.forEach((n => {
                n.buildToast(e, t)
            })))
        }

        function Ye(e, t) {
            $e.forEach((n => {
                null != t && null != t && t.containerId ? (null == t ? void 0 : t.containerId) === n.id && n.toggle(e, null == t ? void 0 : t.id) : n.toggle(e, null == t ? void 0 : t.id)
            }))
        }

        function Ze(e) {
            const {
                subscribe: t,
                getSnapshot: n,
                setProps: a
            } = (0, r.useRef)(function(e) {
                const t = e.containerId || 1;
                return {
                    subscribe(n) {
                        const a = function(e, t, n) {
                            let a = 1,
                                o = 0,
                                l = [],
                                i = [],
                                s = [],
                                u = t;
                            const c = new Map,
                                d = new Set,
                                f = () => {
                                    s = Array.from(c.values()), d.forEach((e => e()))
                                },
                                p = e => {
                                    i = null == e ? [] : i.filter((t => t !== e)), f()
                                },
                                h = e => {
                                    const {
                                        toastId: t,
                                        onOpen: a,
                                        updateId: o,
                                        children: l
                                    } = e.props, s = null == o;
                                    e.staleId && c.delete(e.staleId), c.set(t, e), i = [...i, e.props.toastId].filter((t => t !== e.staleId)), f(), n(Ve(e, s ? "added" : "updated")), s && Me(a) && a((0, r.isValidElement)(l) && l.props)
                                };
                            return {
                                id: e,
                                props: u,
                                observe: e => (d.add(e), () => d.delete(e)),
                                toggle: (e, t) => {
                                    c.forEach((n => {
                                        null != t && t !== n.props.toastId || Me(n.toggle) && n.toggle(e)
                                    }))
                                },
                                removeToast: p,
                                toasts: c,
                                clearQueue: () => {
                                    o -= l.length, l = []
                                },
                                buildToast: (t, i) => {
                                    if ((t => {
                                            let {
                                                containerId: n,
                                                toastId: r,
                                                updateId: a
                                            } = t;
                                            const o = n ? n !== e : 1 !== e,
                                                l = c.has(r) && null == a;
                                            return o || l
                                        })(i)) return;
                                    const {
                                        toastId: s,
                                        updateId: d,
                                        data: m,
                                        staleId: g,
                                        delay: y
                                    } = i, v = () => {
                                        p(s)
                                    }, b = null == d;
                                    b && o++;
                                    const w = { ...u,
                                        style: u.toastStyle,
                                        key: a++,
                                        ...Object.fromEntries(Object.entries(i).filter((e => {
                                            let [t, n] = e;
                                            return null != n
                                        }))),
                                        toastId: s,
                                        updateId: d,
                                        data: m,
                                        closeToast: v,
                                        isIn: !1,
                                        className: Be(i.className || u.toastClassName),
                                        bodyClassName: Be(i.bodyClassName || u.bodyClassName),
                                        progressClassName: Be(i.progressClassName || u.progressClassName),
                                        autoClose: !i.isLoading && (x = i.autoClose, S = u.autoClose, !1 === x || Fe(x) && x > 0 ? x : S),
                                        deleteToast() {
                                            const e = c.get(s),
                                                {
                                                    onClose: t,
                                                    children: a
                                                } = e.props;
                                            Me(t) && t((0, r.isValidElement)(a) && a.props), n(Ve(e, "removed")), c.delete(s), o--, o < 0 && (o = 0), l.length > 0 ? h(l.shift()) : f()
                                        }
                                    };
                                    var x, S;
                                    w.closeButton = u.closeButton, !1 === i.closeButton || He(i.closeButton) ? w.closeButton = i.closeButton : !0 === i.closeButton && (w.closeButton = !He(u.closeButton) || u.closeButton);
                                    let k = t;
                                    (0, r.isValidElement)(t) && !Ue(t.type) ? k = (0, r.cloneElement)(t, {
                                        closeToast: v,
                                        toastProps: w,
                                        data: m
                                    }) : Me(t) && (k = t({
                                        closeToast: v,
                                        toastProps: w,
                                        data: m
                                    }));
                                    const E = {
                                        content: k,
                                        props: w,
                                        staleId: g
                                    };
                                    u.limit && u.limit > 0 && o > u.limit && b ? l.push(E) : Fe(y) ? setTimeout((() => {
                                        h(E)
                                    }), y) : h(E)
                                },
                                setProps(e) {
                                    u = e
                                },
                                setToggle: (e, t) => {
                                    c.get(e).toggle = t
                                },
                                isToastActive: e => i.some((t => t === e)),
                                getSnapshot: () => u.newestOnTop ? s.reverse() : s
                            }
                        }(t, e, Ke);
                        $e.set(t, a);
                        const o = a.observe(n);
                        return qe.forEach((e => Xe(e.content, e.options))), qe = [], () => {
                            o(), $e.delete(t)
                        }
                    },
                    setProps(e) {
                        var n;
                        null == (n = $e.get(t)) || n.setProps(e)
                    },
                    getSnapshot() {
                        var e;
                        return null == (e = $e.get(t)) ? void 0 : e.getSnapshot()
                    }
                }
            }(e)).current;
            a(e);
            const o = (0, r.useSyncExternalStore)(t, n, n);
            return {
                getToastToRender: function(e) {
                    if (!o) return [];
                    const t = new Map;
                    return o.forEach((e => {
                        const {
                            position: n
                        } = e.props;
                        t.has(n) || t.set(n, []), t.get(n).push(e)
                    })), Array.from(t, (t => e(t[0], t[1])))
                },
                isToastActive: Je,
                count: null == o ? void 0 : o.length
            }
        }

        function et(e) {
            const [t, n] = (0, r.useState)(!1), [a, o] = (0, r.useState)(!1), l = (0, r.useRef)(null), i = (0, r.useRef)({
                start: 0,
                delta: 0,
                removalDistance: 0,
                canCloseOnClick: !0,
                canDrag: !1,
                didMove: !1
            }).current, {
                autoClose: s,
                pauseOnHover: u,
                closeToast: c,
                onClick: d,
                closeOnClick: f
            } = e;
            var p, h;

            function m() {
                n(!0)
            }

            function g() {
                n(!1)
            }

            function y(n) {
                const r = l.current;
                i.canDrag && r && (i.didMove = !0, t && g(), i.delta = "x" === e.draggableDirection ? n.clientX - i.start : n.clientY - i.start, i.start !== n.clientX && (i.canCloseOnClick = !1), r.style.transform = "translate3d(".concat("x" === e.draggableDirection ? "".concat(i.delta, "px, var(--y)") : "0, calc(".concat(i.delta, "px + var(--y))"), ",0)"), r.style.opacity = "" + (1 - Math.abs(i.delta / i.removalDistance)))
            }

            function v() {
                document.removeEventListener("pointermove", y), document.removeEventListener("pointerup", v);
                const t = l.current;
                if (i.canDrag && i.didMove && t) {
                    if (i.canDrag = !1, Math.abs(i.delta) > i.removalDistance) return o(!0), e.closeToast(), void e.collapseAll();
                    t.style.transition = "transform 0.2s, opacity 0.2s", t.style.removeProperty("transform"), t.style.removeProperty("opacity")
                }
            }
            null == (h = $e.get((p = {
                id: e.toastId,
                containerId: e.containerId,
                fn: n
            }).containerId || 1)) || h.setToggle(p.id, p.fn), (0, r.useEffect)((() => {
                if (e.pauseOnFocusLoss) return document.hasFocus() || g(), window.addEventListener("focus", m), window.addEventListener("blur", g), () => {
                    window.removeEventListener("focus", m), window.removeEventListener("blur", g)
                }
            }), [e.pauseOnFocusLoss]);
            const b = {
                onPointerDown: function(t) {
                    if (!0 === e.draggable || e.draggable === t.pointerType) {
                        i.didMove = !1, document.addEventListener("pointermove", y), document.addEventListener("pointerup", v);
                        const n = l.current;
                        i.canCloseOnClick = !0, i.canDrag = !0, n.style.transition = "none", "x" === e.draggableDirection ? (i.start = t.clientX, i.removalDistance = n.offsetWidth * (e.draggablePercent / 100)) : (i.start = t.clientY, i.removalDistance = n.offsetHeight * (80 === e.draggablePercent ? 1.5 * e.draggablePercent : e.draggablePercent) / 100)
                    }
                },
                onPointerUp: function(t) {
                    const {
                        top: n,
                        bottom: r,
                        left: a,
                        right: o
                    } = l.current.getBoundingClientRect();
                    "touchend" !== t.nativeEvent.type && e.pauseOnHover && t.clientX >= a && t.clientX <= o && t.clientY >= n && t.clientY <= r ? g() : m()
                }
            };
            return s && u && (b.onMouseEnter = g, e.stacked || (b.onMouseLeave = m)), f && (b.onClick = e => {
                d && d(e), i.canCloseOnClick && c()
            }), {
                playToast: m,
                pauseToast: g,
                isRunning: t,
                preventExitTransition: a,
                toastRef: l,
                eventHandlers: b
            }
        }

        function tt(e) {
            let {
                delay: t,
                isRunning: n,
                closeToast: a,
                type: o = "default",
                hide: l,
                className: i,
                style: s,
                controlledProgress: u,
                progress: c,
                rtl: d,
                isIn: f,
                theme: p
            } = e;
            const h = l || u && 0 === c,
                m = { ...s,
                    animationDuration: "".concat(t, "ms"),
                    animationPlayState: n ? "running" : "paused"
                };
            u && (m.transform = "scaleX(".concat(c, ")"));
            const g = Ie("Toastify__progress-bar", u ? "Toastify__progress-bar--controlled" : "Toastify__progress-bar--animated", "Toastify__progress-bar-theme--".concat(p), "Toastify__progress-bar--".concat(o), {
                    "Toastify__progress-bar--rtl": d
                }),
                y = Me(i) ? i({
                    rtl: d,
                    type: o,
                    defaultClassName: g
                }) : Ie(g, i),
                v = {
                    [u && c >= 1 ? "onTransitionEnd" : "onAnimationEnd"]: u && c < 1 ? null : () => {
                        f && a()
                    }
                };
            return r.createElement("div", {
                className: "Toastify__progress-bar--wrp",
                "data-hidden": h
            }, r.createElement("div", {
                className: "Toastify__progress-bar--bg Toastify__progress-bar-theme--".concat(p, " Toastify__progress-bar--").concat(o)
            }), r.createElement("div", {
                role: "progressbar",
                "aria-hidden": h ? "true" : "false",
                "aria-label": "notification timer",
                className: y,
                style: m,
                ...v
            }))
        }
        let nt = 1;
        const rt = () => "" + nt++;

        function at(e) {
            return e && (Ue(e.toastId) || Fe(e.toastId)) ? e.toastId : rt()
        }

        function ot(e, t) {
            return Xe(e, t), t.toastId
        }

        function lt(e, t) {
            return { ...t,
                type: t && t.type || e,
                toastId: at(t)
            }
        }

        function it(e) {
            return (t, n) => ot(t, lt(e, n))
        }

        function st(e, t) {
            return ot(e, lt("default", t))
        }
        st.loading = (e, t) => ot(e, lt("default", {
            isLoading: !0,
            autoClose: !1,
            closeOnClick: !1,
            closeButton: !1,
            draggable: !1,
            ...t
        })), st.promise = function(e, t, n) {
            let r, {
                pending: a,
                error: o,
                success: l
            } = t;
            a && (r = Ue(a) ? st.loading(a, n) : st.loading(a.render, { ...n,
                ...a
            }));
            const i = {
                    isLoading: null,
                    autoClose: null,
                    closeOnClick: null,
                    closeButton: null,
                    draggable: null
                },
                s = (e, t, a) => {
                    if (null == t) return void st.dismiss(r);
                    const o = {
                            type: e,
                            ...i,
                            ...n,
                            data: a
                        },
                        l = Ue(t) ? {
                            render: t
                        } : t;
                    return r ? st.update(r, { ...o,
                        ...l
                    }) : st(l.render, { ...o,
                        ...l
                    }), a
                },
                u = Me(e) ? e() : e;
            return u.then((e => s("success", l, e))).catch((e => s("error", o, e))), u
        }, st.success = it("success"), st.info = it("info"), st.error = it("error"), st.warning = it("warning"), st.warn = st.warning, st.dark = (e, t) => ot(e, lt("default", {
            theme: "dark",
            ...t
        })), st.dismiss = function(e) {
            ! function(e) {
                var t;
                if (Ge()) {
                    if (null == e || Ue(t = e) || Fe(t)) $e.forEach((t => {
                        t.removeToast(e)
                    }));
                    else if (e && ("containerId" in e || "id" in e)) {
                        var n;
                        (null == (n = $e.get(e.containerId)) ? void 0 : n.removeToast(e.id)) || $e.forEach((t => {
                            t.removeToast(e.id)
                        }))
                    }
                } else qe = qe.filter((t => null != e && t.options.toastId !== e))
            }(e)
        }, st.clearWaitingQueue = function(e) {
            void 0 === e && (e = {}), $e.forEach((t => {
                !t.props.limit || e.containerId && t.id !== e.containerId || t.clearQueue()
            }))
        }, st.isActive = Je, st.update = function(e, t) {
            void 0 === t && (t = {});
            const n = ((e, t) => {
                var n;
                let {
                    containerId: r
                } = t;
                return null == (n = $e.get(r || 1)) ? void 0 : n.toasts.get(e)
            })(e, t);
            if (n) {
                const {
                    props: r,
                    content: a
                } = n, o = {
                    delay: 100,
                    ...r,
                    ...t,
                    toastId: t.toastId || e,
                    updateId: rt()
                };
                o.toastId !== e && (o.staleId = e);
                const l = o.render || a;
                delete o.render, ot(l, o)
            }
        }, st.done = e => {
            st.update(e, {
                progress: 1
            })
        }, st.onChange = function(e) {
            return Qe.add(e), () => {
                Qe.delete(e)
            }
        }, st.play = e => Ye(!0, e), st.pause = e => Ye(!1, e);
        const ut = "undefined" != typeof window ? r.useLayoutEffect : r.useEffect,
            ct = e => {
                let {
                    theme: t,
                    type: n,
                    isLoading: a,
                    ...o
                } = e;
                return r.createElement("svg", {
                    viewBox: "0 0 24 24",
                    width: "100%",
                    height: "100%",
                    fill: "colored" === t ? "currentColor" : "var(--toastify-icon-color-".concat(n, ")"),
                    ...o
                })
            },
            dt = {
                info: function(e) {
                    return r.createElement(ct, { ...e
                    }, r.createElement("path", {
                        d: "M12 0a12 12 0 1012 12A12.013 12.013 0 0012 0zm.25 5a1.5 1.5 0 11-1.5 1.5 1.5 1.5 0 011.5-1.5zm2.25 13.5h-4a1 1 0 010-2h.75a.25.25 0 00.25-.25v-4.5a.25.25 0 00-.25-.25h-.75a1 1 0 010-2h1a2 2 0 012 2v4.75a.25.25 0 00.25.25h.75a1 1 0 110 2z"
                    }))
                },
                warning: function(e) {
                    return r.createElement(ct, { ...e
                    }, r.createElement("path", {
                        d: "M23.32 17.191L15.438 2.184C14.728.833 13.416 0 11.996 0c-1.42 0-2.733.833-3.443 2.184L.533 17.448a4.744 4.744 0 000 4.368C1.243 23.167 2.555 24 3.975 24h16.05C22.22 24 24 22.044 24 19.632c0-.904-.251-1.746-.68-2.44zm-9.622 1.46c0 1.033-.724 1.823-1.698 1.823s-1.698-.79-1.698-1.822v-.043c0-1.028.724-1.822 1.698-1.822s1.698.79 1.698 1.822v.043zm.039-12.285l-.84 8.06c-.057.581-.408.943-.897.943-.49 0-.84-.367-.896-.942l-.84-8.065c-.057-.624.25-1.095.779-1.095h1.91c.528.005.84.476.784 1.1z"
                    }))
                },
                success: function(e) {
                    return r.createElement(ct, { ...e
                    }, r.createElement("path", {
                        d: "M12 0a12 12 0 1012 12A12.014 12.014 0 0012 0zm6.927 8.2l-6.845 9.289a1.011 1.011 0 01-1.43.188l-4.888-3.908a1 1 0 111.25-1.562l4.076 3.261 6.227-8.451a1 1 0 111.61 1.183z"
                    }))
                },
                error: function(e) {
                    return r.createElement(ct, { ...e
                    }, r.createElement("path", {
                        d: "M11.983 0a12.206 12.206 0 00-8.51 3.653A11.8 11.8 0 000 12.207 11.779 11.779 0 0011.8 24h.214A12.111 12.111 0 0024 11.791 11.766 11.766 0 0011.983 0zM10.5 16.542a1.476 1.476 0 011.449-1.53h.027a1.527 1.527 0 011.523 1.47 1.475 1.475 0 01-1.449 1.53h-.027a1.529 1.529 0 01-1.523-1.47zM11 12.5v-6a1 1 0 012 0v6a1 1 0 11-2 0z"
                    }))
                },
                spinner: function() {
                    return r.createElement("div", {
                        className: "Toastify__spinner"
                    })
                }
            },
            ft = e => {
                const {
                    isRunning: t,
                    preventExitTransition: n,
                    toastRef: a,
                    eventHandlers: o,
                    playToast: l
                } = et(e), {
                    closeButton: i,
                    children: s,
                    autoClose: u,
                    onClick: c,
                    type: d,
                    hideProgressBar: f,
                    closeToast: p,
                    transition: h,
                    position: m,
                    className: g,
                    style: y,
                    bodyClassName: v,
                    bodyStyle: b,
                    progressClassName: w,
                    progressStyle: x,
                    updateId: S,
                    role: k,
                    progress: E,
                    rtl: C,
                    toastId: N,
                    deleteToast: j,
                    isIn: _,
                    isLoading: T,
                    closeOnClick: P,
                    theme: O
                } = e, R = Ie("Toastify__toast", "Toastify__toast-theme--".concat(O), "Toastify__toast--".concat(d), {
                    "Toastify__toast--rtl": C
                }, {
                    "Toastify__toast--close-on-click": P
                }), L = Me(g) ? g({
                    rtl: C,
                    position: m,
                    type: d,
                    defaultClassName: R
                }) : Ie(R, g), z = function(e) {
                    let {
                        theme: t,
                        type: n,
                        isLoading: a,
                        icon: o
                    } = e, l = null;
                    const i = {
                        theme: t,
                        type: n
                    };
                    return !1 === o || (Me(o) ? l = o({ ...i,
                        isLoading: a
                    }) : (0, r.isValidElement)(o) ? l = (0, r.cloneElement)(o, i) : a ? l = dt.spinner() : (e => e in dt)(n) && (l = dt[n](i))), l
                }(e), D = !!E || !u, A = {
                    closeToast: p,
                    type: d,
                    theme: O
                };
                let I = null;
                return !1 === i || (I = Me(i) ? i(A) : (0, r.isValidElement)(i) ? (0, r.cloneElement)(i, A) : function(e) {
                    let {
                        closeToast: t,
                        theme: n,
                        ariaLabel: a = "close"
                    } = e;
                    return r.createElement("button", {
                        className: "Toastify__close-button Toastify__close-button--".concat(n),
                        type: "button",
                        onClick: e => {
                            e.stopPropagation(), t(e)
                        },
                        "aria-label": a
                    }, r.createElement("svg", {
                        "aria-hidden": "true",
                        viewBox: "0 0 14 16"
                    }, r.createElement("path", {
                        fillRule: "evenodd",
                        d: "M7.71 8.23l3.75 3.75-1.48 1.48-3.75-3.75-3.75 3.75L1 11.98l3.75-3.75L1 4.48 2.48 3l3.75 3.75L9.98 3l1.48 1.48-3.75 3.75z"
                    })))
                }(A)), r.createElement(h, {
                    isIn: _,
                    done: j,
                    position: m,
                    preventExitTransition: n,
                    nodeRef: a,
                    playToast: l
                }, r.createElement("div", {
                    id: N,
                    onClick: c,
                    "data-in": _,
                    className: L,
                    ...o,
                    style: y,
                    ref: a
                }, r.createElement("div", { ..._ && {
                        role: k
                    },
                    className: Me(v) ? v({
                        type: d
                    }) : Ie("Toastify__toast-body", v),
                    style: b
                }, null != z && r.createElement("div", {
                    className: Ie("Toastify__toast-icon", {
                        "Toastify--animate-icon Toastify__zoom-enter": !T
                    })
                }, z), r.createElement("div", null, s)), I, r.createElement(tt, { ...S && !D ? {
                        key: "pb-".concat(S)
                    } : {},
                    rtl: C,
                    theme: O,
                    delay: u,
                    isRunning: t,
                    isIn: _,
                    closeToast: p,
                    hide: f,
                    type: d,
                    style: x,
                    className: w,
                    controlledProgress: D,
                    progress: E || 0
                })))
            },
            pt = function(e, t) {
                return void 0 === t && (t = !1), {
                    enter: "Toastify--animate Toastify__".concat(e, "-enter"),
                    exit: "Toastify--animate Toastify__".concat(e, "-exit"),
                    appendPosition: t
                }
            },
            ht = We(pt("bounce", !0)),
            mt = (We(pt("slide", !0)), We(pt("zoom")), We(pt("flip")), {
                position: "top-right",
                transition: ht,
                autoClose: 5e3,
                closeButton: !0,
                pauseOnHover: !0,
                pauseOnFocusLoss: !0,
                draggable: "touch",
                draggablePercent: 80,
                draggableDirection: "x",
                role: "alert",
                theme: "light"
            });

        function gt(e) {
            let t = { ...mt,
                ...e
            };
            const n = e.stacked,
                [a, o] = (0, r.useState)(!0),
                l = (0, r.useRef)(null),
                {
                    getToastToRender: i,
                    isToastActive: s,
                    count: u
                } = Ze(t),
                {
                    className: c,
                    style: d,
                    rtl: f,
                    containerId: p
                } = t;

            function h(e) {
                const t = Ie("Toastify__toast-container", "Toastify__toast-container--".concat(e), {
                    "Toastify__toast-container--rtl": f
                });
                return Me(c) ? c({
                    position: e,
                    rtl: f,
                    defaultClassName: t
                }) : Ie(t, Be(c))
            }

            function m() {
                n && (o(!0), st.play())
            }
            return ut((() => {
                if (n) {
                    var e;
                    const n = l.current.querySelectorAll('[data-in="true"]'),
                        r = 12,
                        o = null == (e = t.position) ? void 0 : e.includes("top");
                    let i = 0,
                        s = 0;
                    Array.from(n).reverse().forEach(((e, t) => {
                        const n = e;
                        n.classList.add("Toastify__toast--stacked"), t > 0 && (n.dataset.collapsed = "".concat(a)), n.dataset.pos || (n.dataset.pos = o ? "top" : "bot");
                        const l = i * (a ? .2 : 1) + (a ? 0 : r * t);
                        n.style.setProperty("--y", "".concat(o ? l : -1 * l, "px")), n.style.setProperty("--g", "".concat(r)), n.style.setProperty("--s", "" + (1 - (a ? s : 0))), i += n.offsetHeight, s += .025
                    }))
                }
            }), [a, u, n]), r.createElement("div", {
                ref: l,
                className: "Toastify",
                id: p,
                onMouseEnter: () => {
                    n && (o(!1), st.pause())
                },
                onMouseLeave: m
            }, i(((e, t) => {
                const a = t.length ? { ...d
                } : { ...d,
                    pointerEvents: "none"
                };
                return r.createElement("div", {
                    className: h(e),
                    style: a,
                    key: "container-".concat(e)
                }, t.map((e => {
                    let {
                        content: t,
                        props: a
                    } = e;
                    return r.createElement(ft, { ...a,
                        stacked: n,
                        collapseAll: m,
                        isIn: s(a.toastId, a.containerId),
                        style: a.style,
                        key: "toast-".concat(a.key)
                    }, t)
                })))
            })))
        }
        var yt = n(579);
        const vt = (0, r.createContext)(),
            bt = {
                isLoading: !0,
                data: {
                    username: "",
                    email: "",
                    password: ""
                },
                isAuth: !1,
                user: {},
                isSuccess: !1
            },
            wt = e => {
                let {
                    children: t
                } = e;
                const [n, a] = (0, r.useReducer)(De, bt), o = ee();
                let l = "https://itclg-api.onrender.com";
                const i = async () => {
                    a({
                        type: "LOADING"
                    });
                    try {
                        const e = await fetch("".concat(l, "/api/me"), {
                            method: "GET",
                            credentials: "include"
                        });
                        if (e.ok) {
                            const t = await e.json();
                            t.success && a({
                                type: "LOAD_USER",
                                payload: t
                            })
                        } else a({
                            type: "LOAD_USER_ERROR"
                        })
                    } catch (e) {
                        a({
                            type: "LOAD_USER_ERROR"
                        }), console.error("Network error:", e)
                    }
                };
                return (0, r.useEffect)((() => {
                    i()
                }), []), (0, yt.jsx)(vt.Provider, {
                    value: { ...n,
                        Signup: async e => {
                            e.preventDefault(), a({
                                type: "LOADING"
                            });
                            try {
                                const e = await fetch("".concat(l, "/api/signup"), {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify(n.data)
                                });
                                if (e.ok) {
                                    const t = await e.json();
                                    a({
                                        type: "USER_SIGNUP"
                                    }), a({
                                        type: "SUCCESS",
                                        payload: t
                                    }), o("/login")
                                } else {
                                    const t = await e.json();
                                    st.error(t.message)
                                }
                            } catch (t) {
                                st.error("Internal Server Error")
                            }
                        },
                        Login: async e => {
                            e.preventDefault(), a({
                                type: "LOADING"
                            });
                            try {
                                const e = await fetch("".concat(l, "/api/login"), {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify(n.data),
                                    credentials: "include"
                                });
                                if (e.ok) {
                                    const t = await e.json();
                                    a({
                                        type: "USER_LOGIN"
                                    }), await i(), st.success(t.message), o("/")
                                } else st.error("Invalid Credentials")
                            } catch (t) {
                                console.error("Network error:", t), st.error("Internal Server Error")
                            }
                        },
                        Logout: async () => {
                            a({
                                type: "LOADING"
                            });
                            try {
                                (await fetch("".concat(l, "/api/logout"), {
                                    method: "POST",
                                    credentials: "include"
                                })).ok ? (a({
                                    type: "USER_LOGOUT"
                                }), st.success("Logout successful"), o("/login")) : st.error("Failed to log out")
                            } catch (e) {
                                console.error("Logout error:", e.message), st.error("Internal Server Error")
                            }
                        },
                        handleInput: e => {
                            const {
                                name: t,
                                value: n
                            } = e.target;
                            a({
                                type: "HANDLE_INPUT",
                                payload: {
                                    name: t,
                                    value: n
                                }
                            })
                        }
                    },
                    children: t
                })
            },
            xt = () => (0, r.useContext)(vt),
            St = () => {
                const {
                    isAuth: e,
                    Logout: t
                } = xt();
                return (0, yt.jsx)("nav", {
                    className: "navbar navbar-expand-lg bg-blue",
                    style: {
                        opacity: "0.9"
                    },
                    children: (0, yt.jsxs)("div", {
                        className: "container",
                        children: [(0, yt.jsxs)("div", {
                            className: "d-flex align-items-center",
                            children: [(0, yt.jsx)("img", {
                                src: "/image/logo.jpeg",
                                alt: "logo",
                                className: "rounded-circle shadow-sm img-fluid me-2",
                                style: {
                                    width: "45px",
                                    height: "45px",
                                    objectFit: "cover"
                                }
                            }), (0, yt.jsx)("h2", {
                                className: "navbar-brand text-light fw-bolder my-auto fs-6 fs-md-4 text-nowrap",
                                children: "IT Computer Education World"
                            })]
                        }), (0, yt.jsx)("button", {
                            className: "navbar-toggler btn-sm p-1",
                            type: "button",
                            "data-bs-toggle": "collapse",
                            "data-bs-target": "#navbarNav",
                            "aria-controls": "navbarNav",
                            "aria-expanded": "false",
                            "aria-label": "Toggle navigation",
                            children: (0, yt.jsx)("span", {
                                className: "navbar-toggler-icon",
                                style: {
                                    width: "20px",
                                    height: "20px"
                                }
                            })
                        }), (0, yt.jsx)("div", {
                            className: "collapse navbar-collapse justify-content-lg-end mt-2 mt-lg-0",
                            id: "navbarNav",
                            children: (0, yt.jsxs)("div", {
                                className: "d-flex flex-column flex-lg-row gap-2 align-items-lg-center",
                                children: [(0, yt.jsx)(Oe, {
                                    to: "/",
                                    className: "text-decoration-none",
                                    children: (0, yt.jsx)("button", {
                                        className: "btn btn-outline-light w-100 w-lg-auto",
                                        children: "Home"
                                    })
                                }), (0, yt.jsx)(Oe, {
                                    to: "/about",
                                    className: "text-decoration-none",
                                    children: (0, yt.jsx)("button", {
                                        className: "btn btn-outline-light w-100 w-lg-auto",
                                        children: "About ITC"
                                    })
                                }), e && (0, yt.jsx)(yt.Fragment, {
                                    children: (0, yt.jsx)(Oe, {
                                        to: "/register",
                                        className: "text-decoration-none",
                                        children: (0, yt.jsx)("button", {
                                            className: "btn btn-outline-light w-100 w-lg-auto",
                                            children: "Register Student"
                                        })
                                    })
                                }), e && (0, yt.jsx)(Oe, {
                                    to: "/logout",
                                    className: "text-decoration-none",
                                    children: (0, yt.jsx)("button", {
                                        className: "btn btn-outline-light w-100 w-lg-auto",
                                        onClick: t,
                                        children: "Log out"
                                    })
                                })]
                            })
                        })]
                    })
                })
            },
            kt = () => {
                const [e, t] = (0, r.useState)("image/profile.webp"), [n, a] = (0, r.useState)(!1), [o, l] = (0, r.useState)({
                    card: "",
                    name: "",
                    session: "",
                    fname: "",
                    address: "",
                    city: "",
                    state: "",
                    course: "",
                    image: ""
                }), i = (0, r.useRef)(null);
                (0, r.useEffect)((() => {
                    const e = Object.values(o).every((e => "" !== e.trim()));
                    a(e)
                }), [o]);
                const s = e => {
                    const {
                        name: t,
                        value: n
                    } = e.target;
                    l({ ...o,
                        [t]: n
                    })
                };
                return (0, yt.jsxs)("div", {
                    className: "container-fluid py-5",
                    style: {
                        background: "#f1fff2"
                    },
                    children: [(0, yt.jsx)("div", {
                        className: "d-flex justify-content-center",
                        children: (0, yt.jsx)("h1", {
                            className: "text-center bg-orange w-75 text-light rounded-2 p-2 shadow",
                            children: "Online Attendance Registration Portal - ITCEW"
                        })
                    }), (0, yt.jsx)("form", {
                        className: "my-5 container border rounded-3 shadow-lg p-4 bg-white",
                        onSubmit: async e => {
                            e.preventDefault();
                            try {
                                if (!n) return void st.error("Please fill in all fields.");
                                const e = "https://itclg-api.onrender.com",
                                    r = await fetch("".concat(e, "/api/createstudent"), {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify(o),
                                        credentials: "include"
                                    }),
                                    a = await r.json();
                                r.ok ? (l({
                                    card: "",
                                    name: "",
                                    session: "",
                                    fname: "",
                                    address: "",
                                    city: "",
                                    state: "",
                                    course: "",
                                    image: ""
                                }), i.current && (i.current.value = ""), t("image/profile.webp"), st.success(a.message)) : st.error(a.message)
                            } catch (r) {
                                r.response && r.response.data && r.response.data.message ? st.error(r.response.data.message) : st.error("Request Not Sent. Something went wrong!")
                            }
                        },
                        children: (0, yt.jsxs)("div", {
                            className: "mb-3",
                            children: [(0, yt.jsxs)("div", {
                                className: "row",
                                children: [(0, yt.jsxs)("div", {
                                    className: "col-md-6",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "cardnumber",
                                        className: "form-label fw-bold",
                                        children: "I-card Number"
                                    }), (0, yt.jsx)("input", {
                                        onChange: s,
                                        name: "card",
                                        value: o.card,
                                        type: "number",
                                        className: "form-control form-control-lg",
                                        id: "cardnumber",
                                        required: !0
                                    })]
                                }), (0, yt.jsxs)("div", {
                                    className: "col-md-6",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "name",
                                        className: "form-label fw-bold",
                                        children: "Student Name"
                                    }), (0, yt.jsx)("input", {
                                        onChange: s,
                                        name: "name",
                                        value: o.name,
                                        type: "text",
                                        className: "form-control form-control-lg",
                                        id: "name",
                                        required: !0
                                    })]
                                })]
                            }), (0, yt.jsxs)("div", {
                                className: "row",
                                children: [(0, yt.jsxs)("div", {
                                    className: "col-md-4",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "session",
                                        className: "form-label fw-bold",
                                        children: "Session"
                                    }), (0, yt.jsx)("input", {
                                        onChange: s,
                                        name: "session",
                                        value: o.session,
                                        type: "text",
                                        className: "form-control form-control-lg",
                                        id: "session",
                                        required: !0
                                    })]
                                }), (0, yt.jsxs)("div", {
                                    className: "col-md-4",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "fname",
                                        className: "form-label fw-bold",
                                        children: "Father Name"
                                    }), (0, yt.jsx)("input", {
                                        onChange: s,
                                        name: "fname",
                                        value: o.fname,
                                        type: "text",
                                        className: "form-control form-control-lg",
                                        id: "fname",
                                        required: !0
                                    })]
                                }), (0, yt.jsxs)("div", {
                                    className: "col-md-4",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "course",
                                        className: "form-label fw-bold",
                                        children: "Course"
                                    }), (0, yt.jsxs)("select", {
                                        className: "form-select form-control-lg",
                                        id: "course",
                                        onChange: s,
                                        name: "course",
                                        value: o.course,
                                        required: !0,
                                        children: [(0, yt.jsx)("option", {
                                            value: "",
                                            disabled: !0,
                                            children: "Select Course"
                                        }), (0, yt.jsx)("option", {
                                            value: "ADIT",
                                            children: "ADIT"
                                        }), (0, yt.jsx)("option", {
                                            value: "ADHN",
                                            children: "ADHN"
                                        }), (0, yt.jsx)("option", {
                                            value: "HACKING",
                                            children: "HACKING"
                                        })]
                                    })]
                                })]
                            }), (0, yt.jsx)("div", {
                                className: "row",
                                children: (0, yt.jsxs)("div", {
                                    className: "col",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "address",
                                        className: "form-label fw-bold",
                                        children: "Address"
                                    }), (0, yt.jsx)("input", {
                                        onChange: s,
                                        name: "address",
                                        value: o.address,
                                        type: "text",
                                        className: "form-control form-control-lg",
                                        id: "address",
                                        required: !0
                                    })]
                                })
                            }), (0, yt.jsxs)("div", {
                                className: "row",
                                children: [(0, yt.jsxs)("div", {
                                    className: "col-md-6",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "city",
                                        className: "form-label fw-bold",
                                        children: "City"
                                    }), (0, yt.jsx)("input", {
                                        onChange: s,
                                        name: "city",
                                        value: o.city,
                                        type: "text",
                                        className: "form-control form-control-lg",
                                        id: "city",
                                        required: !0
                                    })]
                                }), (0, yt.jsxs)("div", {
                                    className: "col-md-6",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "state",
                                        className: "form-label fw-bold",
                                        children: "State"
                                    }), (0, yt.jsxs)("select", {
                                        className: "form-select form-control-lg",
                                        id: "state",
                                        onChange: s,
                                        name: "state",
                                        value: o.state,
                                        required: !0,
                                        children: [(0, yt.jsx)("option", {
                                            value: "",
                                            disabled: !0,
                                            children: "Select State"
                                        }), (0, yt.jsx)("option", {
                                            value: "U.P.",
                                            children: "U.P."
                                        }), (0, yt.jsx)("option", {
                                            value: "M.P.",
                                            children: "M.P."
                                        }), (0, yt.jsx)("option", {
                                            value: "JHARKHAND",
                                            children: "JHARKHAND"
                                        }), (0, yt.jsx)("option", {
                                            value: "DELHI",
                                            children: "DELHI"
                                        })]
                                    })]
                                })]
                            }), (0, yt.jsxs)("div", {
                                className: "row align-items-center",
                                children: [(0, yt.jsxs)("div", {
                                    className: "col-md-8",
                                    children: [(0, yt.jsx)("label", {
                                        htmlFor: "inputGroupFile02",
                                        className: "form-label fw-bold",
                                        children: "Upload Image"
                                    }), (0, yt.jsx)("div", {
                                        className: "input-group mb-3",
                                        children: (0, yt.jsx)("input", {
                                            type: "file",
                                            className: "form-control fw-bold",
                                            id: "inputGroupFile02",
                                            name: "image",
                                            onChange: e => {
                                                const n = e.target.files[0];
                                                if (n) {
                                                    if (n.size / 1024 <= 40) {
                                                        let e = new FileReader;
                                                        e.readAsDataURL(n), e.onload = () => {
                                                            t(e.result), l({ ...o,
                                                                image: e.result
                                                            })
                                                        }
                                                    } else a(!1), st.error("File size Should be less than 40kb", {
                                                        autoClose: 4e3
                                                    })
                                                }
                                            },
                                            ref: i
                                        })
                                    })]
                                }), (0, yt.jsx)("div", {
                                    className: "col-md-4",
                                    children: (0, yt.jsx)("div", {
                                        className: "card mx-auto border-0 shadow-sm",
                                        style: {
                                            width: "10rem"
                                        },
                                        children: (0, yt.jsx)("img", {
                                            src: e,
                                            className: "card-img-top rounded",
                                            alt: "Uploaded Preview"
                                        })
                                    })
                                })]
                            }), (0, yt.jsx)("div", {
                                className: "text-center mt-4",
                                children: (0, yt.jsx)("button", {
                                    disabled: !n,
                                    type: "submit",
                                    className: "btn btn-lg btn-warning fw-bold px-5",
                                    children: "Submit"
                                })
                            })]
                        })
                    })]
                })
            },
            Et = e => {
                const {
                    name: t,
                    course: n,
                    session: a,
                    fname: o,
                    image: l,
                    city: i,
                    card: s
                } = e.data.student, u = e => e.charAt(0).toUpperCase() + e.slice(1);
                let c = (new Date).toDateString(),
                    d = (new Date).toLocaleTimeString();
                const f = (0, r.useRef)(null);
                return (0, r.useEffect)((() => {
                    f.current && f.current.play()
                }), []), (0, yt.jsx)("div", {
                    children: (0, yt.jsx)("div", {
                        className: "container my-5 ",
                        style: {
                            minHeight: "100vh"
                        },
                        children: (0, yt.jsxs)("div", {
                            className: "row my-2 ",
                            children: [(0, yt.jsx)("hr", {}), (0, yt.jsxs)("div", {
                                className: "row ",
                                children: [(0, yt.jsxs)("div", {
                                    className: "row p-0",
                                    children: [(0, yt.jsx)("h5", {
                                        className: "text-primary",
                                        children: c
                                    }), (0, yt.jsx)("h5", {
                                        className: "fs-1 fw-bold text-primary",
                                        children: d
                                    })]
                                }), (0, yt.jsx)("hr", {}), (0, yt.jsxs)("div", {
                                    className: "row p-0",
                                    children: [(0, yt.jsxs)("div", {
                                        className: "d-flex ",
                                        children: [(0, yt.jsxs)("h5", {
                                            children: ["ID : ", (0, yt.jsx)("span", {
                                                className: "text-success",
                                                children: s
                                            })]
                                        }), (0, yt.jsxs)("h5", {
                                            className: "ms-1",
                                            children: ["Name : ", (0, yt.jsx)("span", {
                                                className: "text-success",
                                                children: u(t)
                                            })]
                                        })]
                                    }), (0, yt.jsxs)("h5", {
                                        children: ["Father Name : ", (0, yt.jsx)("span", {
                                            className: "text-success",
                                            children: u(o)
                                        })]
                                    }), (0, yt.jsxs)("h5", {
                                        children: ["Course : ", (0, yt.jsx)("span", {
                                            className: "text-success",
                                            children: n
                                        })]
                                    }), (0, yt.jsxs)("h5", {
                                        children: ["Session : ", (0, yt.jsx)("span", {
                                            className: "text-success",
                                            children: u(a)
                                        })]
                                    }), (0, yt.jsxs)("h5", {
                                        children: ["City : ", (0, yt.jsx)("span", {
                                            className: "text-success",
                                            children: i
                                        })]
                                    })]
                                }), (0, yt.jsx)("hr", {}), (0, yt.jsx)("div", {
                                    className: "row my-2 ",
                                    children: (0, yt.jsx)("img", {
                                        className: " border border-1 p-2 rounded-2",
                                        src: l,
                                        alt: "studentimg",
                                        style: {
                                            width: "10rem"
                                        }
                                    })
                                }), (0, yt.jsx)("hr", {}), (0, yt.jsx)("hr", {}), (0, yt.jsx)("audio", {
                                    className: "mb-3",
                                    style: {
                                        width: "20rem"
                                    },
                                    ref: f,
                                    src: "/image/thankyou.wav",
                                    controls: !0,
                                    preload: "auto"
                                }), (0, yt.jsx)("hr", {})]
                            })]
                        })
                    })
                })
            },
            Ct = r.createContext({}),
            Nt = !0;

        function jt(e) {
            let {
                baseColor: t,
                highlightColor: n,
                width: r,
                height: a,
                borderRadius: o,
                circle: l,
                direction: i,
                duration: s,
                enableAnimation: u = Nt
            } = e;
            const c = {};
            return "rtl" === i && (c["--animation-direction"] = "reverse"), "number" === typeof s && (c["--animation-duration"] = "".concat(s, "s")), u || (c["--pseudo-element-display"] = "none"), "string" !== typeof r && "number" !== typeof r || (c.width = r), "string" !== typeof a && "number" !== typeof a || (c.height = a), "string" !== typeof o && "number" !== typeof o || (c.borderRadius = o), l && (c.borderRadius = "50%"), "undefined" !== typeof t && (c["--base-color"] = t), "undefined" !== typeof n && (c["--highlight-color"] = n), c
        }

        function _t(e) {
            let {
                count: t = 1,
                wrapper: n,
                className: a,
                containerClassName: o,
                containerTestId: l,
                circle: i = !1,
                style: s,
                ...u
            } = e;
            var c, d, f;
            const p = r.useContext(Ct),
                h = { ...u
                };
            for (const [r, x] of Object.entries(u)) "undefined" === typeof x && delete h[r];
            const m = { ...p,
                    ...h,
                    circle: i
                },
                g = { ...s,
                    ...jt(m)
                };
            let y = "react-loading-skeleton";
            a && (y += " ".concat(a));
            const v = null !== (c = m.inline) && void 0 !== c && c,
                b = [],
                w = Math.ceil(t);
            for (let x = 0; x < w; x++) {
                let e = g;
                if (w > t && x === w - 1) {
                    const n = null !== (d = e.width) && void 0 !== d ? d : "100%",
                        r = t % 1,
                        a = "number" === typeof n ? n * r : "calc(".concat(n, " * ").concat(r, ")");
                    e = { ...e,
                        width: a
                    }
                }
                const n = r.createElement("span", {
                    className: y,
                    style: e,
                    key: x
                }, "\u200c");
                v ? b.push(n) : b.push(r.createElement(r.Fragment, {
                    key: x
                }, n, r.createElement("br", null)))
            }
            return r.createElement("span", {
                className: o,
                "data-testid": l,
                "aria-live": "polite",
                "aria-busy": null !== (f = m.enableAnimation) && void 0 !== f ? f : Nt
            }, n ? b.map(((e, t) => r.createElement(n, {
                key: t
            }, e))) : b)
        }

        function Tt(e) {
            let {
                children: t,
                ...n
            } = e;
            return r.createElement(Ct.Provider, {
                value: n
            }, t)
        }
        const Pt = () => (0, yt.jsx)(Tt, {
                baseColor: "#e3f2fd",
                highlightColor: "#e9edc9",
                borderRadius: 20,
                children: (0, yt.jsx)("div", {
                    children: (0, yt.jsx)("div", {
                        className: "container",
                        children: (0, yt.jsx)(_t, {
                            height: 400
                        })
                    })
                })
            }),
            Ot = () => {
                const [e, t] = (0, r.useState)(), [n, a] = (0, r.useState)(!1), [o, l] = (0, r.useState)({
                    cardId: ""
                });
                return (0, yt.jsx)("div", {
                    children: (0, yt.jsxs)("div", {
                        className: "container my-2 ",
                        children: [(0, yt.jsx)("div", {
                            className: "d-flex justify-content-center  ",
                            children: (0, yt.jsx)("h1", {
                                className: "text-center  text-light fw-bold rounded-2 py-3 px-2  w-100  fs-4 fs-md-5 fs-lg-3 bg-orange",
                                children: "Online Attendance Portal - ITCEW"
                            })
                        }), (0, yt.jsx)("form", {
                            onSubmit: async e => {
                                if (a(!0), e.preventDefault(), o.cardId) try {
                                    const e = "https://itclg-api.onrender.com",
                                        n = await fetch("".concat(e, "/api/getstudent"), {
                                            method: "POST",
                                            headers: {
                                                "Content-Type": "application/json"
                                            },
                                            body: JSON.stringify(o)
                                        }),
                                        r = await n.json();
                                    n.ok ? (l({
                                        cardId: ""
                                    }), a(!1), t(r)) : (a(!1), t(""), st.error(r.message))
                                } catch (n) {
                                    console.log(n), st.error("Internal Server Error")
                                } else st.error("Fill Input Field Properly"), a(!1), t("")
                            },
                            children: (0, yt.jsx)("div", {
                                className: "row my-4 w-75 mx-auto",
                                children: (0, yt.jsxs)("div", {
                                    className: "col d-flex ",
                                    children: [(0, yt.jsx)("input", {
                                        className: "form-control",
                                        type: "text",
                                        placeholder: "Scan your ID Card",
                                        name: "cardId",
                                        onChange: e => {
                                            const {
                                                name: t,
                                                value: n
                                            } = e.target;
                                            l({ ...o,
                                                [t]: n
                                            })
                                        },
                                        value: o.cardId
                                    }), (0, yt.jsx)("button", {
                                        className: "btn btn-primary bg-blue ms-1",
                                        type: "submit",
                                        children: "Submit"
                                    })]
                                })
                            })
                        }), n ? (0, yt.jsx)(Pt, {}) : (0, yt.jsx)(yt.Fragment, {
                            children: e && (0, yt.jsx)(Et, {
                                data: e
                            })
                        })]
                    })
                })
            },
            Rt = () => (0, yt.jsx)("div", {
                children: (0, yt.jsxs)("footer", {
                    className: "d-flex flex-wrap justify-content-evenly align-items-center py-3 border-top position-fixed w-100 bottom-0",
                    style: {
                        background: "#7EB6E8"
                    },
                    children: [(0, yt.jsx)("div", {
                        className: "col-md-4 d-flex align-items-center",
                        children: (0, yt.jsxs)("p", {
                            className: "text-dark p-0 m-0 fs-6",
                            children: ["Made with \u2665 by Manan | Powered by ", (0, yt.jsx)("span", {
                                children: (0, yt.jsx)("strong", {
                                    children: (0, yt.jsx)(Oe, {
                                        to: "https://techcanva.in",
                                        target: "_blank",
                                        children: "TechCanva"
                                    })
                                })
                            }), " "]
                        })
                    }), (0, yt.jsxs)("ul", {
                        className: "nav col-md-4 justify-content-end list-unstyled d-flex text-dark",
                        children: [(0, yt.jsx)("li", {
                            className: "ms-3",
                            children: (0, yt.jsx)(Pe, {
                                to: "https://techcanva.in",
                                target: "_blank",
                                children: (0, yt.jsx)("img", {
                                    src: "/image/techcanva.png",
                                    alt: "logotechcanva",
                                    className: "icon-img"
                                })
                            })
                        }), (0, yt.jsx)("li", {
                            className: "ms-2",
                            children: (0, yt.jsx)(Pe, {
                                to: "https://wa.me/qr/CE2NQOCPJFHBM1",
                                target: "_blank",
                                children: (0, yt.jsx)("i", {
                                    className: "fa-brands fa-whatsapp fa-xl",
                                    style: {
                                        color: "#000"
                                    }
                                })
                            })
                        }), (0, yt.jsx)("li", {
                            className: "ms-3",
                            children: (0, yt.jsx)(Pe, {
                                to: "https://www.instagram.com/manankumar_06/?r=nametag",
                                target: "_blank",
                                children: (0, yt.jsx)("i", {
                                    className: "fa-brands fa-instagram fa-xl",
                                    style: {
                                        color: "#000"
                                    }
                                })
                            })
                        }), (0, yt.jsx)("li", {
                            className: "ms-3",
                            children: (0, yt.jsx)(Pe, {
                                to: "https://github.com/Manankumar6/",
                                target: "_blank",
                                children: (0, yt.jsx)("i", {
                                    className: "fa-brands fa-github fa-xl",
                                    style: {
                                        color: "#000"
                                    }
                                })
                            })
                        })]
                    })]
                })
            });
        var Lt = {
                color: void 0,
                size: void 0,
                className: void 0,
                style: void 0,
                attr: void 0
            },
            zt = r.createContext && r.createContext(Lt),
            Dt = ["attr", "size", "title"];

        function At(e, t) {
            if (null == e) return {};
            var n, r, a = function(e, t) {
                if (null == e) return {};
                var n = {};
                for (var r in e)
                    if (Object.prototype.hasOwnProperty.call(e, r)) {
                        if (t.indexOf(r) >= 0) continue;
                        n[r] = e[r]
                    }
                return n
            }(e, t);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                for (r = 0; r < o.length; r++) n = o[r], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (a[n] = e[n])
            }
            return a
        }

        function It() {
            return It = Object.assign ? Object.assign.bind() : function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                }
                return e
            }, It.apply(this, arguments)
        }

        function Ft(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter((function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), n.push.apply(n, r)
            }
            return n
        }

        function Ut(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? Ft(Object(n), !0).forEach((function(t) {
                    Mt(e, t, n[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Ft(Object(n)).forEach((function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                }))
            }
            return e
        }

        function Mt(e, t, n) {
            return t = function(e) {
                var t = function(e, t) {
                    if ("object" != typeof e || !e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 !== n) {
                        var r = n.call(e, t || "default");
                        if ("object" != typeof r) return r;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === t ? String : Number)(e)
                }(e, "string");
                return "symbol" == typeof t ? t : t + ""
            }(t), t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e
        }

        function Bt(e) {
            return e && e.map(((e, t) => r.createElement(e.tag, Ut({
                key: t
            }, e.attr), Bt(e.child))))
        }

        function Ht(e) {
            return t => r.createElement(Wt, It({
                attr: Ut({}, e.attr)
            }, t), Bt(e.child))
        }

        function Wt(e) {
            var t = t => {
                var n, {
                        attr: a,
                        size: o,
                        title: l
                    } = e,
                    i = At(e, Dt),
                    s = o || t.size || "1em";
                return t.className && (n = t.className), e.className && (n = (n ? n + " " : "") + e.className), r.createElement("svg", It({
                    stroke: "currentColor",
                    fill: "currentColor",
                    strokeWidth: "0"
                }, t.attr, a, i, {
                    className: n,
                    style: Ut(Ut({
                        color: e.color || t.color
                    }, t.style), e.style),
                    height: s,
                    width: s,
                    xmlns: "http://www.w3.org/2000/svg"
                }), l && r.createElement("title", null, l), e.children)
            };
            return void 0 !== zt ? r.createElement(zt.Consumer, null, (e => t(e))) : t(Lt)
        }

        function Vt(e) {
            return Ht({
                tag: "svg",
                attr: {
                    viewBox: "0 0 1024 1024"
                },
                child: [{
                    tag: "path",
                    attr: {
                        d: "M942.2 486.2Q889.47 375.11 816.7 305l-50.88 50.88C807.31 395.53 843.45 447.4 874.7 512 791.5 684.2 673.4 766 512 766q-72.67 0-133.87-22.38L323 798.75Q408 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 0 0 0-51.5zm-63.57-320.64L836 122.88a8 8 0 0 0-11.32 0L715.31 232.2Q624.86 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 0 0 0 51.5q56.69 119.4 136.5 191.41L112.48 835a8 8 0 0 0 0 11.31L155.17 889a8 8 0 0 0 11.31 0l712.15-712.12a8 8 0 0 0 0-11.32zM149.3 512C232.6 339.8 350.7 258 512 258c54.54 0 104.13 9.36 149.12 28.39l-70.3 70.3a176 176 0 0 0-238.13 238.13l-83.42 83.42C223.1 637.49 183.3 582.28 149.3 512zm246.7 0a112.11 112.11 0 0 1 146.2-106.69L401.31 546.2A112 112 0 0 1 396 512z"
                    },
                    child: []
                }, {
                    tag: "path",
                    attr: {
                        d: "M508 624c-3.46 0-6.87-.16-10.25-.47l-52.82 52.82a176.09 176.09 0 0 0 227.42-227.42l-52.82 52.82c.31 3.38.47 6.79.47 10.25a111.94 111.94 0 0 1-112 112z"
                    },
                    child: []
                }]
            })(e)
        }

        function $t(e) {
            return Ht({
                tag: "svg",
                attr: {
                    viewBox: "0 0 1024 1024"
                },
                child: [{
                    tag: "path",
                    attr: {
                        d: "M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 0 0 0 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z"
                    },
                    child: []
                }]
            })(e)
        }
        const qt = () => {
            const {
                Signup: e,
                handleInput: t,
                data: n,
                isAuth: a
            } = xt(), [o, l] = (0, r.useState)(!1), i = ee();
            return a && i("/"), (0, yt.jsx)("div", {
                className: "container d-flex justify-content-center align-items-center my-5 vh-100 pb-5",
                children: (0, yt.jsxs)("div", {
                    className: "card shadow-lg p-4 ",
                    style: {
                        maxWidth: "400px",
                        width: "100%"
                    },
                    children: [(0, yt.jsx)("img", {
                        src: "/image/logo.jpeg",
                        alt: "logo",
                        className: "rounded-circle mx-auto shadow-sm img-fluid",
                        style: {
                            width: "200px",
                            height: "200px",
                            objectFit: "cover"
                        }
                    }), (0, yt.jsx)("h2", {
                        className: "mb-4 text-center",
                        children: "Sign-up To Itcew"
                    }), (0, yt.jsxs)("form", {
                        onSubmit: e,
                        children: [(0, yt.jsxs)("div", {
                            className: "mb-3",
                            children: [(0, yt.jsx)("label", {
                                htmlFor: "username",
                                className: "form-label",
                                children: "Username"
                            }), (0, yt.jsx)("input", {
                                type: "text",
                                className: "form-control",
                                id: "username",
                                name: "username",
                                value: n.username,
                                onChange: t,
                                required: !0
                            })]
                        }), (0, yt.jsxs)("div", {
                            className: "mb-3",
                            children: [(0, yt.jsx)("label", {
                                htmlFor: "email",
                                className: "form-label",
                                children: "Email address"
                            }), (0, yt.jsx)("input", {
                                type: "email",
                                className: "form-control",
                                id: "email",
                                name: "email",
                                value: n.email,
                                onChange: t,
                                required: !0
                            })]
                        }), (0, yt.jsxs)("div", {
                            className: "mb-3",
                            children: [(0, yt.jsx)("label", {
                                htmlFor: "password",
                                className: "form-label",
                                children: "Password"
                            }), (0, yt.jsxs)("div", {
                                className: "input-group",
                                children: [(0, yt.jsx)("input", {
                                    type: o ? "text" : "password",
                                    className: "form-control",
                                    id: "password",
                                    name: "password",
                                    value: n.password,
                                    onChange: t,
                                    required: !0
                                }), (0, yt.jsx)("button", {
                                    type: "button",
                                    className: "btn btn-primary",
                                    onClick: () => l(!o),
                                    children: o ? (0, yt.jsx)(Vt, {}) : (0, yt.jsx)($t, {})
                                })]
                            })]
                        }), (0, yt.jsx)("button", {
                            type: "submit",
                            className: "btn btn-primary w-100",
                            children: "Sign Up"
                        })]
                    }), (0, yt.jsx)("hr", {
                        className: "my-4"
                    }), (0, yt.jsx)("p", {
                        className: "text-center",
                        children: "Or"
                    }), (0, yt.jsxs)("p", {
                        className: "text-center mt-3",
                        children: ["Already have an account?", (0, yt.jsx)(Pe, {
                            to: "/login",
                            className: "ms-1 text-primary text-decoration-none",
                            children: "Login"
                        })]
                    })]
                })
            })
        };

        function Qt(e) {
            return Ht({
                tag: "svg",
                attr: {
                    viewBox: "0 0 640 512"
                },
                child: [{
                    tag: "path",
                    attr: {
                        d: "M634 471L36 3.51A16 16 0 0 0 13.51 6l-10 12.49A16 16 0 0 0 6 41l598 467.49a16 16 0 0 0 22.49-2.49l10-12.49A16 16 0 0 0 634 471zM296.79 146.47l134.79 105.38C429.36 191.91 380.48 144 320 144a112.26 112.26 0 0 0-23.21 2.47zm46.42 219.07L208.42 260.16C210.65 320.09 259.53 368 320 368a113 113 0 0 0 23.21-2.46zM320 112c98.65 0 189.09 55 237.93 144a285.53 285.53 0 0 1-44 60.2l37.74 29.5a333.7 333.7 0 0 0 52.9-75.11 32.35 32.35 0 0 0 0-29.19C550.29 135.59 442.93 64 320 64c-36.7 0-71.71 7-104.63 18.81l46.41 36.29c18.94-4.3 38.34-7.1 58.22-7.1zm0 288c-98.65 0-189.08-55-237.93-144a285.47 285.47 0 0 1 44.05-60.19l-37.74-29.5a333.6 333.6 0 0 0-52.89 75.1 32.35 32.35 0 0 0 0 29.19C89.72 376.41 197.08 448 320 448c36.7 0 71.71-7.05 104.63-18.81l-46.41-36.28C359.28 397.2 339.89 400 320 400z"
                    },
                    child: []
                }]
            })(e)
        }

        function Kt(e) {
            return Ht({
                tag: "svg",
                attr: {
                    viewBox: "0 0 576 512"
                },
                child: [{
                    tag: "path",
                    attr: {
                        d: "M288 144a110.94 110.94 0 0 0-31.24 5 55.4 55.4 0 0 1 7.24 27 56 56 0 0 1-56 56 55.4 55.4 0 0 1-27-7.24A111.71 111.71 0 1 0 288 144zm284.52 97.4C518.29 135.59 410.93 64 288 64S57.68 135.64 3.48 241.41a32.35 32.35 0 0 0 0 29.19C57.71 376.41 165.07 448 288 448s230.32-71.64 284.52-177.41a32.35 32.35 0 0 0 0-29.19zM288 400c-98.65 0-189.09-55-237.93-144C98.91 167 189.34 112 288 112s189.09 55 237.93 144C477.1 345 386.66 400 288 400z"
                    },
                    child: []
                }]
            })(e)
        }
        const Gt = () => {
                const {
                    Login: e,
                    handleInput: t,
                    data: n,
                    isAuth: a
                } = xt(), o = ee(), [l, i] = (0, r.useState)(!1);
                return (0, r.useEffect)((() => {
                    a && o("/")
                }), [a, o]), (0, yt.jsx)("div", {
                    className: "container d-flex justify-content-center align-items-center vh-100 pb-5",
                    children: (0, yt.jsxs)("div", {
                        className: "card shadow-lg p-4",
                        style: {
                            maxWidth: "400px",
                            width: "100%"
                        },
                        children: [(0, yt.jsx)("img", {
                            src: "/image/logo.jpeg",
                            alt: "logo",
                            className: "rounded-circle mx-auto shadow-sm img-fluid",
                            style: {
                                width: "200px",
                                height: "200px",
                                objectFit: "cover"
                            }
                        }), (0, yt.jsx)("h2", {
                            className: "mb-4 text-center",
                            children: "Login To Itcew"
                        }), (0, yt.jsxs)("form", {
                            onSubmit: e,
                            children: [(0, yt.jsxs)("div", {
                                className: "mb-3",
                                children: [(0, yt.jsx)("label", {
                                    htmlFor: "email",
                                    className: "form-label",
                                    children: "Email address"
                                }), (0, yt.jsx)("input", {
                                    type: "email",
                                    className: "form-control",
                                    id: "email",
                                    name: "email",
                                    value: n.email,
                                    onChange: t,
                                    required: !0
                                })]
                            }), (0, yt.jsxs)("div", {
                                className: "mb-3",
                                children: [(0, yt.jsx)("label", {
                                    htmlFor: "password",
                                    className: "form-label",
                                    children: "Password"
                                }), (0, yt.jsxs)("div", {
                                    className: "input-group",
                                    children: [(0, yt.jsx)("input", {
                                        type: l ? "text" : "password",
                                        className: "form-control",
                                        id: "password",
                                        name: "password",
                                        value: n.password,
                                        onChange: t,
                                        required: !0
                                    }), (0, yt.jsx)("button", {
                                        type: "button",
                                        className: "btn btn-primary bg-blue",
                                        onClick: () => i(!l),
                                        children: l ? (0, yt.jsx)(Qt, {}) : (0, yt.jsx)(Kt, {})
                                    })]
                                })]
                            }), (0, yt.jsx)("button", {
                                type: "submit",
                                className: "btn btn-primary w-100 bg-blue",
                                children: "Login"
                            })]
                        }), (0, yt.jsx)("hr", {
                            className: "my-4"
                        }), (0, yt.jsx)("p", {
                            className: "text-center",
                            children: "Or"
                        }), (0, yt.jsxs)("p", {
                            className: "text-center mt-3",
                            children: ["Don't have an account?", (0, yt.jsx)(Pe, {
                                to: "/signup",
                                className: "ms-1 text-primary text-decoration-none",
                                children: "Sign up"
                            })]
                        })]
                    })
                })
            },
            Jt = () => {
                const {
                    isAuth: e,
                    isLoading: t
                } = xt();
                return t ? (0, yt.jsx)("h1", {
                    children: "Loading..."
                }) : e ? (0, yt.jsx)(ge, {}) : (0, yt.jsx)(me, {
                    to: "/login"
                })
            },
            Xt = () => {
                const {
                    user: e
                } = xt(), [t, n] = (0, r.useState)(!1);
                return (0, r.useEffect)((() => {
                    e && "admin" !== e.role && (async () => {
                        try {
                            const e = await fetch("".concat("https://itclg-api.onrender.com", "/api/initial-admin"), {
                                method: "POST",
                                credentials: "include"
                            });
                            if (!e.ok) throw new Error("Failed to promote user to admin");
                            const t = await e.json();
                            console.log(t), n(!0)
                        } catch (e) {
                            console.error("Error promoting user to admin:", e), n(!1)
                        }
                    })()
                }), []), (0, yt.jsx)("div", {
                    className: "container",
                    children: (0, yt.jsx)("div", {
                        className: "d-flex justify-content-center text-center my-2",
                        children: t ? (0, yt.jsxs)("div", {
                            className: "card p-5 bg-success rounded-4 text-light w-50",
                            children: [(0, yt.jsx)("h1", {
                                children: "Congratulations!"
                            }), (0, yt.jsx)("h4", {
                                children: "You have successfully promoted the user to admin."
                            })]
                        }) : (0, yt.jsxs)("div", {
                            className: "card p-5 text-danger rounded-4 text-light w-50",
                            style: {
                                background: "#ffc2d1"
                            },
                            children: [(0, yt.jsx)("h1", {
                                children: "Oops!"
                            }), (0, yt.jsx)("h4", {
                                children: "Admin already exists."
                            })]
                        })
                    })
                })
            },
            Yt = () => (0, yt.jsxs)("div", {
                className: "container",
                children: [(0, yt.jsx)("h1", {
                    className: "text-center",
                    children: "About ITC Education World- Course"
                }), (0, yt.jsx)("h5", {
                    children: "ADIT (Advance Diploma in Information Technology)"
                }), (0, yt.jsx)("p", {
                    className: "text-muted",
                    children: "Advance Diploma In Information Technology is a Diploma in Automation, Financial Accounting, Graphics, PC Fundamental, Office Automation, Desktop Publishing, Programming, PC Troubleshooting, and Web Designing."
                }), (0, yt.jsxs)("div", {
                    className: "d-flex justify-content-between w-25",
                    children: [(0, yt.jsx)("p", {
                        children: " Duration"
                    }), (0, yt.jsx)("p", {
                        children: "   15 months"
                    })]
                }), (0, yt.jsx)("h5", {
                    className: "text-danger",
                    children: "About this course"
                }), (0, yt.jsx)("p", {
                    children: "Advance Diploma In Information Technology is a Diploma in Automation, Financial Accounting, Graphics, PC Fundamental, Office Automation, Desktop Publishing, Programming, PC Troubleshooting, and Web Designing. It is a diploma course divided into five main semesters. 1st part covers your Computerized Office Documentation, 2nd part covers Financial Accounting Program to learn how to maintain Accounting of Various Firms and LTD. CO, 3rd and 4th part covers developing Graphics and layouts for product illustrations, company logos, and websites. Graphics designing can use image-based designs involving photos, illustrations, logos and symbols, type-based designs, or a combination of both techniques. This course also provides you knowledge of Hardware where you can learn how to deal with your computer hardware problems."
                }), (0, yt.jsx)("h5", {
                    className: "text-danger",
                    children: "More Instructions"
                }), (0, yt.jsxs)("ul", {
                    children: [(0, yt.jsx)("li", {
                        children: "Advance Diploma In Information Technology is a 15 months Diploma."
                    }), (0, yt.jsx)("li", {
                        children: "Advance Diploma In Information Technology gives you job opening in many fields like data entry operator, sales executive, office administrator, graphic designer, photo editor, newspaper add designer, and accountant. After completion of the diploma, one can approach special career-oriented fields in computers."
                    })]
                })]
            });

        function Zt(e, t) {
            return function() {
                return e.apply(t, arguments)
            }
        }
        const {
            toString: en
        } = Object.prototype, {
            getPrototypeOf: tn
        } = Object, nn = (rn = Object.create(null), e => {
            const t = en.call(e);
            return rn[t] || (rn[t] = t.slice(8, -1).toLowerCase())
        });
        var rn;
        const an = e => (e = e.toLowerCase(), t => nn(t) === e),
            on = e => t => typeof t === e,
            {
                isArray: ln
            } = Array,
            sn = on("undefined");
        const un = an("ArrayBuffer");
        const cn = on("string"),
            dn = on("function"),
            fn = on("number"),
            pn = e => null !== e && "object" === typeof e,
            hn = e => {
                if ("object" !== nn(e)) return !1;
                const t = tn(e);
                return (null === t || t === Object.prototype || null === Object.getPrototypeOf(t)) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
            },
            mn = an("Date"),
            gn = an("File"),
            yn = an("Blob"),
            vn = an("FileList"),
            bn = an("URLSearchParams"),
            [wn, xn, Sn, kn] = ["ReadableStream", "Request", "Response", "Headers"].map(an);

        function En(e, t) {
            let n, r, {
                allOwnKeys: a = !1
            } = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            if (null !== e && "undefined" !== typeof e)
                if ("object" !== typeof e && (e = [e]), ln(e))
                    for (n = 0, r = e.length; n < r; n++) t.call(null, e[n], n, e);
                else {
                    const r = a ? Object.getOwnPropertyNames(e) : Object.keys(e),
                        o = r.length;
                    let l;
                    for (n = 0; n < o; n++) l = r[n], t.call(null, e[l], l, e)
                }
        }

        function Cn(e, t) {
            t = t.toLowerCase();
            const n = Object.keys(e);
            let r, a = n.length;
            for (; a-- > 0;)
                if (r = n[a], t === r.toLowerCase()) return r;
            return null
        }
        const Nn = "undefined" !== typeof globalThis ? globalThis : "undefined" !== typeof self ? self : "undefined" !== typeof window ? window : global,
            jn = e => !sn(e) && e !== Nn;
        const _n = (Tn = "undefined" !== typeof Uint8Array && tn(Uint8Array), e => Tn && e instanceof Tn);
        var Tn;
        const Pn = an("HTMLFormElement"),
            On = (e => {
                let {
                    hasOwnProperty: t
                } = e;
                return (e, n) => t.call(e, n)
            })(Object.prototype),
            Rn = an("RegExp"),
            Ln = (e, t) => {
                const n = Object.getOwnPropertyDescriptors(e),
                    r = {};
                En(n, ((n, a) => {
                    let o;
                    !1 !== (o = t(n, a, e)) && (r[a] = o || n)
                })), Object.defineProperties(e, r)
            },
            zn = "abcdefghijklmnopqrstuvwxyz",
            Dn = "0123456789",
            An = {
                DIGIT: Dn,
                ALPHA: zn,
                ALPHA_DIGIT: zn + zn.toUpperCase() + Dn
            };
        const In = an("AsyncFunction"),
            Fn = {
                isArray: ln,
                isArrayBuffer: un,
                isBuffer: function(e) {
                    return null !== e && !sn(e) && null !== e.constructor && !sn(e.constructor) && dn(e.constructor.isBuffer) && e.constructor.isBuffer(e)
                },
                isFormData: e => {
                    let t;
                    return e && ("function" === typeof FormData && e instanceof FormData || dn(e.append) && ("formdata" === (t = nn(e)) || "object" === t && dn(e.toString) && "[object FormData]" === e.toString()))
                },
                isArrayBufferView: function(e) {
                    let t;
                    return t = "undefined" !== typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && un(e.buffer), t
                },
                isString: cn,
                isNumber: fn,
                isBoolean: e => !0 === e || !1 === e,
                isObject: pn,
                isPlainObject: hn,
                isReadableStream: wn,
                isRequest: xn,
                isResponse: Sn,
                isHeaders: kn,
                isUndefined: sn,
                isDate: mn,
                isFile: gn,
                isBlob: yn,
                isRegExp: Rn,
                isFunction: dn,
                isStream: e => pn(e) && dn(e.pipe),
                isURLSearchParams: bn,
                isTypedArray: _n,
                isFileList: vn,
                forEach: En,
                merge: function e() {
                    const {
                        caseless: t
                    } = jn(this) && this || {}, n = {}, r = (r, a) => {
                        const o = t && Cn(n, a) || a;
                        hn(n[o]) && hn(r) ? n[o] = e(n[o], r) : hn(r) ? n[o] = e({}, r) : ln(r) ? n[o] = r.slice() : n[o] = r
                    };
                    for (let a = 0, o = arguments.length; a < o; a++) arguments[a] && En(arguments[a], r);
                    return n
                },
                extend: function(e, t, n) {
                    let {
                        allOwnKeys: r
                    } = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                    return En(t, ((t, r) => {
                        n && dn(t) ? e[r] = Zt(t, n) : e[r] = t
                    }), {
                        allOwnKeys: r
                    }), e
                },
                trim: e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""),
                stripBOM: e => (65279 === e.charCodeAt(0) && (e = e.slice(1)), e),
                inherits: (e, t, n, r) => {
                    e.prototype = Object.create(t.prototype, r), e.prototype.constructor = e, Object.defineProperty(e, "super", {
                        value: t.prototype
                    }), n && Object.assign(e.prototype, n)
                },
                toFlatObject: (e, t, n, r) => {
                    let a, o, l;
                    const i = {};
                    if (t = t || {}, null == e) return t;
                    do {
                        for (a = Object.getOwnPropertyNames(e), o = a.length; o-- > 0;) l = a[o], r && !r(l, e, t) || i[l] || (t[l] = e[l], i[l] = !0);
                        e = !1 !== n && tn(e)
                    } while (e && (!n || n(e, t)) && e !== Object.prototype);
                    return t
                },
                kindOf: nn,
                kindOfTest: an,
                endsWith: (e, t, n) => {
                    e = String(e), (void 0 === n || n > e.length) && (n = e.length), n -= t.length;
                    const r = e.indexOf(t, n);
                    return -1 !== r && r === n
                },
                toArray: e => {
                    if (!e) return null;
                    if (ln(e)) return e;
                    let t = e.length;
                    if (!fn(t)) return null;
                    const n = new Array(t);
                    for (; t-- > 0;) n[t] = e[t];
                    return n
                },
                forEachEntry: (e, t) => {
                    const n = (e && e[Symbol.iterator]).call(e);
                    let r;
                    for (;
                        (r = n.next()) && !r.done;) {
                        const n = r.value;
                        t.call(e, n[0], n[1])
                    }
                },
                matchAll: (e, t) => {
                    let n;
                    const r = [];
                    for (; null !== (n = e.exec(t));) r.push(n);
                    return r
                },
                isHTMLForm: Pn,
                hasOwnProperty: On,
                hasOwnProp: On,
                reduceDescriptors: Ln,
                freezeMethods: e => {
                    Ln(e, ((t, n) => {
                        if (dn(e) && -1 !== ["arguments", "caller", "callee"].indexOf(n)) return !1;
                        const r = e[n];
                        dn(r) && (t.enumerable = !1, "writable" in t ? t.writable = !1 : t.set || (t.set = () => {
                            throw Error("Can not rewrite read-only method '" + n + "'")
                        }))
                    }))
                },
                toObjectSet: (e, t) => {
                    const n = {},
                        r = e => {
                            e.forEach((e => {
                                n[e] = !0
                            }))
                        };
                    return ln(e) ? r(e) : r(String(e).split(t)), n
                },
                toCamelCase: e => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, (function(e, t, n) {
                    return t.toUpperCase() + n
                })),
                noop: () => {},
                toFiniteNumber: (e, t) => null != e && Number.isFinite(e = +e) ? e : t,
                findKey: Cn,
                global: Nn,
                isContextDefined: jn,
                ALPHABET: An,
                generateString: function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 16,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : An.ALPHA_DIGIT,
                        n = "";
                    const {
                        length: r
                    } = t;
                    for (; e--;) n += t[Math.random() * r | 0];
                    return n
                },
                isSpecCompliantForm: function(e) {
                    return !!(e && dn(e.append) && "FormData" === e[Symbol.toStringTag] && e[Symbol.iterator])
                },
                toJSONObject: e => {
                    const t = new Array(10),
                        n = (e, r) => {
                            if (pn(e)) {
                                if (t.indexOf(e) >= 0) return;
                                if (!("toJSON" in e)) {
                                    t[r] = e;
                                    const a = ln(e) ? [] : {};
                                    return En(e, ((e, t) => {
                                        const o = n(e, r + 1);
                                        !sn(o) && (a[t] = o)
                                    })), t[r] = void 0, a
                                }
                            }
                            return e
                        };
                    return n(e, 0)
                },
                isAsyncFn: In,
                isThenable: e => e && (pn(e) || dn(e)) && dn(e.then) && dn(e.catch)
            };

        function Un(e, t, n, r, a) {
            Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = (new Error).stack, this.message = e, this.name = "AxiosError", t && (this.code = t), n && (this.config = n), r && (this.request = r), a && (this.response = a)
        }
        Fn.inherits(Un, Error, {
            toJSON: function() {
                return {
                    message: this.message,
                    name: this.name,
                    description: this.description,
                    number: this.number,
                    fileName: this.fileName,
                    lineNumber: this.lineNumber,
                    columnNumber: this.columnNumber,
                    stack: this.stack,
                    config: Fn.toJSONObject(this.config),
                    code: this.code,
                    status: this.response && this.response.status ? this.response.status : null
                }
            }
        });
        const Mn = Un.prototype,
            Bn = {};
        ["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach((e => {
            Bn[e] = {
                value: e
            }
        })), Object.defineProperties(Un, Bn), Object.defineProperty(Mn, "isAxiosError", {
            value: !0
        }), Un.from = (e, t, n, r, a, o) => {
            const l = Object.create(Mn);
            return Fn.toFlatObject(e, l, (function(e) {
                return e !== Error.prototype
            }), (e => "isAxiosError" !== e)), Un.call(l, e.message, t, n, r, a), l.cause = e, l.name = e.name, o && Object.assign(l, o), l
        };
        const Hn = Un;

        function Wn(e) {
            return Fn.isPlainObject(e) || Fn.isArray(e)
        }

        function Vn(e) {
            return Fn.endsWith(e, "[]") ? e.slice(0, -2) : e
        }

        function $n(e, t, n) {
            return e ? e.concat(t).map((function(e, t) {
                return e = Vn(e), !n && t ? "[" + e + "]" : e
            })).join(n ? "." : "") : t
        }
        const qn = Fn.toFlatObject(Fn, {}, null, (function(e) {
            return /^is[A-Z]/.test(e)
        }));
        const Qn = function(e, t, n) {
            if (!Fn.isObject(e)) throw new TypeError("target must be an object");
            t = t || new FormData;
            const r = (n = Fn.toFlatObject(n, {
                    metaTokens: !0,
                    dots: !1,
                    indexes: !1
                }, !1, (function(e, t) {
                    return !Fn.isUndefined(t[e])
                }))).metaTokens,
                a = n.visitor || u,
                o = n.dots,
                l = n.indexes,
                i = (n.Blob || "undefined" !== typeof Blob && Blob) && Fn.isSpecCompliantForm(t);
            if (!Fn.isFunction(a)) throw new TypeError("visitor must be a function");

            function s(e) {
                if (null === e) return "";
                if (Fn.isDate(e)) return e.toISOString();
                if (!i && Fn.isBlob(e)) throw new Hn("Blob is not supported. Use a Buffer instead.");
                return Fn.isArrayBuffer(e) || Fn.isTypedArray(e) ? i && "function" === typeof Blob ? new Blob([e]) : Buffer.from(e) : e
            }

            function u(e, n, a) {
                let i = e;
                if (e && !a && "object" === typeof e)
                    if (Fn.endsWith(n, "{}")) n = r ? n : n.slice(0, -2), e = JSON.stringify(e);
                    else if (Fn.isArray(e) && function(e) {
                        return Fn.isArray(e) && !e.some(Wn)
                    }(e) || (Fn.isFileList(e) || Fn.endsWith(n, "[]")) && (i = Fn.toArray(e))) return n = Vn(n), i.forEach((function(e, r) {
                    !Fn.isUndefined(e) && null !== e && t.append(!0 === l ? $n([n], r, o) : null === l ? n : n + "[]", s(e))
                })), !1;
                return !!Wn(e) || (t.append($n(a, n, o), s(e)), !1)
            }
            const c = [],
                d = Object.assign(qn, {
                    defaultVisitor: u,
                    convertValue: s,
                    isVisitable: Wn
                });
            if (!Fn.isObject(e)) throw new TypeError("data must be an object");
            return function e(n, r) {
                if (!Fn.isUndefined(n)) {
                    if (-1 !== c.indexOf(n)) throw Error("Circular reference detected in " + r.join("."));
                    c.push(n), Fn.forEach(n, (function(n, o) {
                        !0 === (!(Fn.isUndefined(n) || null === n) && a.call(t, n, Fn.isString(o) ? o.trim() : o, r, d)) && e(n, r ? r.concat(o) : [o])
                    })), c.pop()
                }
            }(e), t
        };

        function Kn(e) {
            const t = {
                "!": "%21",
                "'": "%27",
                "(": "%28",
                ")": "%29",
                "~": "%7E",
                "%20": "+",
                "%00": "\0"
            };
            return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, (function(e) {
                return t[e]
            }))
        }

        function Gn(e, t) {
            this._pairs = [], e && Qn(e, this, t)
        }
        const Jn = Gn.prototype;
        Jn.append = function(e, t) {
            this._pairs.push([e, t])
        }, Jn.toString = function(e) {
            const t = e ? function(t) {
                return e.call(this, t, Kn)
            } : Kn;
            return this._pairs.map((function(e) {
                return t(e[0]) + "=" + t(e[1])
            }), "").join("&")
        };
        const Xn = Gn;

        function Yn(e) {
            return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
        }

        function Zn(e, t, n) {
            if (!t) return e;
            const r = n && n.encode || Yn,
                a = n && n.serialize;
            let o;
            if (o = a ? a(t, n) : Fn.isURLSearchParams(t) ? t.toString() : new Xn(t, n).toString(r), o) {
                const t = e.indexOf("#"); - 1 !== t && (e = e.slice(0, t)), e += (-1 === e.indexOf("?") ? "?" : "&") + o
            }
            return e
        }
        const er = class {
                constructor() {
                    this.handlers = []
                }
                use(e, t, n) {
                    return this.handlers.push({
                        fulfilled: e,
                        rejected: t,
                        synchronous: !!n && n.synchronous,
                        runWhen: n ? n.runWhen : null
                    }), this.handlers.length - 1
                }
                eject(e) {
                    this.handlers[e] && (this.handlers[e] = null)
                }
                clear() {
                    this.handlers && (this.handlers = [])
                }
                forEach(e) {
                    Fn.forEach(this.handlers, (function(t) {
                        null !== t && e(t)
                    }))
                }
            },
            tr = {
                silentJSONParsing: !0,
                forcedJSONParsing: !0,
                clarifyTimeoutError: !1
            },
            nr = {
                isBrowser: !0,
                classes: {
                    URLSearchParams: "undefined" !== typeof URLSearchParams ? URLSearchParams : Xn,
                    FormData: "undefined" !== typeof FormData ? FormData : null,
                    Blob: "undefined" !== typeof Blob ? Blob : null
                },
                protocols: ["http", "https", "file", "blob", "url", "data"]
            },
            rr = "undefined" !== typeof window && "undefined" !== typeof document,
            ar = (or = "undefined" !== typeof navigator && navigator.product, rr && ["ReactNative", "NativeScript", "NS"].indexOf(or) < 0);
        var or;
        const lr = "undefined" !== typeof WorkerGlobalScope && self instanceof WorkerGlobalScope && "function" === typeof self.importScripts,
            ir = rr && window.location.href || "http://localhost",
            sr = { ...e,
                ...nr
            };
        const ur = function(e) {
            function t(e, n, r, a) {
                let o = e[a++];
                if ("__proto__" === o) return !0;
                const l = Number.isFinite(+o),
                    i = a >= e.length;
                if (o = !o && Fn.isArray(r) ? r.length : o, i) return Fn.hasOwnProp(r, o) ? r[o] = [r[o], n] : r[o] = n, !l;
                r[o] && Fn.isObject(r[o]) || (r[o] = []);
                return t(e, n, r[o], a) && Fn.isArray(r[o]) && (r[o] = function(e) {
                    const t = {},
                        n = Object.keys(e);
                    let r;
                    const a = n.length;
                    let o;
                    for (r = 0; r < a; r++) o = n[r], t[o] = e[o];
                    return t
                }(r[o])), !l
            }
            if (Fn.isFormData(e) && Fn.isFunction(e.entries)) {
                const n = {};
                return Fn.forEachEntry(e, ((e, r) => {
                    t(function(e) {
                        return Fn.matchAll(/\w+|\[(\w*)]/g, e).map((e => "[]" === e[0] ? "" : e[1] || e[0]))
                    }(e), r, n, 0)
                })), n
            }
            return null
        };
        const cr = {
            transitional: tr,
            adapter: ["xhr", "http", "fetch"],
            transformRequest: [function(e, t) {
                const n = t.getContentType() || "",
                    r = n.indexOf("application/json") > -1,
                    a = Fn.isObject(e);
                a && Fn.isHTMLForm(e) && (e = new FormData(e));
                if (Fn.isFormData(e)) return r ? JSON.stringify(ur(e)) : e;
                if (Fn.isArrayBuffer(e) || Fn.isBuffer(e) || Fn.isStream(e) || Fn.isFile(e) || Fn.isBlob(e) || Fn.isReadableStream(e)) return e;
                if (Fn.isArrayBufferView(e)) return e.buffer;
                if (Fn.isURLSearchParams(e)) return t.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), e.toString();
                let o;
                if (a) {
                    if (n.indexOf("application/x-www-form-urlencoded") > -1) return function(e, t) {
                        return Qn(e, new sr.classes.URLSearchParams, Object.assign({
                            visitor: function(e, t, n, r) {
                                return sr.isNode && Fn.isBuffer(e) ? (this.append(t, e.toString("base64")), !1) : r.defaultVisitor.apply(this, arguments)
                            }
                        }, t))
                    }(e, this.formSerializer).toString();
                    if ((o = Fn.isFileList(e)) || n.indexOf("multipart/form-data") > -1) {
                        const t = this.env && this.env.FormData;
                        return Qn(o ? {
                            "files[]": e
                        } : e, t && new t, this.formSerializer)
                    }
                }
                return a || r ? (t.setContentType("application/json", !1), function(e, t, n) {
                    if (Fn.isString(e)) try {
                        return (t || JSON.parse)(e), Fn.trim(e)
                    } catch (ga) {
                        if ("SyntaxError" !== ga.name) throw ga
                    }
                    return (n || JSON.stringify)(e)
                }(e)) : e
            }],
            transformResponse: [function(e) {
                const t = this.transitional || cr.transitional,
                    n = t && t.forcedJSONParsing,
                    r = "json" === this.responseType;
                if (Fn.isResponse(e) || Fn.isReadableStream(e)) return e;
                if (e && Fn.isString(e) && (n && !this.responseType || r)) {
                    const n = !(t && t.silentJSONParsing) && r;
                    try {
                        return JSON.parse(e)
                    } catch (ga) {
                        if (n) {
                            if ("SyntaxError" === ga.name) throw Hn.from(ga, Hn.ERR_BAD_RESPONSE, this, null, this.response);
                            throw ga
                        }
                    }
                }
                return e
            }],
            timeout: 0,
            xsrfCookieName: "XSRF-TOKEN",
            xsrfHeaderName: "X-XSRF-TOKEN",
            maxContentLength: -1,
            maxBodyLength: -1,
            env: {
                FormData: sr.classes.FormData,
                Blob: sr.classes.Blob
            },
            validateStatus: function(e) {
                return e >= 200 && e < 300
            },
            headers: {
                common: {
                    Accept: "application/json, text/plain, */*",
                    "Content-Type": void 0
                }
            }
        };
        Fn.forEach(["delete", "get", "head", "post", "put", "patch"], (e => {
            cr.headers[e] = {}
        }));
        const dr = cr,
            fr = Fn.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
            pr = Symbol("internals");

        function hr(e) {
            return e && String(e).trim().toLowerCase()
        }

        function mr(e) {
            return !1 === e || null == e ? e : Fn.isArray(e) ? e.map(mr) : String(e)
        }

        function gr(e, t, n, r, a) {
            return Fn.isFunction(r) ? r.call(this, t, n) : (a && (t = n), Fn.isString(t) ? Fn.isString(r) ? -1 !== t.indexOf(r) : Fn.isRegExp(r) ? r.test(t) : void 0 : void 0)
        }
        class yr {
            constructor(e) {
                e && this.set(e)
            }
            set(e, t, n) {
                const r = this;

                function a(e, t, n) {
                    const a = hr(t);
                    if (!a) throw new Error("header name must be a non-empty string");
                    const o = Fn.findKey(r, a);
                    (!o || void 0 === r[o] || !0 === n || void 0 === n && !1 !== r[o]) && (r[o || t] = mr(e))
                }
                const o = (e, t) => Fn.forEach(e, ((e, n) => a(e, n, t)));
                if (Fn.isPlainObject(e) || e instanceof this.constructor) o(e, t);
                else if (Fn.isString(e) && (e = e.trim()) && !/^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim())) o((e => {
                    const t = {};
                    let n, r, a;
                    return e && e.split("\n").forEach((function(e) {
                        a = e.indexOf(":"), n = e.substring(0, a).trim().toLowerCase(), r = e.substring(a + 1).trim(), !n || t[n] && fr[n] || ("set-cookie" === n ? t[n] ? t[n].push(r) : t[n] = [r] : t[n] = t[n] ? t[n] + ", " + r : r)
                    })), t
                })(e), t);
                else if (Fn.isHeaders(e))
                    for (const [l, i] of e.entries()) a(i, l, n);
                else null != e && a(t, e, n);
                return this
            }
            get(e, t) {
                if (e = hr(e)) {
                    const n = Fn.findKey(this, e);
                    if (n) {
                        const e = this[n];
                        if (!t) return e;
                        if (!0 === t) return function(e) {
                            const t = Object.create(null),
                                n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
                            let r;
                            for (; r = n.exec(e);) t[r[1]] = r[2];
                            return t
                        }(e);
                        if (Fn.isFunction(t)) return t.call(this, e, n);
                        if (Fn.isRegExp(t)) return t.exec(e);
                        throw new TypeError("parser must be boolean|regexp|function")
                    }
                }
            }
            has(e, t) {
                if (e = hr(e)) {
                    const n = Fn.findKey(this, e);
                    return !(!n || void 0 === this[n] || t && !gr(0, this[n], n, t))
                }
                return !1
            }
            delete(e, t) {
                const n = this;
                let r = !1;

                function a(e) {
                    if (e = hr(e)) {
                        const a = Fn.findKey(n, e);
                        !a || t && !gr(0, n[a], a, t) || (delete n[a], r = !0)
                    }
                }
                return Fn.isArray(e) ? e.forEach(a) : a(e), r
            }
            clear(e) {
                const t = Object.keys(this);
                let n = t.length,
                    r = !1;
                for (; n--;) {
                    const a = t[n];
                    e && !gr(0, this[a], a, e, !0) || (delete this[a], r = !0)
                }
                return r
            }
            normalize(e) {
                const t = this,
                    n = {};
                return Fn.forEach(this, ((r, a) => {
                    const o = Fn.findKey(n, a);
                    if (o) return t[o] = mr(r), void delete t[a];
                    const l = e ? function(e) {
                        return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, ((e, t, n) => t.toUpperCase() + n))
                    }(a) : String(a).trim();
                    l !== a && delete t[a], t[l] = mr(r), n[l] = !0
                })), this
            }
            concat() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return this.constructor.concat(this, ...t)
            }
            toJSON(e) {
                const t = Object.create(null);
                return Fn.forEach(this, ((n, r) => {
                    null != n && !1 !== n && (t[r] = e && Fn.isArray(n) ? n.join(", ") : n)
                })), t
            }[Symbol.iterator]() {
                return Object.entries(this.toJSON())[Symbol.iterator]()
            }
            toString() {
                return Object.entries(this.toJSON()).map((e => {
                    let [t, n] = e;
                    return t + ": " + n
                })).join("\n")
            }
            get[Symbol.toStringTag]() {
                return "AxiosHeaders"
            }
            static from(e) {
                return e instanceof this ? e : new this(e)
            }
            static concat(e) {
                const t = new this(e);
                for (var n = arguments.length, r = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++) r[a - 1] = arguments[a];
                return r.forEach((e => t.set(e))), t
            }
            static accessor(e) {
                const t = (this[pr] = this[pr] = {
                        accessors: {}
                    }).accessors,
                    n = this.prototype;

                function r(e) {
                    const r = hr(e);
                    t[r] || (! function(e, t) {
                        const n = Fn.toCamelCase(" " + t);
                        ["get", "set", "has"].forEach((r => {
                            Object.defineProperty(e, r + n, {
                                value: function(e, n, a) {
                                    return this[r].call(this, t, e, n, a)
                                },
                                configurable: !0
                            })
                        }))
                    }(n, e), t[r] = !0)
                }
                return Fn.isArray(e) ? e.forEach(r) : r(e), this
            }
        }
        yr.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]), Fn.reduceDescriptors(yr.prototype, ((e, t) => {
            let {
                value: n
            } = e, r = t[0].toUpperCase() + t.slice(1);
            return {
                get: () => n,
                set(e) {
                    this[r] = e
                }
            }
        })), Fn.freezeMethods(yr);
        const vr = yr;

        function br(e, t) {
            const n = this || dr,
                r = t || n,
                a = vr.from(r.headers);
            let o = r.data;
            return Fn.forEach(e, (function(e) {
                o = e.call(n, o, a.normalize(), t ? t.status : void 0)
            })), a.normalize(), o
        }

        function wr(e) {
            return !(!e || !e.__CANCEL__)
        }

        function xr(e, t, n) {
            Hn.call(this, null == e ? "canceled" : e, Hn.ERR_CANCELED, t, n), this.name = "CanceledError"
        }
        Fn.inherits(xr, Hn, {
            __CANCEL__: !0
        });
        const Sr = xr;

        function kr(e, t, n) {
            const r = n.config.validateStatus;
            n.status && r && !r(n.status) ? t(new Hn("Request failed with status code " + n.status, [Hn.ERR_BAD_REQUEST, Hn.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4], n.config, n.request, n)) : e(n)
        }
        const Er = function(e, t) {
            e = e || 10;
            const n = new Array(e),
                r = new Array(e);
            let a, o = 0,
                l = 0;
            return t = void 0 !== t ? t : 1e3,
                function(i) {
                    const s = Date.now(),
                        u = r[l];
                    a || (a = s), n[o] = i, r[o] = s;
                    let c = l,
                        d = 0;
                    for (; c !== o;) d += n[c++], c %= e;
                    if (o = (o + 1) % e, o === l && (l = (l + 1) % e), s - a < t) return;
                    const f = u && s - u;
                    return f ? Math.round(1e3 * d / f) : void 0
                }
        };
        const Cr = function(e, t) {
                let n = 0;
                const r = 1e3 / t;
                let a = null;
                return function() {
                    const t = !0 === this,
                        o = Date.now();
                    if (t || o - n > r) return a && (clearTimeout(a), a = null), n = o, e.apply(null, arguments);
                    a || (a = setTimeout((() => (a = null, n = Date.now(), e.apply(null, arguments))), r - (o - n)))
                }
            },
            Nr = function(e, t) {
                let n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 3,
                    r = 0;
                const a = Er(50, 250);
                return Cr((n => {
                    const o = n.loaded,
                        l = n.lengthComputable ? n.total : void 0,
                        i = o - r,
                        s = a(i);
                    r = o;
                    const u = {
                        loaded: o,
                        total: l,
                        progress: l ? o / l : void 0,
                        bytes: i,
                        rate: s || void 0,
                        estimated: s && l && o <= l ? (l - o) / s : void 0,
                        event: n,
                        lengthComputable: null != l
                    };
                    u[t ? "download" : "upload"] = !0, e(u)
                }), n)
            },
            jr = sr.hasStandardBrowserEnv ? function() {
                const e = /(msie|trident)/i.test(navigator.userAgent),
                    t = document.createElement("a");
                let n;

                function r(n) {
                    let r = n;
                    return e && (t.setAttribute("href", r), r = t.href), t.setAttribute("href", r), {
                        href: t.href,
                        protocol: t.protocol ? t.protocol.replace(/:$/, "") : "",
                        host: t.host,
                        search: t.search ? t.search.replace(/^\?/, "") : "",
                        hash: t.hash ? t.hash.replace(/^#/, "") : "",
                        hostname: t.hostname,
                        port: t.port,
                        pathname: "/" === t.pathname.charAt(0) ? t.pathname : "/" + t.pathname
                    }
                }
                return n = r(window.location.href),
                    function(e) {
                        const t = Fn.isString(e) ? r(e) : e;
                        return t.protocol === n.protocol && t.host === n.host
                    }
            }() : function() {
                return !0
            },
            _r = sr.hasStandardBrowserEnv ? {
                write(e, t, n, r, a, o) {
                    const l = [e + "=" + encodeURIComponent(t)];
                    Fn.isNumber(n) && l.push("expires=" + new Date(n).toGMTString()), Fn.isString(r) && l.push("path=" + r), Fn.isString(a) && l.push("domain=" + a), !0 === o && l.push("secure"), document.cookie = l.join("; ")
                },
                read(e) {
                    const t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                    return t ? decodeURIComponent(t[3]) : null
                },
                remove(e) {
                    this.write(e, "", Date.now() - 864e5)
                }
            } : {
                write() {},
                read: () => null,
                remove() {}
            };

        function Tr(e, t) {
            return e && !/^([a-z][a-z\d+\-.]*:)?\/\//i.test(t) ? function(e, t) {
                return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e
            }(e, t) : t
        }
        const Pr = e => e instanceof vr ? { ...e
        } : e;

        function Or(e, t) {
            t = t || {};
            const n = {};

            function r(e, t, n) {
                return Fn.isPlainObject(e) && Fn.isPlainObject(t) ? Fn.merge.call({
                    caseless: n
                }, e, t) : Fn.isPlainObject(t) ? Fn.merge({}, t) : Fn.isArray(t) ? t.slice() : t
            }

            function a(e, t, n) {
                return Fn.isUndefined(t) ? Fn.isUndefined(e) ? void 0 : r(void 0, e, n) : r(e, t, n)
            }

            function o(e, t) {
                if (!Fn.isUndefined(t)) return r(void 0, t)
            }

            function l(e, t) {
                return Fn.isUndefined(t) ? Fn.isUndefined(e) ? void 0 : r(void 0, e) : r(void 0, t)
            }

            function i(n, a, o) {
                return o in t ? r(n, a) : o in e ? r(void 0, n) : void 0
            }
            const s = {
                url: o,
                method: o,
                data: o,
                baseURL: l,
                transformRequest: l,
                transformResponse: l,
                paramsSerializer: l,
                timeout: l,
                timeoutMessage: l,
                withCredentials: l,
                withXSRFToken: l,
                adapter: l,
                responseType: l,
                xsrfCookieName: l,
                xsrfHeaderName: l,
                onUploadProgress: l,
                onDownloadProgress: l,
                decompress: l,
                maxContentLength: l,
                maxBodyLength: l,
                beforeRedirect: l,
                transport: l,
                httpAgent: l,
                httpsAgent: l,
                cancelToken: l,
                socketPath: l,
                responseEncoding: l,
                validateStatus: i,
                headers: (e, t) => a(Pr(e), Pr(t), !0)
            };
            return Fn.forEach(Object.keys(Object.assign({}, e, t)), (function(r) {
                const o = s[r] || a,
                    l = o(e[r], t[r], r);
                Fn.isUndefined(l) && o !== i || (n[r] = l)
            })), n
        }
        const Rr = e => {
                const t = Or({}, e);
                let n, {
                    data: r,
                    withXSRFToken: a,
                    xsrfHeaderName: o,
                    xsrfCookieName: l,
                    headers: i,
                    auth: s
                } = t;
                if (t.headers = i = vr.from(i), t.url = Zn(Tr(t.baseURL, t.url), e.params, e.paramsSerializer), s && i.set("Authorization", "Basic " + btoa((s.username || "") + ":" + (s.password ? unescape(encodeURIComponent(s.password)) : ""))), Fn.isFormData(r))
                    if (sr.hasStandardBrowserEnv || sr.hasStandardBrowserWebWorkerEnv) i.setContentType(void 0);
                    else if (!1 !== (n = i.getContentType())) {
                    const [e, ...t] = n ? n.split(";").map((e => e.trim())).filter(Boolean) : [];
                    i.setContentType([e || "multipart/form-data", ...t].join("; "))
                }
                if (sr.hasStandardBrowserEnv && (a && Fn.isFunction(a) && (a = a(t)), a || !1 !== a && jr(t.url))) {
                    const e = o && l && _r.read(l);
                    e && i.set(o, e)
                }
                return t
            },
            Lr = "undefined" !== typeof XMLHttpRequest && function(e) {
                return new Promise((function(t, n) {
                    const r = Rr(e);
                    let a = r.data;
                    const o = vr.from(r.headers).normalize();
                    let l, {
                        responseType: i
                    } = r;

                    function s() {
                        r.cancelToken && r.cancelToken.unsubscribe(l), r.signal && r.signal.removeEventListener("abort", l)
                    }
                    let u = new XMLHttpRequest;

                    function c() {
                        if (!u) return;
                        const r = vr.from("getAllResponseHeaders" in u && u.getAllResponseHeaders());
                        kr((function(e) {
                            t(e), s()
                        }), (function(e) {
                            n(e), s()
                        }), {
                            data: i && "text" !== i && "json" !== i ? u.response : u.responseText,
                            status: u.status,
                            statusText: u.statusText,
                            headers: r,
                            config: e,
                            request: u
                        }), u = null
                    }
                    u.open(r.method.toUpperCase(), r.url, !0), u.timeout = r.timeout, "onloadend" in u ? u.onloadend = c : u.onreadystatechange = function() {
                        u && 4 === u.readyState && (0 !== u.status || u.responseURL && 0 === u.responseURL.indexOf("file:")) && setTimeout(c)
                    }, u.onabort = function() {
                        u && (n(new Hn("Request aborted", Hn.ECONNABORTED, r, u)), u = null)
                    }, u.onerror = function() {
                        n(new Hn("Network Error", Hn.ERR_NETWORK, r, u)), u = null
                    }, u.ontimeout = function() {
                        let e = r.timeout ? "timeout of " + r.timeout + "ms exceeded" : "timeout exceeded";
                        const t = r.transitional || tr;
                        r.timeoutErrorMessage && (e = r.timeoutErrorMessage), n(new Hn(e, t.clarifyTimeoutError ? Hn.ETIMEDOUT : Hn.ECONNABORTED, r, u)), u = null
                    }, void 0 === a && o.setContentType(null), "setRequestHeader" in u && Fn.forEach(o.toJSON(), (function(e, t) {
                        u.setRequestHeader(t, e)
                    })), Fn.isUndefined(r.withCredentials) || (u.withCredentials = !!r.withCredentials), i && "json" !== i && (u.responseType = r.responseType), "function" === typeof r.onDownloadProgress && u.addEventListener("progress", Nr(r.onDownloadProgress, !0)), "function" === typeof r.onUploadProgress && u.upload && u.upload.addEventListener("progress", Nr(r.onUploadProgress)), (r.cancelToken || r.signal) && (l = t => {
                        u && (n(!t || t.type ? new Sr(null, e, u) : t), u.abort(), u = null)
                    }, r.cancelToken && r.cancelToken.subscribe(l), r.signal && (r.signal.aborted ? l() : r.signal.addEventListener("abort", l)));
                    const d = function(e) {
                        const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
                        return t && t[1] || ""
                    }(r.url);
                    d && -1 === sr.protocols.indexOf(d) ? n(new Hn("Unsupported protocol " + d + ":", Hn.ERR_BAD_REQUEST, e)) : u.send(a || null)
                }))
            },
            zr = (e, t) => {
                let n, r = new AbortController;
                const a = function(e) {
                    if (!n) {
                        n = !0, l();
                        const t = e instanceof Error ? e : this.reason;
                        r.abort(t instanceof Hn ? t : new Sr(t instanceof Error ? t.message : t))
                    }
                };
                let o = t && setTimeout((() => {
                    a(new Hn("timeout ".concat(t, " of ms exceeded"), Hn.ETIMEDOUT))
                }), t);
                const l = () => {
                    e && (o && clearTimeout(o), o = null, e.forEach((e => {
                        e && (e.removeEventListener ? e.removeEventListener("abort", a) : e.unsubscribe(a))
                    })), e = null)
                };
                e.forEach((e => e && e.addEventListener && e.addEventListener("abort", a)));
                const {
                    signal: i
                } = r;
                return i.unsubscribe = l, [i, () => {
                    o && clearTimeout(o), o = null
                }]
            },
            Dr = function*(e, t) {
                let n = e.byteLength;
                if (!t || n < t) return void(yield e);
                let r, a = 0;
                for (; a < n;) r = a + t, yield e.slice(a, r), a = r
            },
            Ar = (e, t, n, r, a) => {
                const o = async function*(e, t, n) {
                    for await (const r of e) yield* Dr(ArrayBuffer.isView(r) ? r : await n(String(r)), t)
                }(e, t, a);
                let l = 0;
                return new ReadableStream({
                    type: "bytes",
                    async pull(e) {
                        const {
                            done: t,
                            value: a
                        } = await o.next();
                        if (t) return e.close(), void r();
                        let i = a.byteLength;
                        n && n(l += i), e.enqueue(new Uint8Array(a))
                    },
                    cancel: e => (r(e), o.return())
                }, {
                    highWaterMark: 2
                })
            },
            Ir = (e, t) => {
                const n = null != e;
                return r => setTimeout((() => t({
                    lengthComputable: n,
                    total: e,
                    loaded: r
                })))
            },
            Fr = "function" === typeof fetch && "function" === typeof Request && "function" === typeof Response,
            Ur = Fr && "function" === typeof ReadableStream,
            Mr = Fr && ("function" === typeof TextEncoder ? (Br = new TextEncoder, e => Br.encode(e)) : async e => new Uint8Array(await new Response(e).arrayBuffer()));
        var Br;
        const Hr = Ur && (() => {
                let e = !1;
                const t = new Request(sr.origin, {
                    body: new ReadableStream,
                    method: "POST",
                    get duplex() {
                        return e = !0, "half"
                    }
                }).headers.has("Content-Type");
                return e && !t
            })(),
            Wr = Ur && !!(() => {
                try {
                    return Fn.isReadableStream(new Response("").body)
                } catch (e) {}
            })(),
            Vr = {
                stream: Wr && (e => e.body)
            };
        var $r;
        Fr && ($r = new Response, ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((e => {
            !Vr[e] && (Vr[e] = Fn.isFunction($r[e]) ? t => t[e]() : (t, n) => {
                throw new Hn("Response type '".concat(e, "' is not supported"), Hn.ERR_NOT_SUPPORT, n)
            })
        })));
        const qr = async (e, t) => {
                const n = Fn.toFiniteNumber(e.getContentLength());
                return null == n ? (async e => null == e ? 0 : Fn.isBlob(e) ? e.size : Fn.isSpecCompliantForm(e) ? (await new Request(e).arrayBuffer()).byteLength : Fn.isArrayBufferView(e) ? e.byteLength : (Fn.isURLSearchParams(e) && (e += ""), Fn.isString(e) ? (await Mr(e)).byteLength : void 0))(t) : n
            },
            Qr = {
                http: null,
                xhr: Lr,
                fetch: Fr && (async e => {
                    let {
                        url: t,
                        method: n,
                        data: r,
                        signal: a,
                        cancelToken: o,
                        timeout: l,
                        onDownloadProgress: i,
                        onUploadProgress: s,
                        responseType: u,
                        headers: c,
                        withCredentials: d = "same-origin",
                        fetchOptions: f
                    } = Rr(e);
                    u = u ? (u + "").toLowerCase() : "text";
                    let p, h, [m, g] = a || o || l ? zr([a, o], l) : [];
                    const y = () => {
                        !p && setTimeout((() => {
                            m && m.unsubscribe()
                        })), p = !0
                    };
                    let v;
                    try {
                        if (s && Hr && "get" !== n && "head" !== n && 0 !== (v = await qr(c, r))) {
                            let e, n = new Request(t, {
                                method: "POST",
                                body: r,
                                duplex: "half"
                            });
                            Fn.isFormData(r) && (e = n.headers.get("content-type")) && c.setContentType(e), n.body && (r = Ar(n.body, 65536, Ir(v, Nr(s)), null, Mr))
                        }
                        Fn.isString(d) || (d = d ? "cors" : "omit"), h = new Request(t, { ...f,
                            signal: m,
                            method: n.toUpperCase(),
                            headers: c.normalize().toJSON(),
                            body: r,
                            duplex: "half",
                            withCredentials: d
                        });
                        let a = await fetch(h);
                        const o = Wr && ("stream" === u || "response" === u);
                        if (Wr && (i || o)) {
                            const e = {};
                            ["status", "statusText", "headers"].forEach((t => {
                                e[t] = a[t]
                            }));
                            const t = Fn.toFiniteNumber(a.headers.get("content-length"));
                            a = new Response(Ar(a.body, 65536, i && Ir(t, Nr(i, !0)), o && y, Mr), e)
                        }
                        u = u || "text";
                        let l = await Vr[Fn.findKey(Vr, u) || "text"](a, e);
                        return !o && y(), g && g(), await new Promise(((t, n) => {
                            kr(t, n, {
                                data: l,
                                headers: vr.from(a.headers),
                                status: a.status,
                                statusText: a.statusText,
                                config: e,
                                request: h
                            })
                        }))
                    } catch (b) {
                        if (y(), b && "TypeError" === b.name && /fetch/i.test(b.message)) throw Object.assign(new Hn("Network Error", Hn.ERR_NETWORK, e, h), {
                            cause: b.cause || b
                        });
                        throw Hn.from(b, b && b.code, e, h)
                    }
                })
            };
        Fn.forEach(Qr, ((e, t) => {
            if (e) {
                try {
                    Object.defineProperty(e, "name", {
                        value: t
                    })
                } catch (ga) {}
                Object.defineProperty(e, "adapterName", {
                    value: t
                })
            }
        }));
        const Kr = e => "- ".concat(e),
            Gr = e => Fn.isFunction(e) || null === e || !1 === e,
            Jr = e => {
                e = Fn.isArray(e) ? e : [e];
                const {
                    length: t
                } = e;
                let n, r;
                const a = {};
                for (let o = 0; o < t; o++) {
                    let t;
                    if (n = e[o], r = n, !Gr(n) && (r = Qr[(t = String(n)).toLowerCase()], void 0 === r)) throw new Hn("Unknown adapter '".concat(t, "'"));
                    if (r) break;
                    a[t || "#" + o] = r
                }
                if (!r) {
                    const e = Object.entries(a).map((e => {
                        let [t, n] = e;
                        return "adapter ".concat(t, " ") + (!1 === n ? "is not supported by the environment" : "is not available in the build")
                    }));
                    let n = t ? e.length > 1 ? "since :\n" + e.map(Kr).join("\n") : " " + Kr(e[0]) : "as no adapter specified";
                    throw new Hn("There is no suitable adapter to dispatch the request " + n, "ERR_NOT_SUPPORT")
                }
                return r
            };

        function Xr(e) {
            if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new Sr(null, e)
        }

        function Yr(e) {
            Xr(e), e.headers = vr.from(e.headers), e.data = br.call(e, e.transformRequest), -1 !== ["post", "put", "patch"].indexOf(e.method) && e.headers.setContentType("application/x-www-form-urlencoded", !1);
            return Jr(e.adapter || dr.adapter)(e).then((function(t) {
                return Xr(e), t.data = br.call(e, e.transformResponse, t), t.headers = vr.from(t.headers), t
            }), (function(t) {
                return wr(t) || (Xr(e), t && t.response && (t.response.data = br.call(e, e.transformResponse, t.response), t.response.headers = vr.from(t.response.headers))), Promise.reject(t)
            }))
        }
        const Zr = "1.7.2",
            ea = {};
        ["object", "boolean", "number", "function", "string", "symbol"].forEach(((e, t) => {
            ea[e] = function(n) {
                return typeof n === e || "a" + (t < 1 ? "n " : " ") + e
            }
        }));
        const ta = {};
        ea.transitional = function(e, t, n) {
            function r(e, t) {
                return "[Axios v1.7.2] Transitional option '" + e + "'" + t + (n ? ". " + n : "")
            }
            return (n, a, o) => {
                if (!1 === e) throw new Hn(r(a, " has been removed" + (t ? " in " + t : "")), Hn.ERR_DEPRECATED);
                return t && !ta[a] && (ta[a] = !0, console.warn(r(a, " has been deprecated since v" + t + " and will be removed in the near future"))), !e || e(n, a, o)
            }
        };
        const na = {
                assertOptions: function(e, t, n) {
                    if ("object" !== typeof e) throw new Hn("options must be an object", Hn.ERR_BAD_OPTION_VALUE);
                    const r = Object.keys(e);
                    let a = r.length;
                    for (; a-- > 0;) {
                        const o = r[a],
                            l = t[o];
                        if (l) {
                            const t = e[o],
                                n = void 0 === t || l(t, o, e);
                            if (!0 !== n) throw new Hn("option " + o + " must be " + n, Hn.ERR_BAD_OPTION_VALUE)
                        } else if (!0 !== n) throw new Hn("Unknown option " + o, Hn.ERR_BAD_OPTION)
                    }
                },
                validators: ea
            },
            ra = na.validators;
        class aa {
            constructor(e) {
                this.defaults = e, this.interceptors = {
                    request: new er,
                    response: new er
                }
            }
            async request(e, t) {
                try {
                    return await this._request(e, t)
                } catch (n) {
                    if (n instanceof Error) {
                        let e;
                        Error.captureStackTrace ? Error.captureStackTrace(e = {}) : e = new Error;
                        const t = e.stack ? e.stack.replace(/^.+\n/, "") : "";
                        try {
                            n.stack ? t && !String(n.stack).endsWith(t.replace(/^.+\n.+\n/, "")) && (n.stack += "\n" + t) : n.stack = t
                        } catch (ga) {}
                    }
                    throw n
                }
            }
            _request(e, t) {
                "string" === typeof e ? (t = t || {}).url = e : t = e || {}, t = Or(this.defaults, t);
                const {
                    transitional: n,
                    paramsSerializer: r,
                    headers: a
                } = t;
                void 0 !== n && na.assertOptions(n, {
                    silentJSONParsing: ra.transitional(ra.boolean),
                    forcedJSONParsing: ra.transitional(ra.boolean),
                    clarifyTimeoutError: ra.transitional(ra.boolean)
                }, !1), null != r && (Fn.isFunction(r) ? t.paramsSerializer = {
                    serialize: r
                } : na.assertOptions(r, {
                    encode: ra.function,
                    serialize: ra.function
                }, !0)), t.method = (t.method || this.defaults.method || "get").toLowerCase();
                let o = a && Fn.merge(a.common, a[t.method]);
                a && Fn.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (e => {
                    delete a[e]
                })), t.headers = vr.concat(o, a);
                const l = [];
                let i = !0;
                this.interceptors.request.forEach((function(e) {
                    "function" === typeof e.runWhen && !1 === e.runWhen(t) || (i = i && e.synchronous, l.unshift(e.fulfilled, e.rejected))
                }));
                const s = [];
                let u;
                this.interceptors.response.forEach((function(e) {
                    s.push(e.fulfilled, e.rejected)
                }));
                let c, d = 0;
                if (!i) {
                    const e = [Yr.bind(this), void 0];
                    for (e.unshift.apply(e, l), e.push.apply(e, s), c = e.length, u = Promise.resolve(t); d < c;) u = u.then(e[d++], e[d++]);
                    return u
                }
                c = l.length;
                let f = t;
                for (d = 0; d < c;) {
                    const e = l[d++],
                        t = l[d++];
                    try {
                        f = e(f)
                    } catch (p) {
                        t.call(this, p);
                        break
                    }
                }
                try {
                    u = Yr.call(this, f)
                } catch (p) {
                    return Promise.reject(p)
                }
                for (d = 0, c = s.length; d < c;) u = u.then(s[d++], s[d++]);
                return u
            }
            getUri(e) {
                return Zn(Tr((e = Or(this.defaults, e)).baseURL, e.url), e.params, e.paramsSerializer)
            }
        }
        Fn.forEach(["delete", "get", "head", "options"], (function(e) {
            aa.prototype[e] = function(t, n) {
                return this.request(Or(n || {}, {
                    method: e,
                    url: t,
                    data: (n || {}).data
                }))
            }
        })), Fn.forEach(["post", "put", "patch"], (function(e) {
            function t(t) {
                return function(n, r, a) {
                    return this.request(Or(a || {}, {
                        method: e,
                        headers: t ? {
                            "Content-Type": "multipart/form-data"
                        } : {},
                        url: n,
                        data: r
                    }))
                }
            }
            aa.prototype[e] = t(), aa.prototype[e + "Form"] = t(!0)
        }));
        const oa = aa;
        class la {
            constructor(e) {
                if ("function" !== typeof e) throw new TypeError("executor must be a function.");
                let t;
                this.promise = new Promise((function(e) {
                    t = e
                }));
                const n = this;
                this.promise.then((e => {
                    if (!n._listeners) return;
                    let t = n._listeners.length;
                    for (; t-- > 0;) n._listeners[t](e);
                    n._listeners = null
                })), this.promise.then = e => {
                    let t;
                    const r = new Promise((e => {
                        n.subscribe(e), t = e
                    })).then(e);
                    return r.cancel = function() {
                        n.unsubscribe(t)
                    }, r
                }, e((function(e, r, a) {
                    n.reason || (n.reason = new Sr(e, r, a), t(n.reason))
                }))
            }
            throwIfRequested() {
                if (this.reason) throw this.reason
            }
            subscribe(e) {
                this.reason ? e(this.reason) : this._listeners ? this._listeners.push(e) : this._listeners = [e]
            }
            unsubscribe(e) {
                if (!this._listeners) return;
                const t = this._listeners.indexOf(e); - 1 !== t && this._listeners.splice(t, 1)
            }
            static source() {
                let e;
                const t = new la((function(t) {
                    e = t
                }));
                return {
                    token: t,
                    cancel: e
                }
            }
        }
        const ia = la;
        const sa = {
            Continue: 100,
            SwitchingProtocols: 101,
            Processing: 102,
            EarlyHints: 103,
            Ok: 200,
            Created: 201,
            Accepted: 202,
            NonAuthoritativeInformation: 203,
            NoContent: 204,
            ResetContent: 205,
            PartialContent: 206,
            MultiStatus: 207,
            AlreadyReported: 208,
            ImUsed: 226,
            MultipleChoices: 300,
            MovedPermanently: 301,
            Found: 302,
            SeeOther: 303,
            NotModified: 304,
            UseProxy: 305,
            Unused: 306,
            TemporaryRedirect: 307,
            PermanentRedirect: 308,
            BadRequest: 400,
            Unauthorized: 401,
            PaymentRequired: 402,
            Forbidden: 403,
            NotFound: 404,
            MethodNotAllowed: 405,
            NotAcceptable: 406,
            ProxyAuthenticationRequired: 407,
            RequestTimeout: 408,
            Conflict: 409,
            Gone: 410,
            LengthRequired: 411,
            PreconditionFailed: 412,
            PayloadTooLarge: 413,
            UriTooLong: 414,
            UnsupportedMediaType: 415,
            RangeNotSatisfiable: 416,
            ExpectationFailed: 417,
            ImATeapot: 418,
            MisdirectedRequest: 421,
            UnprocessableEntity: 422,
            Locked: 423,
            FailedDependency: 424,
            TooEarly: 425,
            UpgradeRequired: 426,
            PreconditionRequired: 428,
            TooManyRequests: 429,
            RequestHeaderFieldsTooLarge: 431,
            UnavailableForLegalReasons: 451,
            InternalServerError: 500,
            NotImplemented: 501,
            BadGateway: 502,
            ServiceUnavailable: 503,
            GatewayTimeout: 504,
            HttpVersionNotSupported: 505,
            VariantAlsoNegotiates: 506,
            InsufficientStorage: 507,
            LoopDetected: 508,
            NotExtended: 510,
            NetworkAuthenticationRequired: 511
        };
        Object.entries(sa).forEach((e => {
            let [t, n] = e;
            sa[n] = t
        }));
        const ua = sa;
        const ca = function e(t) {
            const n = new oa(t),
                r = Zt(oa.prototype.request, n);
            return Fn.extend(r, oa.prototype, n, {
                allOwnKeys: !0
            }), Fn.extend(r, n, null, {
                allOwnKeys: !0
            }), r.create = function(n) {
                return e(Or(t, n))
            }, r
        }(dr);
        ca.Axios = oa, ca.CanceledError = Sr, ca.CancelToken = ia, ca.isCancel = wr, ca.VERSION = Zr, ca.toFormData = Qn, ca.AxiosError = Hn, ca.Cancel = ca.CanceledError, ca.all = function(e) {
            return Promise.all(e)
        }, ca.spread = function(e) {
            return function(t) {
                return e.apply(null, t)
            }
        }, ca.isAxiosError = function(e) {
            return Fn.isObject(e) && !0 === e.isAxiosError
        }, ca.mergeConfig = Or, ca.AxiosHeaders = vr, ca.formToJSON = e => ur(Fn.isHTMLForm(e) ? new FormData(e) : e), ca.getAdapter = Jr, ca.HttpStatusCode = ua, ca.default = ca;
        const da = ca,
            fa = () => {
                const [e, t] = (0, r.useState)([]), [n, a] = (0, r.useState)([]), [o, l] = (0, r.useState)(!0), [i, s] = (0, r.useState)(null), [u, c] = (0, r.useState)(""), d = "https://itclg-api.onrender.com";
                (0, r.useEffect)((() => {
                    (async () => {
                        try {
                            const e = await da.get("".concat(d, "/api/getallstudent"), {
                                withCredentials: !0
                            });
                            t(e.data.students), a(e.data.students), l(!1)
                        } catch (e) {
                            s("Error fetching students"), l(!1)
                        }
                    })()
                }), []), (0, r.useEffect)((() => {
                    if ("" === u) a(e);
                    else {
                        const t = e.filter((e => e.name.toLowerCase().includes(u.toLowerCase()) || e.card.toLowerCase().includes(u.toLowerCase())));
                        a(t)
                    }
                }), [u, e]);
                return o ? (0, yt.jsx)("div", {
                    children: "Loading..."
                }) : i ? (0, yt.jsx)("div", {
                    children: i
                }) : (0, yt.jsxs)("div", {
                    className: "container mt-5",
                    children: [(0, yt.jsxs)("div", {
                        className: "d-flex justify-content-between align-items-center bg-light p-3 rounded shadow-sm",
                        children: [(0, yt.jsx)("h2", {
                            className: "mb-0 text-primary fw-bold",
                            children: "Student Records"
                        }), (0, yt.jsxs)("p", {
                            className: "px-3 py-2 bg-primary text-white rounded-pill text-center fw-semibold shadow-sm",
                            children: ["Total: ", e.length]
                        })]
                    }), (0, yt.jsx)("div", {
                        className: "mb-4 row mt-2",
                        children: (0, yt.jsx)("div", {
                            className: "col-12 col-md-6",
                            children: (0, yt.jsx)("input", {
                                type: "text",
                                className: "form-control",
                                placeholder: "Search by name or card ID",
                                value: u,
                                onChange: e => c(e.target.value)
                            })
                        })
                    }), n.length > 0 ? (0, yt.jsx)("div", {
                        className: "table-responsive",
                        children: (0, yt.jsxs)("table", {
                            className: "table table-striped table-bordered table-hover shadow-lg",
                            children: [(0, yt.jsx)("thead", {
                                className: "table-dark ",
                                children: (0, yt.jsxs)("tr", {
                                    children: [(0, yt.jsx)("th", {
                                        children: "Image"
                                    }), (0, yt.jsx)("th", {
                                        children: "Name"
                                    }), (0, yt.jsx)("th", {
                                        children: "Card ID"
                                    }), (0, yt.jsx)("th", {
                                        children: "Course"
                                    }), (0, yt.jsx)("th", {
                                        children: "City"
                                    }), (0, yt.jsx)("th", {
                                        children: "State"
                                    }), (0, yt.jsx)("th", {
                                        children: "Actions"
                                    })]
                                })
                            }), (0, yt.jsx)("tbody", {
                                children: n.map((r => (0, yt.jsxs)("tr", {
                                    children: [(0, yt.jsx)("td", {
                                        children: (0, yt.jsx)("img", {
                                            src: r.image,
                                            alt: r.name,
                                            className: "img-thumbnail",
                                            style: {
                                                width: "50px",
                                                height: "50px",
                                                objectFit: "cover"
                                            }
                                        })
                                    }), (0, yt.jsx)("td", {
                                        children: r.name
                                    }), (0, yt.jsx)("td", {
                                        children: r.card
                                    }), (0, yt.jsx)("td", {
                                        children: r.course
                                    }), (0, yt.jsx)("td", {
                                        children: r.city
                                    }), (0, yt.jsx)("td", {
                                        children: r.state
                                    }), (0, yt.jsx)("td", {
                                        children: (0, yt.jsx)("button", {
                                            className: "btn btn-danger btn-sm",
                                            onClick: () => (async r => {
                                                try {
                                                    await da.delete("".concat(d, "/api/deletestudent/").concat(r), {
                                                        withCredentials: !0
                                                    }), t(e.filter((e => e._id !== r))), a(n.filter((e => e._id !== r)))
                                                } catch (o) {
                                                    s("Error deleting student")
                                                }
                                            })(r._id),
                                            children: "Delete"
                                        })
                                    })]
                                }, r._id)))
                            })]
                        })
                    }) : (0, yt.jsx)("p", {
                        className: "text-center",
                        children: "No students found"
                    })]
                })
            },
            pa = () => {
                const [e, t] = (0, r.useState)([]), [n, a] = (0, r.useState)(!0), [o, l] = (0, r.useState)(null), i = "https://itclg-api.onrender.com";
                (0, r.useEffect)((() => {
                    (async () => {
                        try {
                            const e = await da.get("".concat(i, "/api/getalladmins"), {
                                withCredentials: !0
                            });
                            t(e.data.admins), a(!1)
                        } catch (e) {
                            l("Error fetching users"), a(!1)
                        }
                    })()
                }), []);
                return n ? (0, yt.jsx)("div", {
                    children: "Loading..."
                }) : o ? (0, yt.jsx)("div", {
                    children: o
                }) : (0, yt.jsxs)("div", {
                    className: "container mt-5",
                    children: [(0, yt.jsx)("h1", {
                        className: "mb-4",
                        children: "User Records"
                    }), e.length > 0 ? (0, yt.jsx)("div", {
                        className: "table-responsive",
                        children: (0, yt.jsxs)("table", {
                            className: "table table-striped table-bordered table-hover shadow-lg",
                            children: [(0, yt.jsx)("thead", {
                                className: "table-dark",
                                children: (0, yt.jsxs)("tr", {
                                    children: [(0, yt.jsx)("th", {
                                        children: "Name"
                                    }), (0, yt.jsx)("th", {
                                        children: "Email"
                                    }), (0, yt.jsx)("th", {
                                        children: "Role"
                                    }), (0, yt.jsx)("th", {
                                        children: "Actions"
                                    })]
                                })
                            }), (0, yt.jsx)("tbody", {
                                children: e.map((n => (0, yt.jsxs)("tr", {
                                    children: [(0, yt.jsx)("td", {
                                        children: n.username
                                    }), (0, yt.jsx)("td", {
                                        children: n.email
                                    }), (0, yt.jsx)("td", {
                                        children: n.role
                                    }), (0, yt.jsx)("td", {
                                        children: (0, yt.jsx)("button", {
                                            className: "btn btn-danger btn-sm",
                                            onClick: () => (async n => {
                                                try {
                                                    const r = await da.delete("".concat(i, "/api/deleteadmin/").concat(n), {
                                                        withCredentials: !0
                                                    });
                                                    t(e.filter((e => e._id !== n))), alert(r.data.message)
                                                } catch (r) {
                                                    alert("Error deleting user")
                                                }
                                            })(n._id),
                                            children: "Delete"
                                        })
                                    })]
                                }, n._id)))
                            })]
                        })
                    }) : (0, yt.jsx)("p", {
                        className: "text-center",
                        children: "No users found"
                    })]
                })
            },
            ha = () => {
                const [e, t] = (0, r.useState)("student"), n = e => {
                    t(e)
                };
                return (0, yt.jsxs)("div", {
                    className: "p-2 p-md-5 mb-5",
                    children: [(0, yt.jsx)("h1", {
                        children: "Admin Dashboard"
                    }), (0, yt.jsxs)("nav", {
                        className: "d-flex gap-2",
                        children: [(0, yt.jsx)("button", {
                            className: "btn btn-sm px-3 py-1 rounded-pill ".concat("student" === e ? "btn-primary" : "btn-outline-primary"),
                            onClick: () => n("student"),
                            children: "Student"
                        }), (0, yt.jsx)("button", {
                            className: "btn btn-sm px-3 py-1 rounded-pill ".concat("user" === e ? "btn-primary" : "btn-outline-primary"),
                            onClick: () => n("user"),
                            children: "Users"
                        })]
                    }), (0, yt.jsx)("hr", {}), (0, yt.jsx)("div", {
                        className: "mt-4",
                        children: "student" === e ? (0, yt.jsx)(fa, {}) : (0, yt.jsx)(pa, {})
                    })]
                })
            };
        const ma = function() {
            return (0, yt.jsxs)(yt.Fragment, {
                children: [(0, yt.jsx)(St, {}), (0, yt.jsxs)(be, {
                    children: [(0, yt.jsxs)(ye, {
                        element: (0, yt.jsx)(Jt, {}),
                        children: [(0, yt.jsx)(ye, {
                            path: "/register",
                            element: (0, yt.jsx)(kt, {})
                        }), (0, yt.jsxs)(ye, {
                            path: "/dashboard",
                            element: (0, yt.jsx)(ha, {}),
                            children: [(0, yt.jsx)(ye, {
                                path: "userrecord",
                                element: (0, yt.jsx)(pa, {})
                            }), (0, yt.jsx)(ye, {
                                path: "studentrecord",
                                element: (0, yt.jsx)(fa, {})
                            })]
                        })]
                    }), (0, yt.jsx)(ye, {
                        path: "/initial-admin",
                        element: (0, yt.jsx)(Xt, {})
                    }), (0, yt.jsx)(ye, {
                        path: "/",
                        element: (0, yt.jsx)(Ot, {})
                    }), (0, yt.jsx)(ye, {
                        path: "/about",
                        element: (0, yt.jsx)(Yt, {})
                    }), (0, yt.jsx)(ye, {
                        path: "/signup",
                        element: (0, yt.jsx)(qt, {})
                    }), (0, yt.jsx)(ye, {
                        path: "/login",
                        element: (0, yt.jsx)(Gt, {})
                    })]
                }), (0, yt.jsx)(Rt, {})]
            })
        };
        o.createRoot(document.getElementById("root")).render((0, yt.jsx)(je, {
            children: (0, yt.jsxs)(wt, {
                children: [(0, yt.jsx)(ma, {}), (0, yt.jsx)(gt, {
                    bodyClassName: "toastBody"
                })]
            })
        }))
    })()
})();
//# sourceMappingURL=main.242c745f.js.map